Situated AI 4.0.0
=================
产品版本 / Product version：4.0.0
支持的游戏版本 / Supported game version：1.15.0
启用模块 / Enabled modules：reform、market、security、economy、diplomacy、country_state、information_rules、consumer_adapters / reform, market, security, economy, diplomacy, country_state, information_rules, consumer_adapters
存档兼容 / Save compatibility：new-game-only

【中文】
这是标准安装包。它依据国家的政治、人口、财政、经济、市场、贸易、外交、宗属、军事、战争、殖民、地理、身份与科技处境调整原版 AI 权重。原版资格、成本、效果与行动流程继续生效；本 Mod 不提供免费资源、不强制行动，也不按国家编写固定剧本。
模块开关：reform=启用，market=启用，security=启用，economy=启用，diplomacy=启用。
宗属倾向由声明式原版消费者适配器统一实现。
财政风险在违约，或正在借款且距破产少于 26 周时进入；使用 52 周退出线与 62 天状态有效期。外交博弈中立偏置为 25，攻击性偏置为 0。同一行动的互斥档位取最强已知档，独立收益与成本联合评估，在消费者末端一次限幅；倍率保留原版零值。
安装：退出游戏，将 ZIP 解压到文档目录的 `Paradox Interactive/Victoria 3/mod/Situated AI`，在启动器中登记并启用独立 playset。不要覆盖游戏本体。本包覆盖部分原版 AI 消费者文件；其它 Mod 不在兼容范围内。支持锁定版本的全部 11 种本体语言。
回退：退出游戏后禁用或删除本 Mod，并恢复安装前存档。任意旧存档迁移不受保证。游戏更新后应停用旧包，等待针对新版本重新生成。
工程检查证明生成、打包和锁定原版接口符合自动化契约；AI 长期行为、平衡、后期性能、玩家体验与创意工坊发布由用户验收。

[English]
This is the standard installation package. It adjusts vanilla AI weights using political, population, fiscal, economic, market, trade, diplomatic, subject, military, war, colonial, geographic, identity, and technology context. Vanilla eligibility, costs, effects, and actions remain in force. The Mod grants no free resources and forces no action. It observes current conditions at vanilla consumer evaluation time; no exclusive country route locks other domains. Vanilla AI still compares and executes actions.
Module switches: reform=enabled; market=enabled; security=enabled; economy=enabled; diplomacy=enabled.
Subject tendencies use declarative adapters for vanilla consumers.
Fiscal risk enters on default, or while borrowing with fewer than 26 weeks to bankruptcy. It uses a 52-week exit threshold and a 62-day state lifetime. Diplomatic-play neutrality is 25; aggression is 0. Mutually exclusive tiers use the strongest known evidence; independent benefits and costs combine before one final consumer bound. Multipliers preserve vanilla zero values.
Install after exiting the game. Extract the ZIP to the documents directory at `Paradox Interactive/Victoria 3/mod/Situated AI` and enable it in an isolated launcher playset. Do not overwrite the game installation. Other Mods are outside the compatibility scope. To roll back, exit, disable or remove this Mod, and restore a pre-installation save. Disable the package after a game update until a matching release exists.
The package supports all 11 languages in the locked game version. Engineering checks cover generation, archive structure, and locked vanilla interfaces. Long-run AI behavior, balance, late-game performance, localization presentation, and Workshop publication remain for player acceptance.
