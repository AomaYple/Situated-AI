"""单一命令行入口 ``v3``。

动机
----
收敛之前，``tools/`` 下有 7 个各自为政的入口：4 个 argparse 脚本、1 个自带
subparsers 的脚本、2 个裸脚本（``show_outputs.py`` 连 ``main()`` 都没有，
靠 import 时的副作用输出）。它们各自重复了同一套样板：

* 手写 ``sys.stdout.reconfigure`` 编码兜底 —— 7 份拷贝，抄漏一份就有一条
  命令在 GBK 控制台上崩掉（现在统一走 :mod:`pdx.console`）
* 手写 ``"─" * 64`` 分隔线与 ``f"{name:<58}"`` 对齐 —— 列宽一改就全乱
* ``--json`` 语义各不相同：``run_verify.py`` 里是路径，
  ``run_defines.py`` / ``run_snapshot.py`` 里是布尔开关，落点还写死在代码里
* 退出码各写各的：``run_defines.py`` 用 1 表示「未找到命名空间」，
  与「检查未通过」撞在一起

收敛成一个 typer 应用后，这些约定只有一处定义，``--help`` 也只有一份。

退出码约定
----------
====  ==============================================================
0     成功
1     检查未通过（``verify`` / ``check-outputs`` / ``snapshot verify``）
2     用法错误，或前置条件缺失（游戏目录、产物、快照文件不存在）
3     检查跑了，但输入使结论**不可得**（今天只有 ``crosscheck`` 的
      「行号不可比」一档：引擎日志核对的文件被 mod 覆盖、行数不同）
====  ==============================================================

三者之外不存在「吞掉异常然后返回 0」的路径：需要容错时只捕
:data:`pdx.parser.TOLERATED_ERRORS` 这样的精确异常集合，并且必须把失败
原因打出来 —— 静默跳过是让检查表腐烂的最快方式。

退出码 3 是 2026-09-28 补的第四档（见 :data:`EXIT_UNVERIFIABLE`）：
「核对不了」既不是通过也不是不通过，用 0 冒充成功、用 1 冒充失败
都是把责任记到错的账上。它的判据、措辞与代价都写在那个常量的注释里。
"""

from __future__ import annotations

import json
import time

# Path 必须能**在运行期**导入：typer 用 ``inspect.signature(eval_str=True)``
# 解析命令签名，注解挪进 TYPE_CHECKING 块会让 ``v3 --help`` 直接 NameError（已实测）。
# 另外 `v3 citations` 会真的构造 `Path`，所以它本来就是运行期依赖，不需要 TCH 豁免。
from pathlib import Path
from typing import Annotated, Any, Literal, NoReturn

import typer
from rich.console import Console
from rich.markup import escape
from rich.table import Table

from pdx import (
    ai_surface,
    analyze,
    assets,
    cache,
    candidate_coverage,
    citations,
    company_sectors,
    config,
    consumer_matrix,
    country_state,
    covgate,
    decision_report,
    decisions,
    defines,
    distribution,
    doc_tables,
    docgen,
    docs_mirror,
    engine_log,
    evidence,
    exe_strings,
    information_catalog,
    lockfile,
    observe,
    political_surface,
    situated,
    snapshot,
    tables_offline,
    tabular,
    unknowns,
    vanilla_index,
    verify,
)
from pdx import mods as mods_mod
from pdx.console import enable_utf8_stdio
from pdx.extract import extract_dir
from pdx.parser import TOLERATED_ERRORS, parse_file, parse_text
from pdx.situated import bindings as situated_bindings
from pdx.situated import domain_coverage as situated_domain_coverage
from pdx.situated import inventory as situated_inventory

# 必须在构造 Console 之前调用 —— 理由见 pdx/console.py 的模块文档：
# rich 替代不了编码兜底，GBK 重定向下它自己就会抛 UnicodeEncodeError。
enable_utf8_stdio()

console = Console()

#: 「检查未通过」——只有真跑了检查、且结论是不一致时才用。
EXIT_FAILED = 1
#: 「用法错误 / 前置条件缺失」——click 对未定义选项、缺参数也用这个码，
#: 我们把「产物不存在」「命名空间不存在」也归到这一类，保持口径一致。
EXIT_USAGE = 2
#: 「核对不了」——检查确实跑了，但**输入使结论不可得**（不是通过，也不是不通过）。
#:
#: 只有 ``crosscheck`` 用它，且只用在一种情形上：引擎日志核对的那个文件
#: 被 mod 覆盖、覆盖版与原版**不是同一套行号**（行数不同）⇒ 「token 在不在
#: 那一行」这个问题本身无从回答。口径同 ``unverifiable_files`` 的 docstring：
#: 判据是可测事实（行数），不看「我们认不认识那个 mod」。
#:
#: ⚠️ 不许把它读成「软化的红」：真错配（行号可比、token 就在别的行）仍然走
#: :data:`EXIT_FAILED`。这一族教训见历史审计 B85 ——
#: 「我们在 error.log 里没看到」曾被当成「没有」，把「核不了」写成了「对不上」。
EXIT_UNVERIFIABLE = 3

app = typer.Typer(
    name="v3",
    help="Victoria 3 mod 开发研究工具链：全量分析、defines 提取、断言核对与产物核验。",
    # typer 默认会为 `--install-completion` 生成补全脚本并写进用户目录
    # （~/.bash_completion 等）。工具链不该在用户不知情时接管家目录，
    # 因此关掉 —— 代价是没有 shell 补全，换来的是「装包不留痕」。
    add_completion=False,
    no_args_is_help=True,
)

situated_app = typer.Typer(
    help="处境行动内核的静态审计、报告和解释。",
    no_args_is_help=True,
)
app.add_typer(situated_app, name="situated")


# ── 公共辅助 ────────────────────────────────────────────────
#: 读取已落盘产物时**可预期**的失败集合。
#:
#: 由「文件读不了」（:data:`pdx.parser.TOLERATED_ERRORS`，与解析器同一套
#: 口径）加「JSON 本身坏了」组成。刻意不含 ``Exception``：那会把代码 bug
#: （属性名打错、类型不符）降级成「产物缺失」，是最难查的一类问题 ——
#: 它让错误静默地变成合法输出。
_READ_ERRORS: tuple[type[BaseException], ...] = (
    *TOLERATED_ERRORS,
    json.JSONDecodeError,
    snapshot.SnapshotFormatError,
)


def _fail(message: str, code: int = EXIT_USAGE) -> NoReturn:
    """报错并终止。默认退出码 2（前置条件缺失），见模块文档。"""
    console.print(f"[red]{escape(message)}[/]")
    raise typer.Exit(code)


#: token 断言的判据（三态：匹配 / 真错配 / 不可核对）**不在这里** ——
#: 它是 :meth:`pdx.engine_log.CrossCheckReport.token_verdicts` 的职责，本命令只**消费**。
#:
#: ⚠️ 曾经这里有一个 ``_judge_token_line`` 自己拿 ``line_counts`` 再判一遍（2026-09-28
#: 定、同日收口时删掉）：那就有两套判据，同一份输入两个结论 —— 生效文件整份缺失时
#: 模块判「不可核对」，而命令层因为 ``line_counts.get(rel, (0, 0))`` 两值相等判「真错配」。
#: 判据只能有一处；删掉之后的复现命令与本轮口径修正的来龙去脉见
#: 用户提供日志后的分类只写入 `tools/out/`，不把运行期推断混入当前规则。


def _relative(path: Path) -> str:
    """优先显示仓库相对路径，不在仓库内时退回绝对路径。

    不能照抄 ``run_analyze.py`` 的 ``p.relative_to(Path.cwd())``：只要不是
    从仓库根运行就抛 ValueError。``v3`` 是装进 PATH 的命令，从任何目录调用
    都合理，因此基准换成仓库根 ``config.REPO``，并保留兜底。
    """
    try:
        return str(path.relative_to(config.REPO))
    except ValueError:
        return str(path)


def _require_game() -> None:
    """前置条件：游戏安装目录必须存在。

    缺了就退出码 2，而不是让它一路跑出满屏的「0 个文件」—— 后者看起来像
    「分析成功但游戏里没内容」，是最容易被误信的失败形态。
    """
    if not config.GAME.is_dir():
        _fail(f"找不到游戏目录 {config.GAME}（可用环境变量 V3_ROOT 指定）")


def _require_file(path: Path, what: str, hint: str = "") -> None:
    """前置条件：某个输入文件必须存在。"""
    if not path.is_file():
        suffix = f"（{hint}）" if hint else ""
        _fail(f"{what}不存在：{path}{suffix}")


def _load_product(path: Path, label: str) -> Any:
    """读一份已落盘的分析产物。

    两种失败都算前置条件缺失：文件不在（还没跑过 analyze），或文件在但读不
    出来（截断、写坏、根本不是 JSON）。都以退出码 2 终止并说明原因。
    """
    if not path.is_file():
        _fail(f"缺少产物：{_relative(path)}（请先运行 `v3 analyze` 生成{label}）")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except _READ_ERRORS as exc:
        _fail(f"产物无法读取：{_relative(path)}（{type(exc).__name__}: {exc}）")
    if not isinstance(data, dict):
        _fail(f"产物结构异常：{_relative(path)}（顶层应为对象，实为 {type(data).__name__}）")
    return data


def _write_json(path: Path, payload: Any) -> None:
    """写 JSON 并回报字节数。失败即终止，绝不「写了但没说」。"""
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8", newline="\n"
        )
    except OSError as exc:
        _fail(f"无法写入 {path}：{type(exc).__name__}: {exc}")
    console.print(f"[green]已写入[/] {escape(_relative(path))}  ({path.stat().st_size:,} 字节)")


def _describe(value: object) -> tuple[str, str]:
    """把一个 JSON 值描述成「类型 + 规模」。标量直接给值，长值截断。"""
    if isinstance(value, dict):
        return "字典", f"{len(value):,} 个键"
    if isinstance(value, list):
        return "列表", f"{len(value):,} 项"
    text = str(value)
    return type(value).__name__, text if len(text) <= 60 else f"{text[:59]}…"


def _structure_table(title: str, data: Any) -> Table:
    """把一层 JSON 对象的字段结构渲染成表格。"""
    table = Table(title=title or None, show_lines=False)
    table.add_column("字段")
    table.add_column("类型", style="dim")
    table.add_column("规模", justify="right", style="cyan")
    for key, value in data.items():
        kind, scale = _describe(value)
        table.add_row(escape(str(key)), kind, escape(scale))
    return table


def _size_text(path: Path) -> str:
    """文件大小的可读形式。文件不在就返回破折号 —— 表里不能因此缺行。"""
    if not path.is_file():
        return "—"
    n = path.stat().st_size
    return f"{n / 1048576:.2f} MB" if n > 1048576 else f"{n / 1024:.0f} KB"


# ── analyze ─────────────────────────────────────────────────
def _profile_run(
    *, with_mods: bool, with_cross: bool
) -> tuple[analyze.GameAnalysis, analyze.ModsAnalysis, analyze.CrossAnalysis, Any]:
    """用 pyinstrument 包住整个分析流程。

    pyinstrument 给的是**调用树**而不是我自己分段的粗粒度计时 —— 能直接
    看到时间花在哪个函数上，比手工埋点精确得多。

    ``--profile`` 下同样尊重 ``--no-mods`` / ``--no-cross``：旧脚本在剖析
    分支里漏判了 ``--no-cross``，两条路径的口径不该有差别。
    """
    # pyinstrument 是 dev 依赖。顶层导入会让没装 dev extras 的环境连
    # `v3 --help` 都跑不起来，所以只在这里按需导入。
    try:
        from pyinstrument import Profiler  # noqa: PLC0415
    except ImportError as exc:
        _fail(f'--profile 需要 pyinstrument，请先 pip install -e ".[dev]"：{exc}')

    profiler = Profiler(interval=0.001)
    profiler.start()

    ga = analyze.game_analysis()
    ma = analyze.ModsAnalysis()
    ca = analyze.CrossAnalysis()
    if with_mods:
        ma = analyze.mods_analysis()
        if with_cross:
            ca = analyze.cross_analysis(ma, verbose=False)

    profiler.stop()
    return ga, ma, ca, profiler


@app.command("analyze")
def analyze_cmd(
    mods: Annotated[
        bool, typer.Option("--mods/--no-mods", help="分析全部 mod（关闭则只看游戏本体）")
    ] = True,
    cross: Annotated[
        bool, typer.Option("--cross/--no-cross", help="做 mod 与原版的交叉分析")
    ] = True,
    write: Annotated[
        bool, typer.Option("--write/--no-write", help="把 JSON 与 Markdown 落盘")
    ] = True,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="不打印进度")] = False,
    profile: Annotated[
        bool, typer.Option("--profile", help="用 pyinstrument 输出调用树剖析")
    ] = False,
) -> None:
    """全量分析游戏本体与全部 mod。

    三段流水线默认全做：游戏本体 → mod → 交叉分析。--no-mods 只分析游戏
    本体；--no-cross 保留 mod 分析但不做覆盖关系交叉。--profile 用
    pyinstrument 输出调用树（仍然落盘），--quiet 关掉进度行。
    """
    _require_game()
    started = time.perf_counter()

    if profile:
        ga, ma, ca, profiler = _profile_run(with_mods=mods, with_cross=cross)
        elapsed = time.perf_counter() - started
        console.print()
        # 剖析结果是预格式化文本：关掉 markup/highlight/折行，免得被 rich 重排。
        console.print(
            profiler.output_text(unicode=True, color=False, show_all=False),
            markup=False,
            highlight=False,
            soft_wrap=True,
        )
    else:
        if not quiet:
            console.print("[cyan]▶ 分析游戏本体 …[/]")
        ga = analyze.game_analysis()
        ma = analyze.ModsAnalysis()
        ca = analyze.CrossAnalysis()

        if mods:
            if not quiet:
                console.print("[cyan]▶ 分析 mod …[/]")
            ma = analyze.mods_analysis()

        if mods and cross:
            if not quiet:
                console.print("[cyan]▶ 交叉分析 …[/]")
            ca = analyze.cross_analysis(ma, verbose=False)

        elapsed = time.perf_counter() - started

    if write:
        paths = analyze.write_reports(ga, ma, ca)
        table = Table(title="产出", show_lines=False)
        table.add_column("类型")
        table.add_column("文件", style="cyan")
        table.add_column("字节", justify="right")
        for name, path in paths.items():
            table.add_row(escape(name), escape(_relative(path)), f"{path.stat().st_size:,}")
        console.print(table)

    console.print(f"\n总耗时 {elapsed:.1f} 秒")


@app.command("information-catalog")
def information_catalog_cmd(
    output: Annotated[
        Path | None,
        typer.Option("--output", help="能力目录 JSON 输出路径；默认写入 tools/out/game/"),
    ] = None,
    localization: Annotated[
        bool,
        typer.Option(
            "--localization/--no-localization",
            help="是否登记本体本地化文件入口并生成键级目录",
        ),
    ] = True,
    localization_keys_output: Annotated[
        Path | None,
        typer.Option(
            "--localization-keys-output",
            help="键级本地化 JSONL 输出路径；默认与主目录一起写入 tools/out/game/",
        ),
    ] = None,
    consumer_matrix_output: Annotated[
        Path | None,
        typer.Option(
            "--consumer-matrix-output",
            help="静态同名候选关联矩阵 JSON；不表示运行时消费者已接通",
        ),
    ] = None,
    candidate_metadata: Annotated[
        Path | None,
        typer.Option(
            "--candidate-metadata",
            help="读取实际 integrated 候选合同；启动器 descriptor metadata 不含此合同",
        ),
    ] = None,
    candidate_production: Annotated[
        bool,
        typer.Option(
            "--candidate-production",
            help="从当前生产源生成 integrated 合同并连接，不手工导出候选 metadata",
        ),
    ] = False,
    candidate_coverage_output: Annotated[
        Path | None,
        typer.Option("--candidate-coverage-output", help="候选规则与目录的精确连接和未覆盖差集"),
    ] = None,
    candidate_dispositions_output: Annotated[
        Path | None,
        typer.Option(
            "--candidate-dispositions-output", help="每条目录信息的静态处置 JSONL/JSONL.GZ"
        ),
    ] = None,
) -> None:
    """生成锁定游戏版本的静态信息与消费者目录。

    该命令只声明静态发现及原版文件中的同名候选关联；
    运行时读取、行为质量和实机验证由用户在标准包上推进；本命令只登记静态能力，
    后续按权威实施计划逐步核对；静态登记不等于运行期行为通过。
    """

    if candidate_metadata is not None and candidate_production:
        console.print("[red]--candidate-metadata 与 --candidate-production 只能选一个[/]")
        raise typer.Exit(EXIT_USAGE)
    has_candidate = candidate_metadata is not None or candidate_production
    if candidate_coverage_output is not None and not has_candidate:
        console.print(
            "[red]--candidate-coverage-output 需要 --candidate-metadata 或 --candidate-production[/]"
        )
        raise typer.Exit(EXIT_USAGE)
    if candidate_dispositions_output is not None and not has_candidate:
        console.print(
            "[red]--candidate-dispositions-output 需要 --candidate-metadata 或 --candidate-production[/]"
        )
        raise typer.Exit(EXIT_USAGE)
    target = output or (config.OUT_GAME / "information-catalog.json")
    matrix_target = consumer_matrix_output or (config.OUT_GAME / "consumer-matrix.json")
    coverage_target = candidate_coverage_output or target.with_name("candidate-coverage.json")
    dispositions_target = candidate_dispositions_output or target.with_name(
        "candidate-dispositions.jsonl.gz"
    )
    disposition_stem = dispositions_target.name.removesuffix(".jsonl.gz").removesuffix(".jsonl")
    disposition_summary_target = dispositions_target.with_name(f"{disposition_stem}-summary.json")
    localization_target = localization_keys_output or (
        config.OUT_GAME / "information-localization.jsonl"
    )
    output_paths = [target, matrix_target]
    if has_candidate:
        output_paths.extend((coverage_target, dispositions_target, disposition_summary_target))
    if localization:
        output_paths.append(localization_target)
    resolved = [path.resolve() for path in output_paths]
    if len(set(resolved)) != len(resolved) or (
        candidate_metadata is not None and candidate_metadata.resolve() in resolved
    ):
        console.print("[red]各输出路径和候选输入路径必须互不相同[/]")
        raise typer.Exit(EXIT_USAGE)
    metadata = None
    metadata_origin: Literal["caller_supplied", "current_production_sources"] = (
        "current_production_sources" if candidate_production else "caller_supplied"
    )
    if candidate_metadata is not None:
        try:
            metadata = json.loads(candidate_metadata.read_text(encoding="utf-8"))
            if not isinstance(metadata, dict):
                raise ValueError("候选清单必须为 JSON 对象")
        except (OSError, ValueError) as exc:
            console.print(f"[red]候选清单不可读：{escape(str(exc))}[/]")
            raise typer.Exit(EXIT_USAGE) from exc
    elif candidate_production:
        try:
            _, _, production_files = distribution.package_inputs(include_engineering_metadata=True)
            metadata_text = production_files.get(".metadata/metadata.json")
            if metadata_text is None:
                raise ValueError("生产候选缺少 integrated metadata")
            metadata = json.loads(metadata_text)
            if not isinstance(metadata, dict):
                raise ValueError("生产候选合同必须为 JSON 对象")
        except (KeyError, OSError, ValueError) as exc:
            console.print(f"[red]当前生产候选合同不可用：{escape(str(exc))}[/]")
            raise typer.Exit(EXIT_USAGE) from exc
    _require_game()
    started = time.perf_counter()
    catalog = information_catalog.build(include_localization=localization)
    if metadata is not None:
        try:
            coverage_report = candidate_coverage.build(
                catalog, metadata, metadata_origin=metadata_origin
            )
            try:
                catalog_artifact = target.resolve().relative_to(config.REPO.resolve()).as_posix()
            except ValueError:
                catalog_artifact = target.name
            try:
                disposition_summary = candidate_coverage.write_dispositions(
                    catalog,
                    coverage_report,
                    dispositions_target,
                    catalog_artifact=catalog_artifact,
                )
            except OSError as exc:
                _fail(
                    f"无法写入 {dispositions_target}：{type(exc).__name__}: {exc}",
                    EXIT_FAILED,
                )
        except ValueError as exc:
            console.print(
                f"[red]候选连接失败：{escape(str(exc))}[/]；本次未写入报告，已有文件仅属于先前运行"
            )
            raise typer.Exit(EXIT_USAGE) from exc
        _write_json(coverage_target, coverage_report)
        _write_json(disposition_summary_target, disposition_summary)
        console.print(
            f"候选连接已生成：{_relative(coverage_target)}，"
            f"{len(coverage_report['links'])} 条规则连接，"
            f"{len(coverage_report['unresolved'])} 条未解决连接；不提升证据等级"
        )
        console.print(
            f"信息处置清单已生成：{_relative(dispositions_target)}，"
            f"{disposition_summary['item_count']} 条；摘要："
            f"{_relative(disposition_summary_target)}"
        )
    catalog.write(target)
    consumer_matrix.ConsumerMatrix.from_catalog(catalog).write(matrix_target)
    localization_stats: dict[str, int] | None = None
    if localization:
        localization_stats = information_catalog.write_localization_catalog(localization_target)
    elapsed = time.perf_counter() - started
    console.print(
        f"[green]能力目录已生成[/] {_relative(target)}："
        f"{len(catalog.items):,} 条，耗时 {elapsed:.1f} 秒"
    )
    if localization_stats is not None:
        console.print(
            f"键级本地化目录已生成：{localization_stats['files']:,} 个文件，"
            f"{localization_stats['keys']:,} 个键，"
            f"{localization_stats['errors']:,} 个 unsupported 记录"
        )
    console.print(f"静态消费者矩阵已生成：{_relative(matrix_target)}")
    console.print(
        "静态发现不等于运行时可读或行为通过；未确认项保持 discovered/unknown，"
        "候选连接只证明静态合同映射；后续阶段按权威实施计划推进。"
    )


# ── defines ─────────────────────────────────────────────────
@app.command("defines")
def defines_cmd(
    ns: Annotated[
        str | None,
        typer.Option("--ns", metavar="NAME", help="展开该命名空间的全部参数"),
    ] = None,
    json_out: Annotated[
        Path | None, typer.Option("--json", help="把提取结果写入该 JSON 文件")
    ] = None,
    overlay: Annotated[
        Path | None,
        typer.Option("--overlay", help="预览该 mod defines 文件会覆盖哪些原版参数"),
    ] = None,
) -> None:
    """提取 defines 的命名空间与参数（游戏层 + Jomini 层）。

    默认只打摘要。--ns NAI 展开某个命名空间（即旧脚本的 --ai）；
    --overlay 预览一段 mod defines 的覆盖与新增范围；--json 落盘完整结构。
    命名空间不存在时退出码为 2 —— 旧脚本返回 1，与「检查未通过」撞车。

    > 早先这里还有一个 ``--tables``，用来重算 doc 05 的统计表。
    > 它已并入 **``v3 tables``** —— 那个命令同时覆盖 doc 05 与 doc 19，
    > 而且**默认就是核对**（不一致即退出码 1），因此能进 CI。
    """
    _require_game()

    reports = defines.extract_all_defines()
    game = reports["game"]

    table = Table(title="defines 提取", show_lines=False)
    table.add_column("来源")
    table.add_column("涉及文件", justify="right")
    table.add_column("命名空间块", justify="right")
    table.add_column("去重命名空间", justify="right")
    table.add_column("参数", justify="right", style="cyan")
    table.add_column("@变量", justify="right")
    for label, report in reports.items():
        summary = report.summary()
        table.add_row(
            escape(label),
            f"{summary['涉及文件']:,}",
            f"{summary['命名空间块数']:,}",
            f"{summary['去重命名空间']:,}",
            f"{summary['参数总数']:,}",
            f"{summary['@变量数']:,}",
        )
    console.print(table)

    # 直接读 namespace_files 而不是 summary()["跨文件重复的命名空间"]：
    # 后者的静态类型是 object，用它就得 cast 或绕过类型检查。
    duplicates = {name: files for name, files in game.namespace_files.items() if len(files) > 1}
    if duplicates:
        dup_table = Table(
            title="跨文件重复的命名空间（引擎按块名合并的直接证据）", show_lines=False
        )
        dup_table.add_column("命名空间")
        dup_table.add_column("出现的文件", style="dim")
        for name, files in duplicates.items():
            dup_table.add_row(escape(name), escape(", ".join(files)))
        console.print(dup_table)

    if overlay is not None:
        _require_file(overlay, "overlay 文件")
        # overlay() 返回的是嵌套的杂类字典（静态类型只有 object），这里按
        # JSON 语义消费，故整体当作 Any 处理。
        preview: Any = defines.overlay(game, overlay.read_text(encoding="utf-8-sig"))
        preview_table = Table(
            title=f"覆盖预览：{preview['命名空间数']} 个命名空间", show_lines=False
        )
        preview_table.add_column("状态")
        preview_table.add_column("命名空间")
        preview_table.add_column("覆盖参数", justify="right", style="cyan")
        preview_table.add_column("新增参数", justify="right", style="green")
        preview_table.add_column("样例（各取前 8 个）", style="dim")
        for item in preview["明细"]:
            covered = list(item.get("覆盖参数") or [])
            added = list(item.get("新增参数") or [])
            sample = ", ".join([*covered[:8], *added[:8]])
            preview_table.add_row(
                escape(str(item["状态"])),
                escape(str(item["命名空间"])),
                f"{len(covered):,}",
                f"{len(added):,}",
                escape(sample) or "—",
            )
        console.print(preview_table)

    if ns:
        hits = game.get(ns)
        if not hits:
            _fail(f"未找到命名空间 {ns}")
        for hit in hits:
            console.rule(f"{hit.name}  ({hit.file}:{hit.line})  {hit.count} 个参数")
            params = Table(show_header=True, header_style="bold", show_lines=False)
            params.add_column("参数")
            params.add_column("形态", style="dim")
            params.add_column("值", style="cyan")
            for param in hit.params:
                if param.kind == defines.SCALAR:
                    params.add_row(escape(param.name), "", escape(param.value))
                else:
                    params.add_row(escape(param.name), escape(param.kind), f"×{param.elements}")
            console.print(params)

    if json_out is not None:
        _write_json(
            json_out,
            {
                label: {
                    "概览": report.summary(),
                    "命名空间": [n.to_dict() for n in report.namespaces],
                    "@变量": [
                        {"名称": name, "值": value, "行": line}
                        for name, value, line in report.variables
                    ],
                }
                for label, report in reports.items()
            },
        )


# ── index ───────────────────────────────────────────────────
#: 全量键名索引的落点。由 `v3 index` 重新生成。
OUT_INDEX_DOC = config.DOCS / "13-common全量键名索引.md"


def _build_index_doc() -> tuple[str, dict[str, int]]:
    """生成键名索引正文与统计。

    口径由 :mod:`pdx` 包保证（BOM 剥离、引号感知注释、花括号深度判定、
    连字符键名）—— 这正是它取代早期 PowerShell 正则版的理由。
    """
    common = config.GAME / "common"
    dirs = sorted(p for p in common.iterdir() if p.is_dir())

    rows: list[str] = []
    total_entries = 0
    total_files = 0

    for directory in dirs:
        result = extract_dir(directory)
        keys = sorted(result.entries)
        total_entries += len(keys)
        total_files += result.files

        md = ", ".join(sorted(p.name for p in directory.glob("*.md")))
        sample = ", ".join(keys[:6]) if keys else "—"
        rows.append(
            f"| `{directory.name}` | {result.files} | {len(keys)} | {md or '—'} | {sample} |"
        )

    # `common\` 根下散装的 .txt（实测只有 achievement_groups.txt 一个）。
    # 它们不属于任何子目录，所以逐目录表覆盖不到 —— 但**必须收录**，
    # 否则「全量键名索引」名不副实（那些键在正文里一处都查不到）。
    # 同时把「子目录合计」与「全树合计」的差额写进文档，免得
    # 「本索引 3,025 个文件」与「common 全树 3,026 个 .txt」被当成矛盾。
    loose_files = sorted(common.glob("*.txt"))
    loose_rows: list[str] = []
    for path in loose_files:
        keys = sorted(parse_file(path).top_keys)
        total_entries += len(keys)
        loose_rows.append(
            f"| `{path.name}` | {len(keys)} | {', '.join(f'`{k}`' for k in keys) or '—'} |"
        )
    all_txt = total_files + len(loose_files)

    stats = {
        "目录数": len(dirs),
        "文件总数": total_files,
        "条目总数": total_entries,
    }

    tail = ""
    if loose_rows:
        tail = (
            f"\n## `common\\` 根下的散装文件（{len(loose_files)} 个）\n\n"
            "这些 `.txt` 不在任何子目录里，上面的逐目录表覆盖不到，单独列出：\n\n"
            "| 文件 | 顶层条目 | 顶层键 |\n|---|---:|---|\n" + "\n".join(loose_rows) + "\n"
            "\n> 键名重复是**如实反映**，不是 bug：PDX 允许同级重复键，"
            "而 `parse_file(...).top_keys` 如实返回全部出现。\n"
        )

    head = f"""# 13 · common 全量键名索引

> 对 `game\\common\\` 下**全部 {len(dirs)} 个子目录** + 根下 **{len(loose_files)} 个散装 `.txt`**
> 做机械提取，共 **{total_entries:,} 个顶层条目**。
> 本文回答「**什么东西定义在哪个目录**」。

> 数据版本：Victoria 3 `{config.game_version().get("caligula_branch", "?")}`
> （`caligula_rev = {config.game_version().get("caligula_rev", "?")[:12]}…`）。
> 本文**每次运行 `v3 index` 都会整体重新生成**，因此其中的数字始终对应当前安装，
> 不存在「文档数字过期」的问题 —— 这也是它与其他主题文档的区别。

## 提取口径

本索引由 `v3 index` 生成（实现见 `src/pdx/cli.py`），口径如下：

```text
顶层判定   花括号深度 == 0，**与缩进无关**
编码       utf-8-sig，自动剥离 BOM
注释       引号感知地剥离 # 到行尾（在花括号计数之前）
键名字符集  非空白、非花括号、非等号、非引号（因此支持连字符）
@变量      不计入条目
```

**逐目录统计 + 根下散装文件**：本索引按 `common\\` 的 {len(dirs)} 个子目录逐个提取，
合计 **{total_files:,} 个文件**；`common\\` 根下另有 **{len(loose_files)} 个散装 `.txt`**
（{", ".join(p.name for p in loose_files) or "无"}）不在任何子目录里，列在本文末尾。
所以「本索引 {total_files:,} 个文件」与「`common` 全树 {all_txt:,} 个 `.txt`」
差的就是这 {len(loose_files)} 个 —— 两者都对，只是口径不同，**不要为了对齐而互相改**。

## 勘误记录

### 勘误 1：早期版本漏计含连字符的键

早期版本用**枚举字符类**匹配键名，静默漏掉了含连字符 `-` 的键。
全库共 **32 个**，分布在 4 个目录：

| 目录 | 含连字符键数 | 修正前 | 修正后 |
|---|---:|---:|---:|
| `character_templates` | 27 | 1,983 | **2,011** |
| `production_methods` | 3 | 433 | **436** |
| `technology` | 1 | 183 | **184** |
| `power_bloc_names` | 1 | 199 | **200** |

### 勘误 2：早期版本漏计文件首键（BOM）与缩进的顶层键

`common` 下 {all_txt:,} 个 `.txt` 中 **3,002 个带 UTF-8 BOM**，且部分文件的顶层键**带前导空格**。
用「行首无缩进」判定顶层的做法会漏掉它们。实测 `static_modifiers` 因此少算 7 个：

| 目录 | 修正前 | 修正后 |
|---|---:|---:|
| `static_modifiers` | 6,121 | **6,128** |

### 勘误 3：`.txt` 文件数曾用非递归统计

5 个含子目录的目录受影响：`history` 0→1152、`coat_of_arms` 0→23、
`technology` 0→4、`defines` 6→9、`terrain_manipulators` 1→2。

> **三条勘误的共同教训**：解析 PDX 数据不要假设字符集、不要假设文件平铺、
> 不要用缩进判断结构。全部改用花括号深度 + `utf-8-sig` + 取反字符组。

## 全部 {len(dirs)} 个目录

| 目录 | .txt 文件 | 顶层条目 | 官方文档 | 条目示例（前 6 个） |
|---|---:|---:|---|---|
"""
    return head + "\n".join(rows) + "\n" + tail, stats


@app.command("index")
def index_cmd(
    dry_run: Annotated[bool, typer.Option("--dry-run", help="只打印统计，不写文件")] = False,
) -> None:
    """重新生成 docs/victoria3-modding/13-common全量键名索引.md。

    取代早期用 PowerShell 正则生成的那一版：本版由 pdx 包驱动，因此自动
    获得 BOM 剥离、引号感知注释、花括号深度判定与连字符键名支持。
    """
    _require_game()
    text, stats = _build_index_doc()

    table = Table(title="键名索引统计", show_lines=False)
    table.add_column("项目")
    table.add_column("数值", justify="right", style="cyan")
    for key, value in stats.items():
        table.add_row(escape(key), f"{value:,}")
    console.print(table)

    if dry_run:
        console.print("[yellow]--dry-run：未写文件[/]")
        return

    try:
        # newline="\n"：见 analyze.dump 的注释 —— 否则文档在 Windows 上写成
        # CRLF，与 .gitattributes 的 eol=lf 打架，每次 `v3 index` 都弄脏工作树。
        OUT_INDEX_DOC.write_text(text, encoding="utf-8", newline="\n")
    except OSError as exc:
        _fail(f"无法写入 {OUT_INDEX_DOC}：{type(exc).__name__}: {exc}")
    console.print(
        f"[green]已写入[/] {escape(_relative(OUT_INDEX_DOC))}  "
        f"行数 {len(text.splitlines()):,}  字节 {OUT_INDEX_DOC.stat().st_size:,}"
    )


# ── snapshot ────────────────────────────────────────────────
snapshot_app = typer.Typer(
    help="游戏版本快照：捕获某个版本的全部 mod 相关信息，Paradox 增删字段时一次 diff 就能全部发现。",
    add_completion=False,
    no_args_is_help=True,
)
app.add_typer(snapshot_app, name="snapshot")


def _load_snapshot(path: Path) -> snapshot.Snapshot:
    """读快照。文件损坏属前置条件缺失，退出码 2。"""
    try:
        return snapshot.Snapshot.load(path)
    except _READ_ERRORS as exc:
        _fail(f"快照无法读取：{_relative(path)}（{type(exc).__name__}: {exc}）")


def _snapshot_output_path(target: str, *, compact: bool) -> Path:
    """返回创建命令的明确输出路径，不走读取时的回退规则。"""
    suffix = ".compact.json" if compact else ".json"
    return snapshot.SNAPSHOT_DIR / f"{target}{suffix}"


@snapshot_app.command("create")
def snap_create(
    label: Annotated[str | None, typer.Option("--label", help="快照名（默认为游戏版本号）")] = None,
    compact: Annotated[
        bool,
        typer.Option("--compact", help="精简模式：本地化只留计数与指纹，可入库"),
    ] = False,
) -> None:
    """生成当前版本快照，写入 tools/out/snapshots/。

    默认生成完整快照，供本机分析使用。``--compact`` 保留结构域，
    将本地化条目压缩为计数与指纹，便于随仓库分发和比较版本变化。
    实际体积和条目数取决于当前游戏版本，以生成结果为准。
    """
    _require_game()
    snap = snapshot.build(compact=compact, verbose=True)
    target = label or snap.version_label.replace("/", "-")
    # 创建命令必须显式选择输出口径；snapshot_path() 为读取场景提供
    # 完整→精简回退，不能用于写入，否则完整快照会覆盖同名 .compact.json。
    path = _snapshot_output_path(target, compact=compact)
    snap.write(path)

    counts = snap.counts()
    console.print(f"[green]已写入[/] {escape(_relative(path))}")
    console.print(
        f"域 {len(snap.sections)} 个，条目总计 {sum(counts.values()):,}，"
        f"字节 {path.stat().st_size:,}"
    )

    table = Table(show_lines=False)
    table.add_column("域")
    table.add_column("项", justify="right")
    table.add_column("条目", justify="right", style="cyan")
    for section, body in snap.sections.items():
        table.add_row(
            escape(section),
            f"{len(body):,}",
            f"{sum(len(names) for names in body.values()):,}",
        )
    console.print(table)


@snapshot_app.command("list")
def snap_list() -> None:
    """列出已有快照及其规模。"""
    paths = snapshot.list_snapshots()
    if not paths:
        console.print("[yellow]尚无快照。先运行 `v3 snapshot create`。[/]")
        return

    table = Table(title=f"共 {len(paths)} 份快照", show_lines=False)
    table.add_column("快照")
    table.add_column("版本")
    table.add_column("条目", justify="right", style="cyan")
    table.add_column("字节", justify="right")
    for path in paths:
        # 单份快照读不了不该让整个列表失败（旧脚本也是这样），但必须把
        # 异常类型与消息打出来，而不是显示成一个空行。
        try:
            snap = snapshot.Snapshot.load(path)
        except _READ_ERRORS as exc:
            table.add_row(
                escape(path.name),
                "[red]读取失败[/]",
                "—",
                escape(f"{type(exc).__name__}: {exc}"),
            )
            continue
        total = sum(len(names) for body in snap.sections.values() for names in body.values())
        table.add_row(
            escape(path.name),
            escape(snap.version_label),
            f"{total:,}",
            f"{path.stat().st_size:,}",
        )
    console.print(table)


@snapshot_app.command("diff")
def snap_diff(
    older: Annotated[str, typer.Argument(help="旧快照名（不含 .json）")],
    newer: Annotated[str, typer.Argument(help="新快照名")],
    detail: Annotated[bool, typer.Option("--detail", help="列出增删明细")] = False,
    json_out: Annotated[Path | None, typer.Option("--json", help="把差异写入该 JSON 文件")] = None,
) -> None:
    """比对两份快照，列出字段与条目的增删。

    检测到变更**不算失败**（退出码仍为 0）—— 变更是这个命令要报告的事实，
    不是错误。快照文件不存在时退出码 2。
    """
    a_path = snapshot.snapshot_path(older)
    b_path = snapshot.snapshot_path(newer)
    for path in (a_path, b_path):
        _require_file(path, "快照", "可用 `v3 snapshot list` 查看已有快照")

    a = _load_snapshot(a_path)
    b = _load_snapshot(b_path)

    if a.compact != b.compact:
        _fail("两份快照的精简口径不同：请使用两个完整快照，或使用两个 --compact 快照再比较。")

    console.rule(f"对比 {a.version_label}  →  {b.version_label}")
    console.print(
        f"A rev [dim]{escape(a.version.get('caligula_rev', '?'))}[/]    "
        f"B rev [dim]{escape(b.version.get('caligula_rev', '?'))}[/]"
    )

    changes = snapshot.compare(a, b)
    if not changes:
        console.print("[green]两份快照完全一致 —— 没有检测到任何字段增删。[/]")
        return

    # 域集合不同 = 两份快照不是**同一个口径**拍的（常见于拿入库的旧快照比新版：
    # 域是逐轮加上去的）。此时差异里混着「格式变化」，不能当成原版变化读 ——
    # 1.14.3 那份只有 6 个域（localization 存明细），1.14.4 有 14 个
    # （localization 换成 localization_digest + ai_surface/vocabulary 等），
    # 直接 diff 会报出 116 万条「删除」，而真正的原版变化只有几百处。
    only_a = sorted(set(a.sections) - set(b.sections))
    only_b = sorted(set(b.sections) - set(a.sections))
    if only_a or only_b:
        console.print(
            f"[yellow]⚠️ 两份快照的**域集合不同**[/] —— 下面的差异里混着格式变化，"
            f"别直接当成原版变化读。\n"
            f"   只有 A 有：{escape('、'.join(only_a) or '（无）')}\n"
            f"   只有 B 有：{escape('、'.join(only_b) or '（无）')}\n"
            f"   可比的是两侧都有的域：{escape('、'.join(sorted(set(a.sections) & set(b.sections))))}"
        )

    summary = snapshot.diff_summary(changes)
    table = Table(title="变更", show_lines=False)
    table.add_column("域")
    table.add_column("项")
    table.add_column("新增", justify="right", style="green")
    table.add_column("删除", justify="right", style="red")
    for change in changes:
        table.add_row(
            escape(change.section),
            escape(change.name),
            f"+{len(change.added)}" if change.added else "—",
            f"-{len(change.removed)}" if change.removed else "—",
        )
    console.print(table)
    console.print(
        f"变更项 {summary['变更项数']} 处，"
        f"新增条目 {summary['新增条目']}，删除条目 {summary['删除条目']}"
    )

    if detail:
        console.rule("明细")
        for change in changes:
            console.print(f"[bold]{escape(change.section)} / {escape(change.name)}[/]")
            for name in change.added:
                console.print(f"  [green]+ {escape(name)}[/]")
            for name in change.removed:
                console.print(f"  [red]- {escape(name)}[/]")

    if json_out is not None:
        _write_json(
            json_out,
            {
                "from": {"版本": a.version, "文件": a_path.name},
                "to": {"版本": b.version, "文件": b_path.name},
                "概览": summary,
                "变更": [
                    {
                        "域": change.section,
                        "名称": change.name,
                        "新增": change.added,
                        "删除": change.removed,
                    }
                    for change in changes
                ],
            },
        )


@snapshot_app.command("verify")
def snap_verify() -> None:
    """自我一致性检查：同一环境重复生成的快照必须逐字节相同。

    不稳定就退出码 1 —— 快照一抖，diff 里全是噪声，整个机制失去意义。
    """
    _require_game()
    console.print("构建快照两次并比较 …")
    first = snapshot.build()
    second = snapshot.build()
    da = json.dumps(first.to_dict(), ensure_ascii=False, indent=1, sort_keys=True)
    db = json.dumps(second.to_dict(), ensure_ascii=False, indent=1, sort_keys=True)

    if da == db:
        total = sum(len(names) for body in first.sections.values() for names in body.values())
        console.print("[green]✅ 两次构建结果完全一致 —— 快照是确定性的[/]")
        console.print(f"   域 {len(first.sections)} 个，条目总计 {total:,}")
        return

    console.print("[red]❌ 两次构建结果不同 —— 快照不稳定，diff 会充满噪声[/]")
    for change in snapshot.compare(first, second)[:20]:
        console.print(escape(change.line()))
    raise typer.Exit(EXIT_FAILED)


# ── mirror（官方文档清单与本地镜像）──────────────────────────
mirror_app = typer.Typer(help="官方 .md 的清单与本地镜像。", no_args_is_help=True)
app.add_typer(mirror_app, name="mirror")


@mirror_app.command("check")
def mirror_check() -> None:
    """核对清单：与本机游戏比对，并与本地镜像比对。

    **不修改任何文件**。有差异时退出码 1 —— 因此能当门禁。

    没有游戏（或没有本地镜像）时对应的那条**跳过而非判失败**：
    一条跑不了的检查不该把退出码弄脏，否则这个门禁在任何 CI 上都是红的。
    两条都跑不了才算「什么都没查成」，此时退出 2（前置条件缺失）—— 免得空过。
    """
    if not docs_mirror.load_manifest():
        _fail(f"读不到 {docs_mirror.MANIFEST_NAME} —— 先跑 `v3 mirror write`")

    checked = 0
    bad: list[str] = []

    if (config.GAME / "common").is_dir():
        checked += 1
        against_game = docs_mirror.diff_against_game()
        if against_game:
            console.rule("[red]清单与本机游戏不一致[/]")
            bad.extend(against_game)
        else:
            console.print("[green]清单与本机游戏完全一致[/]")
    else:
        console.print("[yellow]游戏目录不可用：跳过「清单 vs 本体」[/]")

    if config.OFFICIAL_DOCS_MIRROR.is_dir():
        checked += 1
        against_mirror = docs_mirror.diff_mirror()
        if against_mirror:
            console.rule("[red]本地镜像与清单不一致[/]")
            bad.extend(against_mirror)
        else:
            console.print("[green]本地镜像与清单完全一致[/]")
    else:
        console.print("[yellow]本地镜像不存在：跳过「清单 vs 镜像」[/]")

    for line in bad[:20]:
        console.print(f"[red]❌[/] {escape(line)}")
    if len(bad) > 20:
        console.print(f"[red]…还有 {len(bad) - 20} 条[/]")

    if bad:
        raise typer.Exit(EXIT_FAILED)
    if not checked:
        _fail("既没有游戏也没有本地镜像 —— 两条比对都没跑成")


@mirror_app.command("write")
def mirror_write(
    sync: Annotated[bool, typer.Option("--sync", help="顺便把本地镜像从游戏重拷一份")] = False,
) -> None:
    """重新生成清单（要游戏）；``--sync`` 同时重建本地镜像。

    清单入库（约 17 KB），镜像不入库（Paradox 版权内容）。
    见 :mod:`pdx.docs_mirror` 的模块文档 —— 那里也写明了
    「移出版本控制 ≠ 从历史里清除」这个限制。
    """
    _require_game()
    path = docs_mirror.write_manifest()
    data = docs_mirror.load_manifest()
    console.print(
        f"[green]已写入[/] {escape(_relative(path))}  "
        f"{data.get('篇数')} 篇，{path.stat().st_size:,} 字节"
    )

    if sync:
        root = config.OFFICIAL_DOCS_MIRROR
        copied = 0
        for key, src in docs_mirror.iter_docs():
            dst = root / key
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(docs_mirror.text_bytes(src.read_bytes().decode("utf-8-sig")))
            copied += 1
        console.print(f"[green]已同步本地镜像[/] {copied} 篇 → {escape(_relative(root))}")

    console.print(
        "[dim]清单里的字节/行数变了的话，记得同步 07-官方文档索引.md（v3 verify 会核对）[/]"
    )


# ── refresh（游戏升级后的一条命令维护）──────────────────────
@app.command("refresh")
def refresh_cmd(
    dry_run: Annotated[bool, typer.Option("--dry-run", help="只报告会改什么，不写盘")] = False,
) -> None:
    """**游戏升级后的一条命令**：重算生成表 + 按归属标记改写正文数字，再报剩下的红点。

    等价于 ``v3 tables --write`` + ``v3 verify --fix``，但按顺序做完再核一遍，
    把「机器能改的」一次改完，只把**机器改不了的**列出来给人：

    * 无标记的数字（数字不在正文里 / 在表格里 / 形态不同）；
    * 判断类内容（叙述、历史对照句 —— 登记在 ``PROSE_NOT_COMPUTED``）；
    * 断言失败（真值变了但口径也需要人看一眼的那几条）。

    为什么要有它：这两步原先要人记得按顺序跑，而**忘记跑 = 文档静默过期**，
    正是这个仓库反复踩的坑（doc 04 的 682 行活了整整一个版本、README 的
    164/226 停了两轮）。跑完退出码 0 表示全绿；否则 1，并列出剩余项。
    """
    console.rule("[bold]1/3 重算生成表[/]")
    if dry_run:
        try:
            table_drift = docgen.check_all()
        except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
            _fail(f"核对表格失败：{type(exc).__name__}: {exc}")
        if table_drift:
            console.print(f"  [yellow]--dry-run：{len(table_drift)} 行与生成结果不一致[/]")
            for doc, line, now, want in table_drift[:20]:
                console.print(f"  {escape(doc)}:{line} 现值 {escape(now)} → 生成值 {escape(want)}")
        else:
            console.print("  [green]生成表与文档一致，无需改写[/]")
    else:
        try:
            written = docgen.write_all()
        except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
            _fail(f"重算表格失败：{type(exc).__name__}: {exc}")
        rows = sum(written.values())
        console.print(f"  [green]重算 {len(written)} 张表 / {rows} 行[/]（内容没变的表不会改盘）")

    console.rule("[bold]2/3 按归属标记改写正文数字[/]")
    if dry_run:
        pending = verify.fix_markers(write=False)
        console.print(f"  [yellow]--dry-run：{len(pending)} 处需要改[/]")
        for item in pending[:20]:
            console.print(f"  {escape(item.describe())}")
    else:
        fixes = verify.fix_markers(write=True)
        if fixes:
            for item in fixes[:40]:
                console.print(f"  [cyan]{escape(item.describe())}[/]")
            console.print(f"  共改写 [bold]{len(fixes)}[/] 处")
        else:
            console.print("  [green]标记处的数字全都与断言一致[/]")

    console.rule("[bold]3/3 核验剩下的[/]")
    marker_issues = verify.check_markers()
    drift = verify.unknown_doc_drift()
    results = verify.run_claims(verify.CLAIMS, include_slow=True)
    failed = [r for r in results if not r.ok]
    console.print(
        f"  断言 {len(results) - len(failed)} / {len(results)} 通过"
        f" · 标记问题 {len(marker_issues)} · 正文漂移 {len(drift)}"
    )
    for issue in marker_issues[:10]:
        console.print(f"  [red]❌[/] {escape(issue.describe())}")
    for d in drift[:10]:
        console.print(f"  [red]❌[/] {escape(d.describe())}")
    for r in failed[:10]:
        console.print(
            f"  [red]❌[/] [{escape(r.claim.id)}] 期望 {escape(str(r.claim.expected))} 实得 {escape(str(r.actual))}"
        )
    if failed or drift or marker_issues:
        console.print(
            "[yellow]剩下的机器改不了[/] —— 上面每条都指到了具体行；"
            "判断类内容见 `test_inventory.PROSE_NOT_COMPUTED`。"
        )
        raise typer.Exit(EXIT_FAILED)
    console.print("[green]全部一致：表格、正文数字、断言。没有需要人改的东西。[/]")


# ── tables（文档里由工具生成的表格）──────────────────────────
@app.command("tables")
def tables_cmd(
    write: Annotated[bool, typer.Option("--write", help="重算并写回文档")] = False,
    offline: Annotated[
        bool,
        typer.Option(
            "--offline",
            help="不读游戏：拿**入库快照**里记录的表内容核对文档（CI 用；可配 --write）",
        ),
    ] = False,
    only: Annotated[str, typer.Option("--only", help="只处理文档名含该子串的目标")] = "",
) -> None:
    """重算文档里**由工具生成**的表格（doc 05 的 defines 表、doc 08 的目录统计表、
    doc 19 的根目录与路径表）。

    不带 ``--write`` 时是**核对**：逐行比对文档现值与生成结果，
    有任何不一致就退出码 1 —— 这样它能进 CI / pre-commit，
    而不是又一个「要记得手动跑」的脚本。

    为什么需要它：这些表原先由一批已退休的 PowerShell 脚本产出，
    之后再没人重跑过，于是 doc 05 的 5 张表**整整落后了一个游戏版本**
    （参数总数 3434 应当变 3488），doc 19 的根目录文件数也从 12 漂到 13。

    替换规则见 :mod:`pdx.doc_tables`：只动数据行，表头、分隔线与散文一律不碰；
    散文列与行的顺序按文档保留。

    **``--offline``**：算表要读游戏，CI 上没有游戏 —— 于是「表格被手改」
    一直没人守。快照里现在带着**每张表当时的数据行**，所以离线可以比对，
    也可以 ``--write`` 把表恢复成最后一次已知正确的样子。
    它证明的是「表与入库快照一致」，**不是**「表与现在的游戏一致」
    （后者仍是 `v3 refresh` 的活）。口径见 :mod:`pdx.tables_offline`。
    """
    if offline:
        _tables_offline(write=write, only=only)
        return
    if only:
        _fail("--only 只在 --offline 下有意义（在线核对是逐表与生成结果比对）")

    if write:
        try:
            done = docgen.write_all()
        except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
            _fail(f"重算表格失败：{type(exc).__name__}: {exc}")
        table = Table(title="已重算的表格", show_lines=False)
        table.add_column("文档 · 表")
        table.add_column("数据行", justify="right", style="cyan")
        for name, n in done.items():
            table.add_row(escape(name), str(n))
        console.print(table)
        return

    try:
        diff = docgen.check_all()
    except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
        _fail(f"核对表格失败：{type(exc).__name__}: {exc}")

    if not diff:
        console.print(
            f"[green]全部 {sum(len(t.specs) for t in docgen.targets())} 张生成表都与文档一致[/]"
        )
        return

    table = Table(title=f"{len(diff)} 行与生成结果不一致", show_lines=False)
    table.add_column("文档", style="dim")
    table.add_column("行", justify="right")
    table.add_column("文档现值", overflow="fold")
    table.add_column("生成值", overflow="fold")
    for doc_name, line_no, actual, expected in diff[:30]:
        table.add_row(escape(doc_name), str(line_no), escape(actual[:70]), escape(expected[:70]))
    console.print(table)
    console.print("[yellow]跑 `v3 tables --write` 可按生成结果修正[/]")
    raise typer.Exit(EXIT_FAILED)


def _tables_offline(*, write: bool, only: str) -> None:
    """``v3 tables --offline``：只读快照与文档，不读游戏。"""
    recorded = tables_offline.load_tables()
    if not recorded:
        _fail(
            "快照里没有生成表记录（域 doc_tables）—— 在装有游戏的机器上跑 "
            "`v3 snapshot create --compact` 重建一份（它是入库的）"
        )

    if write:
        try:
            done = tables_offline.restore(recorded, only=only)
        except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
            _fail(f"按快照恢复表格失败：{type(exc).__name__}: {exc}")
        if not done:
            console.print("[green]全部生成表都与快照记录一致，无需改动[/]")
            return
        table = Table(title=f"已按快照恢复 {len(done)} 张表", show_lines=False)
        table.add_column("表")
        table.add_column("数据行", justify="right", style="cyan")
        for key, n in sorted(done.items()):
            table.add_row(escape(key), str(n))
        console.print(table)
        return

    try:
        diffs, missing, orphans = tables_offline.compare(recorded, only=only)
    except (doc_tables.TableNotFoundError, doc_tables.TableMalformedError, OSError) as exc:
        _fail(f"离线核对表格失败：{type(exc).__name__}: {exc}")

    if diffs:
        table = Table(title=f"{len(diffs)} 行与快照记录不一致", show_lines=False)
        table.add_column("表", style="dim")
        table.add_column("行", justify="right")
        table.add_column("文档现值", overflow="fold")
        table.add_column("快照记录", overflow="fold")
        for d in diffs[:30]:
            table.add_row(
                escape(d.key), str(d.line), escape(d.actual[:60]), escape(d.expected[:60])
            )
        console.print(table)
        console.print("[yellow]跑 `v3 tables --offline --write` 可按快照恢复[/]")
        raise typer.Exit(EXIT_FAILED)

    covered = len(recorded) - len(orphans)
    console.print(f"[green]快照里记录的 {covered} 张生成表都与文档一致[/]")
    if missing:
        console.print(
            f"[yellow]另有 {len(missing)} 张登记在案的表不在快照里（多半是新增规格）—— "
            f"本机跑 `v3 refresh` 后重建快照即可：{escape(', '.join(missing[:5]))}"
            f"{' …' if len(missing) > 5 else ''}[/]"
        )
    if orphans:
        console.print(
            f"[yellow]快照里有 {len(orphans)} 张表已不在登记表里（规格被删或改名）："
            f"{escape(', '.join(orphans[:5]))}{' …' if len(orphans) > 5 else ''}[/]"
        )


# ── verify ──────────────────────────────────────────────────
def _verify_from_snapshot(*, claims: list[verify.Claim], only: str | None, no_drift: bool) -> None:
    """``v3 verify --from-snapshot``：不读游戏，用**入库的离线真值**核验。

    两份真值：精简快照（目录条目、defines、DLC 清单）与官方文档清单
    （94 篇 ``.md`` 的篇数与逐篇字节数）。后者是新加的 —— 官方文档那几条断言
    本来就不需要游戏，白丢在 CI 覆盖之外没有道理。

    抽成独立函数而不是塞在 ``verify_cmd`` 里，是为了让「无游戏也能跑」
    这条路径足够显眼 —— 它是 CI 上唯一能真正核对断言的入口。
    """
    snap = verify.latest_compact_snapshot()
    if snap is None:
        # 不再直接退出：官方文档清单是第二份离线真值，没有快照时它照样能核验。
        console.print(
            "[yellow]没有精简快照（tools/out/snapshots/*.compact.json）—— "
            "只核验官方文档清单那几条。在装有游戏的机器上跑 "
            "`v3 snapshot create --compact` 可补上一份（它是入库的）。[/]"
        )

    selected = [c for c in claims if not only or only in c.id]
    if only and not selected:
        _fail(f"没有 id 含 {only!r} 的断言（注册表共 {len(verify.CLAIMS)} 条）")

    results = verify.verify_from_snapshot(snap, selected)
    if not results:
        _fail(
            "没有任何断言能被离线真值覆盖 —— 检查 pdx.verify 的 "
            "_SNAPSHOT_GETTERS / _MANIFEST_GETTERS。"
            f"目前能覆盖的类型：{sorted(verify.snapshot_kinds())}"
        )

    table = Table(
        title=f"离线核验（{len(results)} 条，快照 {snap.version_label if snap else '无'}）",
        show_lines=False,
    )
    table.add_column("", width=2, justify="center")
    table.add_column("ID", style="dim")
    table.add_column("断言")
    table.add_column("快照", style="cyan")
    table.add_column("期望", justify="right")
    for r in results:
        table.add_row(
            "✅" if r.ok else "❌",
            escape(r.claim.id),
            escape(r.claim.text),
            escape(str(r.actual)),
            escape(str(r.claim.expected)),
        )
    console.print(table)

    failed = [r for r in results if not r.ok]
    covered = len(results)
    console.print(
        f"通过 {covered - len(failed)} / {covered}    失败 {len(failed)}"
        f"    [dim]（离线真值覆盖 {covered}/{len(verify.CLAIMS)} 条；"
        f"其余需读游戏本体，本地跑 v3 verify）[/]"
    )
    for r in failed:
        console.print(
            f"[red]❌[/] [{escape(r.claim.id)}] 期望 {escape(str(r.claim.expected))} "
            f"快照 {escape(str(r.actual))}  {escape(r.error)}"
        )

    drift = [] if no_drift else verify.unknown_doc_drift()
    if drift:
        console.rule("[red]文档正文与断言表脱节[/]")
        for d in drift:
            console.print(f"[red]❌[/] {escape(d.describe())}")
    elif not no_drift:
        console.print("[green]文档正文与断言表一致[/]")

    if failed or drift:
        raise typer.Exit(EXIT_FAILED)


@app.command("verify")
def verify_cmd(
    fast: Annotated[bool, typer.Option("--fast", help="跳过需要全库扫描的检查")] = False,
    json_out: Annotated[Path | None, typer.Option("--json", help="把结果写入该 JSON 文件")] = None,
    only: Annotated[str | None, typer.Option("--only", help="只跑 id 含该子串的断言")] = None,
    no_drift: Annotated[
        bool, typer.Option("--no-drift", help="跳过文档正文的数字漂移扫描")
    ] = False,
    unregistered: Annotated[
        bool, typer.Option("--unregistered", help="列出文档里**尚未登记**的数量断言后退出")
    ] = False,
    from_snapshot: Annotated[
        bool,
        typer.Option(
            "--from-snapshot",
            help="不读游戏，用**入库的离线真值**（精简快照 + 官方文档清单）核验（CI 用）",
        ),
    ] = False,
    fix: Annotated[
        bool,
        typer.Option("--fix", help="把带归属标记的数字改写成断言期望值（只改标记处，写盘）"),
    ] = False,
    fix_claims: Annotated[
        bool,
        typer.Option("--fix-claims", help="把**实测值**写回断言表的期望值（照单全收，写盘）"),
    ] = False,
) -> None:
    """核对知识库文档里的数量断言（游戏本体口径）。

    与 check-outputs 的分工：本命令查「游戏里到底有多少」，
    check-outputs 查「落盘的产物有没有写对」。两者共用同一份断言注册表
    ``verify.CLAIMS``，因此不可能再出现「脚本期望值与注册表冲突」那种
    结构性分歧。有断言失败时退出码为 1。

    **本命令同时跑文档正文的漂移扫描**（:func:`pdx.verify.find_doc_drift`）——
    断言表测对了不等于文档写对了：文档里可能仍躺着旧值，而断言表照样全绿。
    早在 T0 阶段这两者就号称共用一套逻辑，但 ``find_doc_drift`` 事实上一路
    只被测试调用，``v3 verify`` 从未跑过它，于是「工具报全绿、文档已过期」
    这个最要命的失效模式一直敞着。现在真的接上了（``--no-drift`` 可跳过）。

    ``--from-snapshot`` 是**给 CI 用的**：那里没有游戏，全部实测断言都会被
    跳过；入库精简快照里的 common 条目名、defines 命名空间与 DLC 清单只支持
    部分断言，实际覆盖范围以命令输出为准。它证明的是「断言注册表
    仍与当时记录的真值一致」，**不**证明「游戏里现在还是这个数」。

    **``--fix``**：正文里带归属标记的数字（``205<!--claim:dip.group_files-->``）
    会被改写成断言期望值。它只碰**带标记的那一个数字**，包裹（``**`` / 反引号）
    与空格原样保留，因此不是「猜着改文本」，而是「按归属改」。不带 ``--fix``
    时同一套逻辑只报告不改 —— 两者共用一条实现，免得「说会改 A、实际改了 B」。

    **``--fix-claims``**：官方更新之后用 —— 把**实测值**写回断言表
    ``CLAIMS`` 的期望值。它与 ``--fix`` 是**相反方向**的：``--fix`` 假定断言表
    是对的、改文档；``--fix-claims`` 假定实测是对的、改断言表。因此它照单全收，
    量错了就把错误一起写进闸门 —— 只该在"版本演练"里、且人逐条看过改动清单之后跑。
    ``--only`` 可以缩小到某几条（如 ``--only dip.``），改动清单永远逐条打印。
    """
    if fix_claims:
        _require_game()
        edits, skipped = verify.fix_claims(write=True, only=only or "")
        if not edits:
            console.print("[green]断言表与实测一致，无需改动[/]")
        else:
            table = Table(title=f"按实测改写 {len(edits)} 条断言", show_lines=False)
            table.add_column("ID", style="dim")
            table.add_column("旧期望", justify="right")
            table.add_column("新实测", justify="right", style="green")
            table.add_column("描述", overflow="fold")
            for edit in edits:
                table.add_row(
                    escape(edit.id),
                    escape(str(edit.old)),
                    escape(str(edit.new)),
                    escape(edit.text)
                    + ("  [yellow]← 描述里还写着旧值[/]" if edit.text_stale else ""),
                )
            console.print(table)
            stale = [edit for edit in edits if edit.text_stale]
            if stale:
                console.print(
                    f"[yellow]{len(stale)} 条断言的**描述**里还写着旧值[/]"
                    "（表里那一列会自相矛盾）—— 请手工改描述，工具不代改："
                    "有些旧数字是故意留的历史对照。"
                )
            console.print("改完请重跑 `v3 verify`（不带 --fix-claims）确认全绿。")
        if skipped:
            console.print(f"[yellow]{len(skipped)} 条没动[/]（期望值不是整数 / 量不出来）：")
            for line in skipped[:20]:
                console.print(f"   [dim]{escape(line)}[/]")
            if len(skipped) > 20:
                console.print(f"   …共 {len(skipped)} 条")
        return

    if fix:
        changes = verify.fix_markers(write=True)
        if not changes:
            console.print("[green]带标记的数字全都与断言一致，无需改动[/]")
            return
        table = Table(title=f"按断言改写 {len(changes)} 处", show_lines=False)
        table.add_column("文档", style="dim")
        table.add_column("行", justify="right")
        table.add_column("断言", style="dim")
        table.add_column("旧", justify="right")
        table.add_column("新", justify="right", style="green")
        for ch in changes:
            table.add_row(
                escape(ch.doc), str(ch.line), escape(ch.id), escape(ch.old), escape(ch.new)
            )
        console.print(table)
        console.print("改完请重跑 `v3 verify`（不带 --fix）确认全绿。")
        return

    if from_snapshot:
        _verify_from_snapshot(claims=verify.CLAIMS, only=only, no_drift=no_drift)
        return

    _require_game()
    claims = verify.CLAIMS
    if unregistered:
        # 覆盖率扫描：文档里还有哪些「数量」没进断言表。
        # 它是**排查工具**不是门禁 —— 输出刻意宽松（宁可多报），退出码 0。
        found = verify.find_unregistered_claims()
        if not found:
            console.print("[green]文档里没有未登记的数量断言[/]")
            return
        table = Table(title=f"{len(found)} 篇文档里有未登记的数量", show_lines=False)
        table.add_column("文档", style="dim")
        table.add_column("行", justify="right")
        table.add_column("原文", overflow="fold")
        for name, hits in sorted(found.items()):
            for line_no, text in hits[:20]:
                table.add_row(escape(name), str(line_no), escape(text.strip()[:90]))
        console.print(table)
        console.print(
            "[yellow]这些数字未必是错的[/] —— 只是没进断言表，因此没有看守。"
            "值得钉住的请登记到 pdx.verify.CLAIMS。"
        )
        return

    if only:
        claims = [c for c in claims if only in c.id]
        if not claims:
            # 不能筛出空列表就「全部通过」退出 0 —— 那样 --only 拼错一个字母
            # 会静默报成功，是最容易骗过 CI 的一类假绿灯。
            _fail(
                f"没有 id 含 {only!r} 的断言"
                f"（注册表共 {len(verify.CLAIMS)} 条；用 v3 verify 不带 --only 查看全部）"
            )

    results = verify.run_claims(claims, include_slow=not fast)
    failed = [r for r in results if not r.ok]

    table = Table(title=f"断言核对（{len(results)} 条）", show_lines=False)
    table.add_column("", width=2, justify="center")
    table.add_column("ID", style="dim")
    table.add_column("断言")
    table.add_column("实得", style="cyan")
    table.add_column("期望", justify="right")
    for result in results:
        table.add_row(
            "✅" if result.ok else "❌",
            escape(result.claim.id),
            escape(result.claim.text),
            escape(f"执行失败：{result.error}" if result.error else str(result.actual)),
            escape(str(result.claim.expected)),
        )
    console.print(table)

    summary = verify.summarize(results)
    console.print(f"通过 {summary['通过']} / {len(results)}    失败 {summary['失败']}")

    if failed:
        console.rule("[red]失败明细[/]")
        for result in failed:
            claim = result.claim
            console.print(f"[red]❌[/] [{escape(claim.id)}] [dim]{escape(claim.doc)}[/]")
            console.print(f"   {escape(claim.text)}")
            console.print(
                f"   期望 {escape(str(claim.expected))}  "
                f"实得 {escape(str(result.actual))}  {escape(result.error)}"
            )
            if claim.note:
                console.print(f"   备注：{escape(claim.note)}")

    # ── 归属标记的体检 ─────────────────────────────────
    # 与漂移扫描分工：标记是**精确绑定**（这个数字属于哪条断言），
    # 漂移扫描是**启发式**（锚点 + 量级），只管没有标记的断言。
    marker_issues = [] if only else verify.check_markers()
    if marker_issues:
        console.rule("[red]归属标记有问题[/]")
        for issue in marker_issues[:30]:
            console.print(f"[red]❌[/] {escape(issue.describe())}")
        if len(marker_issues) > 30:
            console.print(f"   …共 {len(marker_issues)} 处")
    elif not only:
        console.print(
            f"[green]归属标记全部对上[/]（{len(verify.all_markers())} 处，"
            f"数字不符时用 `v3 verify --fix`）"
        )

    # ── 文档正文的数字漂移 ──────────────────────────────
    # 用 unknown_doc_drift：已登记为「口径不同、文档其实没错」的那些不算失败。
    drift = [] if (no_drift or only) else verify.unknown_doc_drift()
    if not no_drift and not only:
        if drift:
            console.rule("[red]文档正文与断言表脱节[/]")
            for d in drift:
                console.print(f"[red]❌[/] {escape(d.describe())}")
            console.print(
                f"[yellow]共 {len(drift)} 处。若确认是「口径不同、文档没错」，"
                f"登记到 pdx.verify.KNOWN_METRIC_MIXUPS 并写明理由；否则请改文档。[/]"
            )
        else:
            mixups = len(verify.KNOWN_METRIC_MIXUPS)
            extra = f"（{mixups} 处已登记的口径错配不计）" if mixups else "（无已登记的口径错配）"
            console.print(f"[green]文档正文与断言表一致[/]{extra}")

    if json_out is not None:
        _write_json(
            json_out,
            {
                "summary": summary,
                "results": [
                    {
                        "id": r.claim.id,
                        "doc": r.claim.doc,
                        "text": r.claim.text,
                        "kind": r.claim.kind,
                        "target": r.claim.target,
                        "expected": r.claim.expected,
                        "actual": r.actual,
                        "ok": r.ok,
                        "error": r.error,
                    }
                    for r in results
                ],
                "文档漂移": [
                    {
                        "id": d.claim.id,
                        "doc": d.doc,
                        "line": d.line,
                        "found": d.found,
                        "expected": d.claim.expected,
                        "text": d.text.strip(),
                    }
                    for d in drift
                ],
                "标记问题": [
                    {"doc": i.doc, "line": i.line, "id": i.id, "detail": i.detail}
                    for i in marker_issues
                ],
            },
        )

    if failed or drift or marker_issues:
        raise typer.Exit(EXIT_FAILED)


# ── observe（运行期证据采集）───────────────────────────────
@app.command("observe")
def observe_cmd(
    once: Annotated[
        bool, typer.Option("--once", help="只采集当前日志和稳定 autosave，然后退出")
    ] = False,
    interval: Annotated[
        float, typer.Option("--interval", min=0.2, help="连续观察的间隔秒数")
    ] = 15.0,
    stable_seconds: Annotated[
        float, typer.Option("--stable-seconds", min=0.0, help="存档保持不变多久才读取")
    ] = 1.0,
    output: Annotated[
        Path | None,
        typer.Option("--output", help="证据目录；默认写入 tools/out/observations/<时间>"),
    ] = None,
    archive_saves: Annotated[
        bool, typer.Option("--archive-saves", help="复制稳定 autosave 原始字节；默认只保存摘要")
    ] = False,
    max_iterations: Annotated[
        int | None, typer.Option("--max-iterations", min=1, help="连续观察最多执行多少轮")
    ] = None,
) -> None:
    """后台采集日志增量和稳定 autosave 摘要。

    工具只读游戏用户目录，不启动或控制游戏。默认不复制百兆级存档；需要完整原始
    存档时显式传 ``--archive-saves``。报告会标记 runtime、snapshot 和 inference
    证据，并保留“状态变化不等于决策因果”的限制。
    """
    timestamp = time.strftime("%Y%m%dT%H%M%S")
    root = output or (config.OUT / "observations" / timestamp)
    session = observe.ObservationSession(
        config.USERDIR, root, archive_saves=archive_saves, stable_seconds=stable_seconds
    )
    iterations = 0
    try:
        while True:
            iterations += 1
            new_saves, new_logs = session.poll()
            # ``--once`` has no later polling turn to establish stability.  A
            # second zero-delay pass lets a file that was already complete at
            # startup be observed without weakening the collector's normal
            # two-sample stability contract.
            if once and stable_seconds == 0:
                extra_saves, extra_logs = session.poll()
                new_saves.extend(extra_saves)
                new_logs.extend(extra_logs)
            for event in new_saves:
                console.print(
                    f"[cyan]存档[/] {event['path']}："
                    f"{event['metadata'].get('game_date') or '日期未知'}"
                )
            if new_logs:
                console.print(f"[dim]日志增量：{len(new_logs)} 个文件块[/]")
            if once or (max_iterations is not None and iterations >= max_iterations):
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("[yellow]收到停止信号，正在写入当前报告。[/]")

    report = session.finish()
    report.update(
        {
            "tool": "v3 observe",
            "started_at": timestamp,
            "iterations": iterations,
            "userdir": str(config.USERDIR),
            "archive_saves": archive_saves,
        }
    )
    console.print(f"[green]观察报告已写入 {_relative(root)}[/]")


# ── crosscheck（引擎交叉验证）───────────────────────────────
@app.command("crosscheck")
def crosscheck_cmd(
    json_out: Annotated[
        Path | None, typer.Option("--json", help="把核对结果写入该 JSON 文件")
    ] = None,
) -> None:
    """用游戏自己的日志交叉验证我们的解析。

    这是本工具链里**唯一一次由外部背书的核对**。其余所有测试的比对对象
    都是我们自己写的实现（差分测试的预言机、黄金基线），两份实现可以
    一起错。引擎日志给的是第三方口径：

    * 它从哪些目录按什么扩展名枚举文件 —— 对「全量」的直接检验
    * 它报错时所在的文件与行号 —— 对行号与结构检验
    * 它在某行看到的文本键 —— 对 token 识别与行号检验

    前提：本机**运行过游戏**，从而 ``Documents/Paradox Interactive/Victoria 3/logs``
    下有日志。没有日志时本命令报前置条件缺失（退出码 2），不假装通过。

    注意日志里的游戏版本可能与当前安装不一致 —— 命令会把它打出来，
    版本不符时结论要打折。

    退出码分四档（见模块文档）：0 = 完全一致；1 = 有该修的问题（覆盖面缺口、
    或**行号可比的**真错配）；2 = 前置条件缺失；**3 = 不可核对** —— 检查跑了，
    但被核对的文件被 mod 覆盖、与原版不是同一套行号（行数不同 / 文件整份被删），
    「token 在不在那一行」这个问题本身无从回答。打 3 而不是 0/1，
    是因为这一档既不是通过（0 会把"没核对"说成"核对通过"），
    也不是不一致（1 会把两套行号的差记到解析器头上）——
    同族教训见历史审计 B85。
    """
    claims, version = engine_log.parse_logs()
    if not claims:
        _fail(f"找不到引擎日志：{engine_log.default_log_dir()}（需要先运行过一次游戏）")

    # 覆盖映射要留着 —— 「结论 = 不可核对」那一档必须写出**覆盖来源**
    # （哪个 mod 的哪份文件顶替了原版），否则读的人只看到"对不上"却不知道在跟谁对。
    overrides = engine_log.build_override_map()
    report = engine_log.cross_check(claims, log_version=version, overrides=overrides)
    s = report.summary()

    table = Table(title=f"引擎交叉验证（日志版本 {version or '未记录'}）", show_lines=False)
    table.add_column("指标")
    table.add_column("值", justify="right", style="cyan")
    for k, v in s.items():
        table.add_row(str(k), str(v))
    console.print(table)

    gaps = report.coverage_gaps
    if gaps:
        console.print("\n[red]覆盖面缺口：[/]")
        for d, e, n, hit, t in gaps:
            console.print(f"  ❌ {d}  {e}   引擎枚举 {n}，我们解析 {hit}（共 {t}）")

    # token 不一致要**判到底该不该核对**，不能混成一坨"不一致"。
    # ⚠️ 判据只有一处：:meth:`pdx.engine_log.CrossCheckReport.token_verdicts`（三态）。
    # 本命令只**消费**结论、只负责措辞与退出码 —— 不再自己读 ``line_counts`` 判一遍
    # （曾经命令层重判过一次，于是同一份输入两个结论，2026-09-28 收口时删掉）：
    #   ① 不可核对（行号不可比 / 日志比安装旧）⇒ 既不是通过，也不是不一致，退出码 3；
    #   ② 真错配（行号可比却对不上）⇒ 判红，这才是值得查的。
    # 把①②报成红，等于把"日志过期/两套行号"的账记到解析器头上（2026-09-22 实测 18/18）。
    verdicts = report.token_verdicts()
    #: 日志比安装旧的那一支（生效与原版都找不到这个 token）—— 与"行号不可比"分列说。
    absent = report.absent_tokens
    #: 行号不可比那一档（不可核对的主档）：既不能用 0 冒充成功，也不能用 1 冒充失败。
    unverifiable = [
        v
        for v in verdicts
        if v.state == engine_log.TOKEN_UNVERIFIABLE and v.kind != engine_log.KIND_STALE_ABSENT
    ]
    #: 真错配（行号可比却对不上）—— 唯一判红的一档，也是唯一要看行号的一档。
    misplaced_v = [v for v in verdicts if v.state == engine_log.TOKEN_MISPLACED]
    misplaced = [v.as_tuple for v in misplaced_v]
    #: 行号不可比的文件 -> 覆盖它的那个 mod 文件（"覆盖来源"，人要看的就是它）。
    override_source: dict[str, Path] = {
        v.file_rel: overrides[v.file_rel] for v in unverifiable if v.file_rel in overrides
    }

    # 摘要表已在上面打印过；模块的 ``summary()`` 里已经带三态读数，所以这里不再另加
    # 一行"重判"（两处各说一个数正是这轮要消灭的东西），表也不重印第二遍。

    if unverifiable:
        console.print(
            "\n[yellow]⚠️ 不可核对："
            f"{len(unverifiable)} 条 token 断言所在文件被 mod 覆盖、与原版不是同一套行号"
            "（行数不同／文件被删）⇒ 行号无从核对。[/]"
        )
        console.print(
            "[yellow]   结论 = 不可核对（既不是通过，也不是不一致；本命令退出码 3）："
            "验不了的不是解析器，是我们与引擎读的不是同一份内容。[/]"
        )
        for v in unverifiable:
            where = (
                f"覆盖版里别处有（第 {v.ours} 行）" if v.ours is not None else "覆盖版整份都没有"
            )
            console.print(f"   ⚠️ {v.file_rel}  日志第 {v.line} 行 {v.token!r} —— {where}")
        if override_source:
            console.print("   覆盖来源（引擎读的是它，我们读的也是它）：")
            for rel in sorted(override_source):
                console.print(f"     ⚠️ {rel}  ←  {_relative(override_source[rel])}")
        else:
            # 文件整份缺失的那一档没有覆盖来源可写：宁可少写一行，也不写空标题。
            console.print("   覆盖来源：无（生效文件整份缺失，不是被覆盖版持有）。")
        if misplaced:
            console.print("   这一档**不参与**下面的判红，也不用跑一次常规游戏去修它。")
        else:
            console.print("   ⇒ 跑一次常规游戏（与当前 mod 集一致）即可让行号重新可比。")
    if absent:
        console.print("\n[yellow]token 在当前安装中整份文件都找不到（日志比安装旧）：[/]")
        for rel, line, tok, _got in absent[:20]:
            console.print(f"  ⚠️ {rel}:{line}  {tok!r}")
        console.print(
            "  ⇒ 这些**不是**解析器问题：日志描述的是另一套 mod 状态。"
            "跑一次常规游戏即可让日志与安装一致。"
        )
    if misplaced:
        console.print("\n[red]token 行号不一致（真错配）：[/]")
        for rel, line, tok, got in misplaced[:20]:
            # got 是「那一行上有没有」；没有时再看跨行搜索命中的第几行 ——
            # 直接印 None 会读成「我们什么都没找到」，与事实不符（行号可比时刻意打印行号）。
            our_line: int | None = (
                got if got is not None else report.tokens_anywhere.get((rel, tok))
            )
            where = f"第 {our_line} 行" if our_line is not None else "整份文件都没有"
            console.print(f"  ❌ {rel}:{line}  {tok!r}  我们给出：{where}")

    if json_out is not None:
        _write_json(
            json_out,
            {
                "日志版本": version,
                "概览": s,
                "覆盖面": [
                    {"目录": d, "扩展名": e, "引擎枚举": n, "我们解析": hit, "文件数": t}
                    for (d, e), (n, hit, t) in sorted(report.coverage.items())
                ],
                "token核对": [
                    {"文件": rel, "行": line, "token": tok, "我们的行": got}
                    for rel, line, tok, got in report.tokens
                ],
                "位置核对": [
                    {"文件": rel, "行": line, "判定": why} for rel, line, why in report.locations
                ],
                "token分类": {
                    "不可核对（行号不可比）": len(unverifiable),
                    "真错配（行号可比）": len(misplaced),
                    "不可核对": [
                        {
                            "文件": v.file_rel,
                            "日志行": v.line,
                            "token": v.token,
                            "覆盖版的行": v.ours,
                            "说明": v.reason,
                            "来源细分": v.kind,
                            "覆盖来源": (
                                _relative(override_source[v.file_rel])
                                if v.file_rel in override_source
                                else None
                            ),
                        }
                        for v in unverifiable
                    ],
                    "整份文件都没有": [
                        {"文件": rel, "行": line, "token": tok} for rel, line, tok, _ in absent
                    ],
                    "真错配（在但不在那一行、且行号可比）": [
                        {
                            "文件": v.file_rel,
                            "行": v.line,
                            "token": v.token,
                            # 与上面同一口径：我们没有它对，但我们知道它在第几行时不许写 None 搪塞。
                            "我们的行": v.ours,
                        }
                        for v in misplaced_v
                    ],
                    "引擎日志模块的三态读数（本命令与它同源）": s,
                },
            },
        )

    # 退出码只认"真正该查的"一类：覆盖面缺口 与**行号可比的**真错配。
    # 不参与的两类：① 行号不可比（文件被覆盖、行数不同／文件被删）；② token 在当前安装里
    # 不存在（日志比安装旧）。判红就是把过期数据/两套行号的账记到解析器头上 ——
    # 实测 18 条不一致里 18 条属于这两类，2026-09-28 那 2 条也落在①。
    # 「不可核对」单独一档（退出码 3）：既不能用 0 冒充成功，也不能用 1 冒充失败。
    # ⚠️ 退出码与三态**一一对应**（判据同源，见上面 verdicts）：
    #   1 = 覆盖面缺口 或 至少一条 TOKEN_MISPLACED；
    #   3 = 至少一条 TOKEN_UNVERIFIABLE（行号不可比 / 日志比安装旧）；
    #   0 = 其余（全部 TOKEN_MATCH）。
    if gaps or misplaced:
        raise typer.Exit(EXIT_FAILED)
    if unverifiable or absent:
        console.print(
            f"\n[yellow]结论 = 不可核对：{len(unverifiable)} 条 token 行号不可比"
            f"（另有 {len(absent)} 条 token 在当前安装里整份文件都找不到）；"
            f"除此以外与引擎日志一致。本命令退出码 {EXIT_UNVERIFIABLE}"
            "（既不是通过，也不是不一致）。[/]"
        )
        console.print(
            "[yellow]   ⇒ 跑一次常规游戏、让引擎日志与当前 mod 集一致，这一档即可核对。[/]"
        )
        raise typer.Exit(EXIT_UNVERIFIABLE)
    console.print("\n[green]与引擎日志完全一致 ✅[/]")


# ── check-outputs ───────────────────────────────────────────
@app.command("check-outputs")
def check_outputs_cmd() -> None:
    """核验已落盘的分析产物是否与断言注册表一致。

    与 verify 的分工：verify 核验**游戏本体**（游戏里到底有多少条目），
    本命令核验**产物**（落盘的 JSON 有没有把它写对）。两者检查的是不同
    问题，但共用同一份注册表 ``verify.CLAIMS``。

    历史教训：早先这个脚本自己维护了一套写死的期望值，它的
    ``on_actions = 263`` 与注册表里的 264 长期冲突，又因为跑在 pytest
    管辖之外而无人发现。现在这种结构性分歧不可能再出现。

    缺少产物时退出码 2（先跑 `v3 analyze`），不一致时退出码 1。
    """
    game = _load_product(config.OUT_GAME / "游戏本体.json", "游戏本体分析")
    mods = _load_product(config.OUT_MODS / "mod.json", "mod 分析")
    cross = _load_product(config.OUT_CROSS / "交叉.json", "交叉分析")

    results = verify.verify_products(game, mods, cross)
    checkable = [r for r in results if r.claim.kind in verify.product_kinds()]

    table = Table(title="分析产物核验", show_lines=False)
    table.add_column("", width=2, justify="center")
    table.add_column("断言")
    table.add_column("实得", justify="right", style="cyan")
    table.add_column("期望", justify="right", style="dim")
    for result in checkable:
        table.add_row(
            "✅" if result.ok else "❌",
            escape(result.claim.text),
            escape(str(result.actual)),
            escape(str(result.claim.expected)),
        )
    console.print(table)

    failed = [r for r in checkable if not r.ok]
    skipped = len(results) - len(checkable)
    console.print(
        f"\n产物可核验 {len(checkable)} / {len(results)} 条断言"
        f"（其余 {skipped} 条需单独运行对应提取器，本命令不覆盖）"
    )

    if failed:
        console.print(f"[red]不一致 {len(failed)} 条：[/]")
        for result in failed:
            console.print(f"  ❌ [{escape(result.claim.id)}] {escape(result.line())}")
        raise typer.Exit(EXIT_FAILED)

    console.print("[green]产物与断言注册表完全一致 ✅[/]")


# ── show ────────────────────────────────────────────────────
@app.command("strings")
def strings_cmd(
    limit: int = typer.Option(40, "--limit", "-n", help="最多列出多少个未使用的标识符"),
    show_list: bool = typer.Option(True, "--list/--no-list", help="是否列出候选清单"),
    families: bool = typer.Option(False, "--families/--no-families", help="改按命名族聚类看"),
    by: str = typer.Option("suffix", "--by", help="族按后缀还是前缀聚：suffix / prefix"),
    min_size: int = typer.Option(8, "--min", help="族至少多少个成员才列出"),
) -> None:
    """开采 `victoria3.exe` 的字符串：引擎里有、脚本里没用的标识符。

    这条**不是**「下一步」了，而是已经在用的线索来源：`v3 evidence --exe-grep`
    按名字族取证、`--families` 按后缀/前缀聚类（PDX 字段名往往成族出现 ——
    实测 `*_command` 233 个、`*_cw_duplicate_compat` 161 个、`*_mult` 72 个）。

    口径见 `pdx.exe_strings`（扫可打印 ASCII 串 → 取标识符形状 → 与脚本词表作差）。
    它给的是**线索**而不是结论：候选里混着编译器与 CRT 符号（`SDL_` / `map_K*` 这种
    一眼能排除），哪些是 PDX 的字段枚举要人看。文件不存在时退出码 2。
    """
    if not exe_strings.exe_path().is_file():
        console.print(f"[red]找不到 {escape(str(exe_strings.exe_path()))}[/] —— 需要游戏本体")
        raise typer.Exit(2)

    stats = exe_strings.identifier_stats()
    table = Table(title="victoria3.exe 字符串开采", show_lines=False)
    table.add_column("指标")
    table.add_column("值", justify="right", style="cyan")
    table.add_row("exe 里的标识符形状串", f"{stats['exe']:,}")
    table.add_row("脚本里出现过的词", f"{stats['script']:,}")
    table.add_row("未在脚本里出现过", f"{stats['unused']:,}")
    console.print(table)

    if families:
        picked = exe_strings.identifier_families(by=by, min_size=min_size, limit=limit)
        console.print(f"\n按{'后缀' if by == 'suffix' else '前缀'}聚出的族（≥{min_size} 个成员）：")
        for token, names in picked:
            shown = "、".join(names[:3])
            console.print(f"  [cyan]{len(names):5d}[/]  {escape(token)}  [dim]{escape(shown)}…[/]")
        return

    if show_list:
        rows = exe_strings.unused_identifiers()
        console.print(f"\n未使用候选（前 {min(limit, len(rows))} / {len(rows):,}）：")
        for name in rows[:limit]:
            console.print(f"  {escape(name)}")


@app.command("lock")
def lock_cmd(
    write: bool = typer.Option(False, "--write", help="按当前环境重写 requirements.lock"),
) -> None:
    """依赖锁：把本机解析出来的依赖版本组合写成可核对的文件。

    `pyproject.toml` 里全是下限（`typer>=0.27`）—— 下限保证装得上，
    **不保证装出来是同一套**：CI 与本地、今天与三个月后解析出的
    pytest / ruff / hypothesis 版本可能不同，于是「代码一行没改却一边红」
    就会发生。这个命令沿 `Requires-Dist` 展开本机已安装的闭包，
    `--write` 写成 `requirements.lock`；不带参数时与锁**对账**（有差异退出码 1）。

    为什么不引 pip-tools / uv：那是又一个要装、要维护、要联网解析的工具，
    而本仓库只有 15 条直接依赖，标准库的 `importlib.metadata` 就够了。
    口径与边界（含「标记保守求值」这条）见 `pdx.lockfile`。
    """
    actual = lockfile.resolve()
    if write:
        count = lockfile.write(actual)
        console.print(f"[green]已写入 {lockfile.LOCK_FILE}：{count} 条[/]")
        return

    locked = lockfile.read()
    if not locked:
        _fail(f"读不到 {lockfile.LOCK_FILE}（或它不是本工具生成的）—— 先跑 `v3 lock --write`")

    drift = lockfile.compare(actual, locked)
    if not drift:
        console.print(f"[green]{lockfile.LOCK_FILE} 与当前环境一致（{len(locked)} 条）[/]")
        return

    table = Table(title=f"锁与环境有 {len(drift)} 处不一致", show_lines=False)
    table.add_column("包")
    table.add_column("类别")
    table.add_column("锁", style="dim")
    table.add_column("当前", style="cyan")
    for d in drift:
        table.add_row(
            escape(d.name), escape(d.kind), escape(d.locked or "—"), escape(d.actual or "—")
        )
    console.print(table)
    console.print("[yellow]确认过是有意升级/降级后，跑 `v3 lock --write` 更新锁[/]")
    raise typer.Exit(EXIT_FAILED)


@app.command("cov")
def cov_cmd(
    check_only: bool = typer.Option(False, "--check-only", help="只读上次的数据，不重跑测试"),
    top: int = typer.Option(0, "--top", help="只列出覆盖率最低的 N 个模块（0 = 全列）"),
) -> None:
    """跑覆盖率门禁：整体 86% 之外，再按**核心模块**逐条核对下限。

    为什么整体门禁不够：删掉 200 行 `cli.py` 的测试、再给某个小模块补 200 行
    测试，总数可以纹丝不动，而最要紧的那几个模块（解析器、断言注册表、
    归属标记、表格生成）已经悄悄退化了。口径与下限见 `pdx.covgate`。

    `--check-only` 读上次 `v3 cov` 写下的 `tools/out/cov.json`（不重跑，秒级）；
    完整覆盖率使用自适应并行预算，实际耗时见回归记录；这条**不进 CI**（CI 上没有游戏，
    覆盖率口径完全不同，理由见 `.github/workflows/ci.yml` 的文件头注释）。
    """
    code = 0
    if not check_only:
        code = covgate.run_pytest()
        if code != 0:
            console.print(f"[yellow]pytest 退出码 {code} —— 先让测试全绿再看覆盖率[/]")

    rows = covgate.load_coverage()
    if not rows:
        _fail(f"读不到覆盖率数据（{covgate.COV_JSON}）—— 先跑一次 `v3 cov`（不带 --check-only）")

    display_rows = sorted(rows, key=lambda r: r.percent)[:top] if top else rows

    table = Table(title="模块覆盖率（分支）", show_lines=False)
    table.add_column("模块")
    table.add_column("覆盖率", justify="right", style="cyan")
    table.add_column("下限", justify="right")
    table.add_column("语句", justify="right", style="dim")
    table.add_column("", width=2, justify="center")
    for row in display_rows:
        floor = row.floor
        table.add_row(
            escape(row.module),
            f"{row.percent:.1f}%",
            "—" if floor is None else f"{floor:.0f}%",
            f"{row.statements:,}",
            "" if floor is None else ("✅" if row.ok else "❌"),
        )
    console.print(table)

    failed = covgate.check(rows)
    gone = covgate.missing_floors(rows)
    overall = covgate.total_percent(rows)
    floor_overall = covgate.overall_floor()
    below_overall = overall + 1e-9 < floor_overall
    console.print(
        f"整体 {overall:.2f}%    低于下限 {len(failed)} 个模块"
        f"    [dim]（整体下限 {floor_overall:.0f}% 读自 pyproject.toml，"
        f"模块下限表 {len(covgate.FLOORS)} 个，见 pdx.covgate）[/]"
    )
    if below_overall:
        console.print(f"  [red]❌ 整体 {overall:.2f}% < {floor_overall:.0f}%[/]")
    for row in failed:
        console.print(f"  [red]❌ {escape(row.module)}：{row.percent:.1f}% < {row.floor:.0f}%[/]")
    if gone:
        console.print(
            f"[yellow]下限表里这些模块这次没有数据（改名或删了？）：{escape(', '.join(gone))}[/]"
        )
    if code != 0 or failed or below_overall or gone:
        raise typer.Exit(EXIT_FAILED)


@app.command("cache")
def cache_cmd(
    clear: bool = typer.Option(False, "--clear", help="清空磁盘缓存"),
    show_entries: bool = typer.Option(False, "--list", help="列出最旧的若干条目"),
) -> None:
    """解析缓存的状态与清理。

    全量分析、`v3 tables`、`v3 verify` 都要解析 6 千个脚本文件；内存缓存只管
    一次进程内的重复，**跨进程（`pytest -n auto` 的 16 个 worker、每次重跑）
    靠的是磁盘层**。缓存放在系统临时目录，按仓库路径分桶，不往仓库里塞文件。

    键 = `sha256(路径 + mtime + 大小 + 引擎指纹)`：源文件变了、解析器代码变了，
    旧条目自动失效，不需要谁记得清缓存。口径见 `pdx.cache` 模块文档。
    """
    mem = cache.stats()
    disk = cache.disk_counts()
    table = Table(title="解析缓存", show_lines=False)
    table.add_column("层")
    table.add_column("指标")
    table.add_column("值", justify="right", style="cyan")
    table.add_row("内存", "条目", f"{mem['条目']:,}")
    table.add_row("内存", "命中 / 未命中", f"{mem['命中']:,} / {mem['未命中']:,}")
    table.add_row("磁盘", "可命中条目", f"{disk['条目']:,}")
    table.add_row("磁盘", "分片 / 占用", f"{disk['分片']} / {disk['字节'] / 1048576:.1f} MB")
    table.add_row("磁盘", "状态", cache.describe_state())
    console.print(table)

    if show_entries:
        for path, mtime, size in sorted(cache.disk_entries(), key=lambda item: item[1])[:20]:
            console.print(
                f"  {time.strftime('%Y-%m-%d %H:%M', time.localtime(mtime))}  "
                f"{size / 1024:8.1f} KB  {escape(str(path))}"
            )

    if clear:
        removed = cache.clear_disk()
        console.print(f"[green]已清空磁盘缓存：{removed} 个分片[/]")


@app.command("evidence")
def evidence_cmd(
    keys: Annotated[list[str] | None, typer.Argument(help="要查证的键名，可给多个")] = None,
    mods: bool = typer.Option(False, "--mods/--no-mods", help="是否也扫本机 mod（③ 类证据）"),
    samples: bool = typer.Option(True, "--samples/--no-samples", help="是否列出原版样例"),
    exe_grep: str = typer.Option("", "--exe-grep", help="改查 exe 标识符里含该子串的一族名字"),
    directory: str = typer.Option("", "--dir", help="① 类只扫这个子树，如 common/scripted_lists"),
    values: bool = typer.Option(False, "--values/--no-values", help="列出该键的标量取值分布"),
) -> None:
    """查一个键名的四类证据：原版用法 / 官方 md / MOD 实践 / exe 字面量。

    doc 04 §13 那 28 项 **【未确认】** 里，相当一部分本地就有证据，只是散在
    四个地方。这个命令把它们一次摆出来，口径写在 `pdx.evidence`：

    ① 原版用法（`.txt`/`.gui` 过解析器，**注释不算用法**）
       键与**值**分开统计：`orphan` 是键，`character_event` 是值（`type = ...`）
    ② 官方 md 的篇名与行号，并区分「反引号/赋值」与「英文散文里恰好有这个单词」
    ③ 本机 mod 的使用次数（**本机快照**，不能写成断言）
    ④ `victoria3.exe` 里有没有这个字面量，以及它前后的邻居串（表内聚集）

    `--exe-grep` 换一个问法：引擎里有哪些同族名字（例如 `scripted` 一族）。
    ⚠️ ④ 只是线索：邻居里混着同节的无关字面量，"引擎里有" 不等于 "语法合法"。
    没有游戏本体时 ①②④ 为空，命令仍成功（退出码 0）。
    """
    if exe_grep:
        hits = exe_strings.match_identifiers(exe_grep, limit=0)
        console.print(f"exe 里含 [cyan]{escape(exe_grep)}[/] 的标识符（{len(hits)} 个）：")
        for name in hits[:200]:
            console.print(f"  {escape(name)}")
        if len(hits) > 200:
            console.print(f"  [dim]…（共 {len(hits)} 个，只列前 200）[/]")
        return
    if not keys:
        _fail("至少要给一个键名，例如 `v3 evidence is_shown_in_lobby`")

    reports = evidence.gather(
        keys, mods=mods, root=(config.GAME / directory) if directory else None
    )
    for ev in reports:
        console.print(f"\n[bold cyan]{escape(ev.key)}[/] —— {escape(ev.summary)}")
        v = ev.vanilla
        if v.total:
            by_dir = "、".join(f"{d}×{n}" for d, n in v.by_dir.most_common(4))
            parents = "、".join(f"{p}×{n}" for p, n in v.parents.most_common(4))
            forms = "、".join(f"{f}×{n}" for f, n in v.forms.most_common(3))
            console.print(f"  ① 目录：{escape(by_dir)}")
            console.print(f"    父键：{escape(parents)}")
            console.print(f"    形态：{escape(forms)}")
            if values and v.scalar_values:
                listed = "、".join(f"{k}×{n}" for k, n in v.scalar_values.most_common(12))
                console.print(f"    取值（{len(v.scalar_values)} 种）：{escape(listed)}")
            if samples:
                for s in v.samples:
                    console.print(f"    · [dim]{escape(s.where)}[/] {escape(s.text)}")
        if v.values:
            parents = "、".join(f"{p}×{n}" for p, n in v.value_parents.most_common(4))
            console.print(f"  ① 作为值：{v.values} 处，出现在：{escape(parents)}")
            if samples:
                for s in v.value_samples:
                    console.print(f"    · [dim]{escape(s.where)}[/] {escape(s.text)}")
        if ev.docs:
            code = ev.documented
            for hit in code[:4]:
                console.print(f"  ② [{hit.kind}] [dim]{escape(hit.where)}[/] {escape(hit.text)}")
            if len(code) > 4:
                console.print(f"     （另有 {len(code) - 4} 处）")
            if ev.prose:
                console.print(f"     （散文命中 {ev.prose} 处，不算「文档提到该键」）")
        if ev.mods:
            listed = "、".join(f"{m}×{n}" for m, n in ev.mods[:5])
            console.print(f"  ③ mod：{escape(listed)}")
        elif mods:
            console.print("  ③ mod：本机 mod 里 0 处")
        exe_state = "有" if ev.exe_exact else "无"
        console.print(f"  ④ exe 字面量：{exe_state}")
        if ev.exe_prev or ev.exe_next:
            if ev.exe_prev:
                console.print(f"     前：{escape(' '.join(ev.exe_prev))}")
            if ev.exe_next:
                console.print(f"     后：{escape(' '.join(ev.exe_next))}")


@app.command("prefixes")
def prefixes_cmd(
    directory: Annotated[
        str | None, typer.Argument(help="只看某个目录，例如 common/scripted_triggers")
    ] = None,
    top: int = typer.Option(12, "--top", "-n", help="最多列多少个目录"),
) -> None:
    """本机 mod 的**功能前缀按目录**用量 —— 「这个目录能不能带前缀」的证据。

    原版自己零使用功能前缀（`pdx.mods.vanilla_prefix_count`），所以 doc 04 §1
    那张表里「能否用 `REPLACE:` 之类的前缀」只能看 mod 实践。这个命令就是
    那 12 个 **【未确认】** 单元格的复算路径。

    ⚠️ 结果取决于本机装了哪些 mod（**本机快照**），不是游戏版本属性。
    没有 mod 时输出空表。
    """
    by_dir = mods_mod.prefix_usage_by_dir()
    if not by_dir:
        console.print("[yellow]没有发现任何 mod（workshop 与本地 mod 目录都为空）[/]")
        return
    if directory:
        counter = by_dir.get(directory)
        if not counter:
            console.print(f"[yellow]{escape(directory)} 下没有任何带前缀的条目[/]")
            return
        table = Table(title=f"{directory} 的功能前缀（本机快照）", show_lines=False)
        table.add_column("前缀")
        table.add_column("次数", justify="right", style="cyan")
        for prefix, count in counter.most_common():
            table.add_row(escape(prefix), str(count))
        console.print(table)
        return

    table = Table(title="各目录的功能前缀用量（本机 mod 快照）", show_lines=False)
    table.add_column("目录")
    table.add_column("前缀总计", justify="right", style="cyan")
    table.add_column("明细", style="dim")
    for rel_dir, counter in sorted(by_dir.items(), key=lambda item: -sum(item[1].values()))[:top]:
        detail = "、".join(f"{p}×{n}" for p, n in counter.most_common(5))
        table.add_row(escape(rel_dir), str(sum(counter.values())), escape(detail))
    console.print(table)


@app.command("assets")
def assets_cmd(
    json_out: Annotated[
        Path | None, typer.Option("--json", help="把普查结果写成 JSON（工作区相对路径）")
    ] = None,
    examples: bool = typer.Option(True, "--examples/--no-examples", help="列出非 2 的幂的样例"),
) -> None:
    """DDS 头普查：`game/gfx/**/*.dds` 的格式、尺寸与 mipmap。

    这三行结论此前来自**一次没留下脚本的全量扫描**（doc 06 §6.3）——
    也就是「下一个人无法复算」。现在口径写在 `pdx.assets`：读每个文件前 128 字节头，
    判据全部来自头内字段（mipmap 取 offset 28、标志位 `0x20000`、`fourCC` 取 84…）。

    ⚠️ 结果描述的是**本机这一份安装**，随 DLC 与美术更新而变；文档引用时
    应写成「本机快照 + 复算命令」。没有游戏时输出空表并成功退出。
    """
    result = assets.census()
    table = Table(title=f"DDS 头普查（{escape(result.root)}）", show_lines=False)
    table.add_column("指标")
    table.add_column("值", justify="right", style="cyan")
    for row in assets.format_rows(result):
        cells = [c.strip() for c in row.strip("|").split("|")]
        table.add_row(escape(cells[0]), escape(cells[1]))
    console.print(table)
    if examples and result.examples:
        console.print("非 2 的幂样例：" + escape("；".join(result.examples)))
    if json_out is not None:
        _write_json(json_out, result.summary())
        console.print(f"已写入 {escape(str(json_out))}")


@app.command("csv")
def csv_cmd(
    rel: Annotated[str, typer.Argument(help="游戏目录下的相对路径，如 map_data/adjacencies.csv")],
    column: Annotated[str, typer.Option("--column", "-c", help="只详列这一列的取值")] = "",
    limit: int = typer.Option(20, "--limit", "-n", help="--column 时最多列多少个取值"),
) -> None:
    """非 PDX 语法表格（`.csv` / `.tsv`）的取值分布。

    回答的是「这一列到底有哪些取值」这类问题 —— doc 06 §4.4 关于 `adjacencies.csv`
    的几条结论（`Type` 只有若干种取值、`Through` 全是 `-1`…）此前同样是一次性脚本的
    产物，现在可随时复算（口径见 `pdx.tabular`）。文件不存在时退出码 2。
    """
    path = (config.GAME / rel).resolve()
    _require_file(path, f"表格文件 {rel}", "路径按游戏目录算，例如 map_data/adjacencies.csv")
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    delimiter, columns, rows = tabular.parse_table_text(text)
    sheet = tabular.Table(
        rel=rel, delimiter=delimiter, columns=columns, rows=rows, size=path.stat().st_size
    )
    console.print(
        f"[bold]{escape(rel)}[/] 分隔符 {escape(repr(delimiter))}  "
        f"列 {len(columns)}  数据行 {len(rows):,}"
    )

    stats = tabular.column_stats(sheet, top=limit)
    if column:
        picked = [s for s in stats if s.name == column]
        if not picked:
            _fail(f"没有列 {column!r}；该表有：{', '.join(columns)}")
        stat = picked[0]
        console.print(
            f"列 [cyan]{escape(stat.name)}[/]：不同取值 {stat.distinct}，空值 {stat.blanks}"
        )
        for value, count in stat.top:
            console.print(f"  {escape(value)} × {count}")
        return

    out = Table(title="逐列取值分布", show_lines=False)
    out.add_column("列")
    out.add_column("不同取值", justify="right", style="cyan")
    out.add_column("空值", justify="right", style="dim")
    out.add_column("最常见", style="dim")
    for stat in stats:
        common = "、".join(f"{v}×{n}" for v, n in stat.top[:3])
        out.add_row(escape(stat.name), str(stat.distinct), str(stat.blanks), escape(common))
    console.print(out)


# ── ai-surface（原版 AI 意图层的可执行面）────────────────────
@app.command("ai-surface")
def ai_surface_cmd(
    write: Annotated[
        bool, typer.Option("--write", help="生成/更新 docs/design/02-可执行面.md")
    ] = False,
    check: Annotated[
        bool, typer.Option("--check", help="核对文档与生成结果是否一致（退出码 1 = 已被手改）")
    ] = False,
    top: Annotated[int, typer.Option("--top", "-n", help="输入清单最多列多少条")] = 60,
    offline: Annotated[
        bool,
        typer.Option("--offline", help="离线：原版 AI 面改读入库精简快照（CI 用），不读游戏本体"),
    ] = False,
) -> None:
    """原版 AI 意图层的**可执行面**：有哪些牌、牌在读什么、面有多大。

    这是当前 Mod 信息目录的机械生成器，回答三个问题（全部**枚举**自原版文件，不手抄）：

    1. **有哪些牌**：`common/ai_strategies/*.txt` 里每张 `ai_strategy_*` 的槽位（`type =`）、
       权重基准、条件数、有无 `possible` 门、牌面上的字段数；
    2. **牌在读什么**：牌的 `weight` / `possible` 里出现的**触发器**与**脚本值引用** ——
       这张清单就是「可喂输入清单」：原版 AI 自己会读的量，我们移动它就能影响概率；
    3. **面有多大**：`common/defines/00_ai.txt` 的 `NAI` 块规模、`*_ENABLED` 原版子系统开关、
       以及 `STRATEGY_RANDOM_FACTOR` 这类直接决定"随机性"的全局旋钮。

    产物 `docs/design/02-可执行面.md` **由本命令生成，勿手改**；`--check` 就是防手改的闸门
    （不一致退出码 1，可进 CI）。

    `--offline`：上面三件事改从**入库精简快照**的 `ai_surface` 域读（生成快照时由
    同一个模块写进去），因此没有游戏本体的机器（CI）也能跑 `--check`。它证明的仍是
    「文档与**入库快照**一致」，不是「与现在的游戏一致」（后者要本机 `--write`）。
    快照缺失或缺这一域时报**前置条件缺失**（退出码 2），不是通过。
    """
    # 前置条件先挡一道（P13：缺前置条件要**明确报错**，不是抛 traceback）。
    # 本命令的三件事全部枚举自原版文件，没有游戏本体时它连第一条都做不了 ——
    # 实测过：不挡的话 `--check` 会在读 `common/defines/00_ai.txt` 时抛
    # `FileNotFoundError` 并把整个 traceback 打到用户脸上。
    # 与 `v3 modguard` / `v3 tables` 同一口径：报"前置条件缺失"，退出码 2。
    if offline:
        try:
            ai_surface.read_offline()
        except ai_surface.OfflineUnavailableError as exc:
            _fail(str(exc))
    elif not config.GAME.is_dir():
        _fail(
            f"前置条件缺失：找不到原版目录 {config.GAME}（可用环境变量 V3_ROOT 指定）"
            " —— 本命令的三件事全部枚举自原版 ai_strategies / defines，"
            "没有游戏本体时不可用；没有游戏的机器请用 `--offline`（读入库快照）"
        )

    if check:
        try:
            problem = ai_surface.check_doc(top=top, offline=offline)
        except ai_surface.OfflineUnavailableError as exc:
            _fail(str(exc))
        if problem:
            _fail(problem)
        console.print(f"[green]{escape(ai_surface.DOC_REL)} 与生成结果一致 ✅[/]")
        if offline:
            index = ai_surface.offline_source()
            source = index.describe() if index is not None else "?"
            console.print(
                f"[dim]离线模式：原版 AI 面来自{escape(source)} —— 证明的是"
                "「文档与入库快照一致」，不是「与现在的游戏一致」。[/]"
            )
        return

    if offline:
        cards, defines = ai_surface.read_offline()
    else:
        cards = ai_surface.read_cards()
        defines = ai_surface.read_defines()
    inputs = ai_surface.collect_inputs(cards)

    if write:
        try:
            path = ai_surface.write_doc(top=top, offline=offline)
        except ai_surface.OfflineUnavailableError as exc:
            _fail(str(exc))
        console.print(
            f"[green]已写入 {escape(str(path))}[/]：{len(cards)} 张牌 / {len(inputs)} 个不同的输入"
        )
        return

    hits = ai_surface.factor_report(inputs)

    slots: dict[str, int] = {}
    for card in cards:
        slots[card.slot] = slots.get(card.slot, 0) + 1
    table = Table(title=f"原版 AI 牌面：{len(cards)} 张", show_lines=False)
    table.add_column("槽位")
    table.add_column("张数", justify="right", style="cyan")
    for slot, n in sorted(slots.items()):
        table.add_row(escape(slot), str(n))
    console.print(table)

    console.print(f"\n被牌读到的不同输入：**{len(inputs)}** 个，前 {min(top, len(inputs))} 个：")
    for item in inputs[:top]:
        console.print(f"  [cyan]{item.cards:3d}[/]x {escape(item.name)}  [dim]({item.kind})[/]")

    console.print("\n候选账本因子 → 原版读点：")
    for hit in hits:
        mark = "[green]✅[/]" if hit.hits else "[yellow]❌[/]"
        console.print(f"  {mark} {escape(hit.factor.name)}：{escape(hit.verdict)}")

    console.print(
        f"\ndefines 面：`00_ai.txt` {defines.lines} 行 / NAI 块 {defines.nai_keys} 键 / "
        f"原版子系统开关 {len(defines.enabled_switches)} 个 / `AI_*` 条目 {len(defines.ai_keys)} 个。"
    )
    console.print("跑 `v3 ai-surface --write` 生成 `docs/design/02-可执行面.md`。")


# ── political-surface（M5：政治候选静态语义）────────────────────
@app.command("political-surface")
def political_surface_cmd(
    write: Annotated[
        bool, typer.Option("--write", help="生成/更新 docs/design/02-政治候选面.md")
    ] = False,
    check: Annotated[
        bool, typer.Option("--check", help="核对文档与当前原版政治策略是否一致")
    ] = False,
    json_path: Annotated[
        Path | None,
        typer.Option("--json", help="另写一份结构化 JSON 索引（可选路径）"),
    ] = None,
) -> None:
    """枚举原版政治策略的法律候选输入与静态字段。

    该命令解析 ``change_law_chance``、通过率阈值、方向上限、革命厌恶和
    IG/运动偏好，并保留每个条件加法的来源行。它不计算引擎最终启动概率、
    候选排序或随机抽签；这些仍需实机 Getter 或行为证据。
    """
    if not config.GAME.is_dir():
        _fail(f"前置条件缺失：找不到原版目录 {config.GAME}（可用环境变量 V3_ROOT 指定）")
    try:
        strategies = political_surface.read_strategies()
        default_strategy = political_surface.read_default_strategy()
    except (OSError, ValueError) as exc:
        _fail(f"原版政治策略无法读取：{exc}")
    if check:
        problem = political_surface.check_doc()
        if problem:
            _fail(problem)
        console.print(f"[green]{escape(political_surface.DOC_REL)} 与生成结果一致 ✅[/]")
    if write:
        path = political_surface.write_doc()
        console.print(
            f"[green]已写入 {escape(str(path))}[/]：{len(strategies)} 张政治策略牌 + 默认层"
        )
    if json_path is not None:
        path = political_surface.write_json(json_path)
        console.print(f"[green]已写入 {escape(str(path))}[/]")
    if write or check or json_path is not None:
        return
    table = Table(title=f"原版政治策略：{len(strategies)} 张 + 默认层", show_lines=False)
    table.add_column("策略")
    table.add_column("change_law_chance")
    table.add_column("通过阈值")
    table.add_column("进度/倒退上限")
    table.add_column("来源")
    for strategy in strategies:
        change = political_surface._format_summary(strategy.change_law_chance)
        minimum = political_surface._format_summary(strategy.min_law_chance_to_pass)
        direction = (
            f"{political_surface._format_summary(strategy.max_progressiveness)} / "
            f"{political_surface._format_summary(strategy.max_regressiveness)}"
        )
        table.add_row(
            escape(strategy.name),
            escape(change),
            escape(minimum),
            escape(direction),
            escape(f"{strategy.file}:{strategy.line}"),
        )
    table.add_row(
        escape(default_strategy.name),
        escape(political_surface._format_summary(default_strategy.change_law_chance)),
        "—",
        "—",
        escape(f"{default_strategy.file}:{default_strategy.line}"),
    )
    console.print(table)
    console.print(
        "静态字段不等于最终引擎启动概率；运行 `v3 political-surface --write` 生成可追踪文档。"
    )


@app.command("modgen")
def modgen_cmd(
    write: Annotated[bool, typer.Option("--write", help="生成唯一正式 Mod 的仓库产物")] = False,
    check: Annotated[bool, typer.Option("--check", help="逐字节核对生成物，不写盘")] = False,
) -> None:
    """从生产 TOML 和锁定原版底本生成标准 Mod；生成物禁止手改。"""
    if write and check:
        _fail("--write 与 --check 互斥：先写盘，再另跑一次核对")
    try:
        if not (config.GAME / "common").is_dir():
            raise ValueError(f"缺少锁定游戏原件：{config.GAME / 'common'}")
        if write:
            company_sectors.write_baseline(config.GAME)
            distribution.equipment_opportunities.write_baseline(config.GAME)
            distribution.treaty_opportunities.write_baseline(config.GAME)
            distribution.mobilization_opportunities.write_baseline(config.GAME)
            binding_count = situated_bindings.write()
            domain_count = situated_domain_coverage.write_counts()
            console.print(
                f"[green]已重建 {binding_count} 条原版消费者绑定和 {domain_count} 个领域统计[/]"
            )
        elif check:
            source_problems = [
                *situated_bindings.check(),
                *situated_domain_coverage.check_counts(),
            ]
            if source_problems:
                _fail("生成合同不一致：\n" + "\n".join(source_problems), EXIT_FAILED)
        _, _, files = distribution.package_inputs()
        production = {name: text for name, text in files.items() if name != "README.md"}
        if write:
            written = decisions.write(decisions.PRODUCT, production)
            (decisions.PRODUCT / "generation-lock.json").write_text(
                distribution.generation_lock(production), encoding="utf-8", newline="\n"
            )
            console.print(f"[green]已生成 {len(written)} 个生产文件：UTF-8 无 BOM、LF[/]")
        elif check:
            problems = decisions.check(decisions.PRODUCT, production)
            distribution.check_generation_lock()
            if problems:
                _fail("生成物不一致：\n" + "\n".join(problems), EXIT_FAILED)
            console.print(f"[green]{len(production)} 个生产文件与源逐字节一致[/]")
        else:
            console.print(
                f"Situated AI {distribution.RELEASE_VERSION}：{len(production)} 个生产文件；--write 生成 / --check 核对"
            )
    except (ValueError, OSError) as exc:
        _fail(f"生成失败：{exc}", EXIT_FAILED)


@app.command("package")
def package_cmd(
    output: Annotated[Path, typer.Option("--output", help="正式 ZIP 输出路径")] = (
        distribution.DEFAULT_PACKAGE_PATH
    ),
) -> None:
    """核对生产生成物后打包；仅在游戏交付边界添加 BOM。"""
    try:
        target = distribution.package(output)
    except (ValueError, OSError) as exc:
        _fail(f"打包失败：{exc}", EXIT_FAILED)
    console.print(f"[green]已生成[/] {escape(str(target))}")


@app.command("citations")
def citations_cmd(
    paths: Annotated[
        list[str] | None,
        typer.Argument(help="要扫描的说明文件或目录"),
    ] = None,
) -> None:
    """核对说明文件里的 `文件:行号` 引用能否解析到当前游戏原版的唯一一行。

    ```text
    文件名写错（00_sikh_empire.txt 其实叫 04_sikh_empire.txt） ⇒ missing
    少了子路径（ai_strategies/… 其实在 common/ai_strategies/） ⇒ missing
    行号越界（文件 300 行，引了 :322）                          ⇒ out_of_range
    同名文件有几十个（modifiers.txt）                          ⇒ ambiguous
    ```

    必须显式提供路径，避免隐式扫描已删除的旧数据目录。此命令只检查引用路径、唯一性和行号，
    不判断被引内容是否支持说明中的结论；生产接口由 `modguard` 单独核验。
    """
    if not paths:
        _fail("至少指定一个说明文件或目录")
    targets = [Path(item) for item in paths]
    missing = [str(path) for path in targets if not path.exists()]
    if missing:
        _fail(f"找不到：{'、'.join(missing)}")
    found = citations.scan_paths(targets)
    if not found:
        _fail("指定路径中没有发现文件:行号引用")
    problems = [item for item in found if not item.ok]
    table = Table(
        title=f"{len(found)} 条引用（{len(found) - len(problems)} 条指得到）",
        show_lines=False,
    )
    table.add_column("结论", style="cyan")
    table.add_column("引用", overflow="fold")
    table.add_column("出处", overflow="fold")
    table.add_column("说明", overflow="fold")
    for item in problems[:40]:
        table.add_row(
            f"[red]{item.status}[/]",
            escape(f"{item.file}:{item.start}"),
            escape(item.where),
            escape(item.detail),
        )
    if problems:
        console.print(table)
        console.print(f"[yellow]{len(problems)} 条引用指不到唯一一行[/]")
        raise typer.Exit(EXIT_FAILED)
    console.print(f"[green]{len(found)} 条引用全部指得到唯一一行 ✅[/]")


@app.command("modguard")
def modguard_cmd(
    offline: Annotated[bool, typer.Option("--offline", help="从入库快照核对原版接口")] = False,
) -> None:
    """检查唯一生产包的生成、语法、底本和原版接口；不推断 AI 行为质量。"""
    try:
        if offline:
            distribution.check_generation_lock()
            policy, extensions = distribution.production_configuration()
            production = distribution.read_production_files()
            problems = []
        else:
            policy, extensions, files = distribution.package_inputs()
            production = {name: text for name, text in files.items() if name != "README.md"}
            problems = decisions.check(decisions.PRODUCT, production)
        index = vanilla_index.load(offline=offline)
        if index is None:
            _fail("缺少原版接口证据：请提供锁定游戏或使用入库快照")
        problems.extend(
            decisions.validate(
                index.vocabulary(),
                game=None if offline else config.GAME,
                snapshot={"域": index.sections} if offline else None,
                policy=policy,
                extensions=extensions,
                country_policy=country_state.load(),
            )
        )
        for name, text in production.items():
            if name.endswith(".txt") and isinstance(text, str):
                problems.extend(f"{name}: {error}" for error in parse_text(text, name).errors)
        if problems:
            _fail("生产工程检查失败：\n" + "\n".join(problems), EXIT_FAILED)
    except (ValueError, OSError) as exc:
        _fail(f"生产工程检查失败：{exc}", EXIT_FAILED)
    console.print(
        "[green]冻结源码/产物、脚本语法与快照接口检查通过[/]"
        if offline
        else "[green]生产生成、脚本语法、锁定底本与原版接口检查通过[/]"
    )
    console.print("证据：" + ("入库快照（不证明当前游戏内容）" if offline else "本机原版目录"))
    console.print("长期行为、平衡、玩家体验和游戏性能由用户验收。")


@app.command("decision-audit")
def decision_audit_cmd(
    output: Annotated[
        Path | None,
        typer.Option("--output", help="情境决策报告 JSON 输出路径；默认写入 tools/out/ci/"),
    ] = None,
    offline: bool = typer.Option(
        False,
        "--offline",
        help="只使用入库源和锁定底本；适用于无游戏目录的 CI 静态合同检查",
    ),
) -> None:
    """核对情境决策合同并生成可解释报告。

    默认复用一次生产构建得到的 engineering metadata；``--offline`` 使用入库源和
    锁定底本构造同一份静态合同，供无游戏目录的 CI 使用。它不启动游戏，也不把合同
    通过升级为 AI 行为或平衡通过。
    """
    target = output or (config.OUT / "ci" / "decision-audit.json")
    try:
        if offline:
            metadata = decision_report.source_metadata()
        else:
            _, _, files = distribution.package_inputs(include_engineering_metadata=True)
            metadata = json.loads(files[".metadata/metadata.json"])
            if not isinstance(metadata, dict):
                raise ValueError("工程 metadata 顶层必须是对象")
        report = decision_report.build(metadata)
    except (KeyError, TypeError, ValueError, OSError, json.JSONDecodeError) as exc:
        _fail(f"情境决策合同检查失败：{exc}", EXIT_FAILED)
    _write_json(target, report)
    domains = report["domains"]
    mapped = sum(row["status"] == "consumer_mapped" for row in domains.values())
    console.print(
        f"[green]情境决策合同通过[/]：{mapped}/{len(domains)} 个域已连接原版消费者，"
        f"{report['reader_count']} 个读取器（信息 {report['information_reader_count']}、"
        f"消费者 {report['consumer_reader_count']}），"
        f"{report['information_rule_count'] + report['consumer_rule_count']} 条规则"
    )
    console.print("证据：静态生成合同；行为、平衡和长期性能仍由用户实机验收。")


@situated_app.command("audit")
def situated_audit_cmd() -> None:
    """检查处境行动内核的源、关系、预算和生产接线合同。"""
    try:
        problems = situated.audit.check()
        coverage = situated.audit.report()
    except (OSError, ValueError) as exc:
        _fail(f"处境行动内核审计失败：{exc}", EXIT_FAILED)
    if problems:
        _fail("处境行动内核审计失败：\n" + "\n".join(problems), EXIT_FAILED)
    model = situated.load_model()
    label = (
        "处境行动内核审计通过"
        if coverage.status == "complete"
        else "处境行动内核审计完成，覆盖仍未收口"
    )
    color = "green" if coverage.status == "complete" else "yellow"
    console.print(
        f"[{color}]{label}[/]：{len(model.facts)} 个事实、"
        f"{len(model.actions)} 张显式行动卡、{len(model.action_instances)} 个生产行动实例、"
        f"{len(model.production_consumers)} 个生产消费者；覆盖状态 {coverage.status}，"
        f"原版范围状态 {coverage.scope_status}。"
    )
    console.print("证据：静态生成合同；不证明长期游戏行为质量。")


@situated_app.command("inventory")
def situated_inventory_cmd(
    output: Annotated[
        Path | None,
        typer.Option(
            "--output", help="盘点 JSON 输出目录；默认写入 tools/out/ci/situated-inventory/"
        ),
    ] = None,
) -> None:
    """生成 K0 原版决策面盘点和旧规则迁移台账。"""
    target = output or (config.OUT / "ci" / "situated-inventory")
    try:
        inventory_path, migration_path = situated_inventory.write(target)
        inventory = situated_inventory.discover()
    except (OSError, ValueError) as exc:
        _fail(f"处境决策面盘点失败：{exc}", EXIT_FAILED)
    console.print(
        f"[green]处境决策面盘点已写入[/]：{_relative(inventory_path)}；{_relative(migration_path)}"
    )
    console.print(
        f"发现 {inventory.discovered_count} 个面，范围哈希 {inventory.scope_hash}；"
        f"状态 {inventory.status_counts}。"
    )
    console.print("证据：K0 静态底本/生产源盘点；pending 不代表功能已实现。")


@situated_app.command("report")
def situated_report_cmd(
    output: Annotated[
        Path | None,
        typer.Option("--output", help="报告 JSON 输出路径；默认写入 tools/out/ci/"),
    ] = None,
    native: bool = typer.Option(
        False, "--native", help="读取锁定原版并重建生产输出，独立核对全范围映射与原版保护责任"
    ),
) -> None:
    """输出处境行动内核的可追溯合同报告。"""
    target = output or (config.OUT / "ci" / "situated-report.json")
    try:
        if native:
            payload = situated.audit.native_report()
        else:
            payload = situated.load_model().contract()
            payload["coverage"] = situated.audit.report().as_dict()
    except (OSError, ValueError) as exc:
        _fail(f"处境行动报告失败：{exc}", EXIT_FAILED)
    _write_json(target, payload)
    console.print(f"[green]处境行动报告已写入[/]：{_relative(target)}")
    console.print("证据：静态生成合同；不证明长期游戏行为质量。")


@situated_app.command("explain")
def situated_explain_cmd() -> None:
    """列出行动卡、消费者和未知回退，供静态审查使用。"""
    try:
        model = situated.load_model()
    except (OSError, ValueError) as exc:
        _fail(f"处境行动解释失败：{exc}", EXIT_FAILED)
    table = Table(title="处境行动卡（生成期合同）", show_lines=False)
    table.add_column("行动")
    table.add_column("领域")
    table.add_column("消费者")
    table.add_column("最大增量", justify="right")
    table.add_column("解释", overflow="fold")
    for action in model.actions:
        consumer = next(item for item in model.consumers if item.id == action.consumer)
        table.add_row(
            action.id,
            action.domain,
            consumer.field,
            f"{action.max_delta:g}",
            action.explanation,
        )
    console.print(table)
    console.print("未知、玩家和不可用路径回退原版；证据类别：simulation/static_check。")


@app.command("unverified")
def unverified_cmd(
    doc: str | None = typer.Option(None, "--doc", "-d", help="只看某篇，例如 04"),
    show_context: bool = typer.Option(True, "--context/--no-context", help="是否带上下文"),
) -> None:
    """列出文档里所有 **【未确认】** 项 —— 待验证清单的可复算版本。

    这些标记是**承诺**：凡是文档没证据的地方都必须标出来，不能凭印象断言。
    这个命令把承诺变成可数、可定位的清单（doc 04 §13 的 U 编号就是它的
    人工整理版），免得「还有多少没验证」只能靠人翻。

    没有未确认项时退出码 0；有则打印清单（退出码 0 —— 它是**清单**不是门禁，
    真正的门禁是 `v3 verify` 与 pytest）。
    """
    items = unknowns.unverified_items(doc=doc)
    if not items:
        scope = f"（doc {doc}）" if doc else ""
        console.print(f"[green]没有 【未确认】 项{scope}[/]")
        return

    by_doc: dict[str, list[unknowns.Unverified]] = {}
    for item in items:
        by_doc.setdefault(item.doc, []).append(item)

    table = Table(title=f"【未确认】清单（{len(items)} 处 / {len(by_doc)} 篇）", show_lines=False)
    table.add_column("文档")
    table.add_column("行", justify="right", style="cyan")
    table.add_column("章节", style="dim")
    table.add_column("上下文" if show_context else "内容")
    for name, group in sorted(by_doc.items()):
        for item in group:
            table.add_row(
                escape(name),
                str(item.line),
                escape(item.section),
                escape(item.context if show_context else item.text),
            )
    console.print(table)


@app.command("show")
def show_cmd() -> None:
    """转储已落盘产物的结构与规模。

    列出产出文件、各 JSON 的顶层字段、以及「一个 common 目录」和
    「一个 mod」记录了哪些内容 —— 改动提取逻辑后用它快速确认产物里
    到底有什么。产物不存在时退出码 2。
    """
    products = [
        ("游戏本体 JSON", config.OUT_GAME / "游戏本体.json"),
        ("mod JSON", config.OUT_MODS / "mod.json"),
        ("交叉 JSON", config.OUT_CROSS / "交叉.json"),
    ]
    game = _load_product(products[0][1], "游戏本体分析")
    mods = _load_product(products[1][1], "mod 分析")
    cross = _load_product(products[2][1], "交叉分析")

    files = [
        *products,
        ("游戏本体报告", config.REPORTS / "游戏本体分析.md"),
        ("mod 报告", config.REPORTS / "mod分析.md"),
    ]
    table = Table(title="产出文件", show_lines=False)
    table.add_column("名称")
    table.add_column("大小", justify="right", style="cyan")
    table.add_column("路径", style="dim")
    for label, path in files:
        table.add_row(escape(label), _size_text(path), escape(_relative(path)))
    console.print(table)

    console.print(_structure_table("游戏本体 JSON —— 顶层字段", game))

    common = game.get("common") or {}
    if common:
        # 样例取 buildings：它的字段最全。取不到就退回第一个目录 ——
        # 旧的 show_outputs.py 写的是 mods["各mod"][1]，产物结构一变就
        # IndexError，属于把「当前数据长什么样」硬编码进了展示代码。
        sample = "buildings" if "buildings" in common else next(iter(common))
        console.print(f"\n  · common 每个目录记录的内容（样例：{escape(sample)}）")
        console.print(_structure_table("", common[sample]))

        entries = sum(len(body.get("条目", [])) for body in common.values())
        fields = sum(len(body.get("字段", {})) for body in common.values())
        console.print(f"      common 条目名合计 {entries:,}")
        console.print(f"      common 字段名合计 {fields:,}")

    console.print(_structure_table("mod JSON —— 顶层字段", mods))

    mod_rows = mods.get("各mod") or []
    if mod_rows:
        first = mod_rows[0]
        name = first.get("名称") or first.get("目标") or "—"
        console.print(f"\n  · 每个 mod 记录的内容（样例：{escape(str(name))}）")
        console.print(_structure_table("", first))

    console.print(_structure_table("交叉 JSON —— 顶层字段", cross))


if __name__ == "__main__":  # pragma: no cover - 手工运行入口
    app()
