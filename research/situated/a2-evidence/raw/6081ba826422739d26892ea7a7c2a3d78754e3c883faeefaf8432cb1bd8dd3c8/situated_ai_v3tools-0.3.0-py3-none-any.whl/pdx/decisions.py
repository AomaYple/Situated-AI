"""生产 Mod 生成器：整合处境信息、规则和原版消费者适配器。

以锁定原版底本为基础生成策略、触发器、脚本值、事件与完整本地化。
只为 AI 增加有界倾向，保留玩家路径与原版行动执行，按源和底本指纹拒绝漂移。
"""

from __future__ import annotations

import hashlib
import importlib
import json
import math
import re
import tomllib
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass, replace
from pathlib import Path
from typing import TYPE_CHECKING

from packaging.version import InvalidVersion, Version

from . import (
    __version__,
    config,
    decision_adapters,
    decision_diplomacy,
    decision_economy,
    decision_interfaces,
    decision_rules,
    decision_security,
)
from .localization_languages import (
    DEFAULT_LANGUAGES,
    Language,
    localization_path,
)
from .localization_languages import (
    normalize as normalize_languages,
)
from .model import Block
from .parser import parse_text
from .situated import action_instances as situated_action_instances
from .situated import compiler as situated_compiler
from .situated import lowering as situated_lowering
from .situated import pdx_eval as situated_pdx_eval
from .situated import support_program
from .situated.compiler import load_model as load_situated_model
from .situated.compiler import strategy_overlay as compile_situated_overlay
from .situated.decision_ir import ContextBinding, EvaluationContext, WriterDecisionIR
from .textio import normalized_text
from .vanilla_index import (
    KEY_DIRS,
    SCRIPT_VALUE_ACCESSOR_DIR,
    VARIABLE_POOL_DIRS,
    VOCABULARY_DIRS,
    game_index,
    script_value_accessors,
    vocabulary_dir,
)

if TYPE_CHECKING:
    from .country_state import CountryPolicy


def _country_state_module():
    return importlib.import_module("pdx.country_state")


SOURCE = config.REPO / "mod" / "decisions" / "fiscal.toml"
PRODUCT = config.REPO / "mod"
BASELINE = config.REPO / "research" / "vanilla-ai" / "1.14.5" / "00_default_strategy.txt"
RISK_VAR = "sitai_fiscal_risk"
ACTIVE_TRIGGER = "sitai_fiscal_external_risk"
TOOL_VERSION = __version__
EXTENSIONS = SOURCE.with_name("extensions.toml")
PACKAGE_STATUSES = frozenset({"experimental", "candidate", "accepted"})
SAVE_COMPATIBILITY = frozenset({"new-game-only", "same-version-new-game", "same-candidate-save"})
SUPPORTED_PLATFORMS = frozenset({"windows", "macos", "linux"})
EXTENSION_PROFILE_MODULES = frozenset({"reform", "market", "security", "economy", "diplomacy"})

# 生产本地化集合跟随当前锁定的 Victoria 3 本体语言。
LANGUAGES: dict[str, str] = {language.directory: language.header for language in DEFAULT_LANGUAGES}

_DECISION_LOCALIZATION: dict[str, dict[str, str]] = {
    "SITAI_RULE_REMAINING_EXTERNAL_STATE_DEFAULT_COST_REASON": {
        "english": "Default and the financing burden of new territorial commitments",
        "braz_por": "Inadimplência e custo de financiar novos compromissos territoriais",
        "french": "Défaut de paiement et charge financière de nouveaux engagements territoriaux",
        "german": "Zahlungsausfall und Finanzierung neuer territorialer Verpflichtungen",
        "japanese": "債務不履行と新たな領土に伴う資金調達の負担",
        "korean": "채무 불이행과 신규 영토에 대한 재정 부담",
        "polish": "Niewypłacalność i obciążenie finansowe nowych zobowiązań terytorialnych",
        "russian": "Дефолт и финансовое бремя новых территориальных обязательств",
        "simp_chinese": "违约与新增领土承诺的融资负担",
        "spanish": "Impago y carga financiera de nuevos compromisos territoriales",
        "turkish": "Temerrüt ve yeni toprak taahhütlerinin finansman yükü",
    },
    "SITAI_RULE_REMAINING_EXTERNAL_STATE_RECONSTRUCTION_COST_REASON": {
        "english": "Postwar recovery takes priority over new territorial commitments",
        "braz_por": "A recuperação pós-guerra tem prioridade sobre novos compromissos territoriais",
        "french": "La reconstruction après-guerre prime sur de nouveaux engagements territoriaux",
        "german": "Wiederaufbau hat Vorrang vor neuen territorialen Verpflichtungen",
        "japanese": "新たな領土への関与に先立つ戦後復興",
        "korean": "신규 영토 확장보다 우선하는 전후 복구",
        "polish": "Odbudowa powojenna ma pierwszeństwo przed nowymi zobowiązaniami terytorialnymi",
        "russian": "Послевоенное восстановление важнее новых территориальных обязательств",
        "simp_chinese": "战后重建优先于新增领土承诺",
        "spanish": "La recuperación de posguerra tiene prioridad sobre nuevos compromisos territoriales",
        "turkish": "Savaş sonrası toparlanma yeni toprak taahhütlerinden önce gelir",
    },
    "SITAI_RULE_REMAINING_HOMELAND_FERVOR_REASON": {
        "english": "National fervor, homeland ties and a connected market",
        "braz_por": "Fervor nacional, laços com a pátria e conexão com o mercado",
        "french": "Ferveur nationale, liens avec la patrie et accès au marché",
        "german": "Nationaler Eifer, Heimatbindungen und Marktanbindung",
        "japanese": "国家的熱意、故郷との結び付き、市場接続",
        "korean": "국가적 열의, 본토 유대와 시장 연결",
        "polish": "Zapał narodowy, więzi z ojczyzną i połączenie z rynkiem",
        "russian": "Национальный пыл, связи с родиной и доступ к рынку",
        "simp_chinese": "民族热情、本土联系与市场连接",
        "spanish": "Fervor nacional, vínculos con la patria y conexión con el mercado",
        "turkish": "Ulusal coşku, anavatan bağları ve pazar bağlantısı",
    },
    "SITAI_SUPPORT_BALANCE_REASON": {
        "english": "Economic exposure and defensive commitments",
        "braz_por": "Exposição econômica e compromissos de defesa",
        "french": "Exposition économique et engagements défensifs",
        "german": "Wirtschaftliche Abhängigkeit und Verteidigungsverpflichtungen",
        "japanese": "経済的な依存と防衛上の約束",
        "korean": "경제적 노출과 방위 공약",
        "polish": "Zależność gospodarcza i zobowiązania obronne",
        "russian": "Экономическая зависимость и оборонные обязательства",
        "simp_chinese": "经济依赖与防御承诺的综合权衡",
        "spanish": "Exposición económica y compromisos defensivos",
        "turkish": "Ekonomik maruziyet ve savunma taahhütleri",
    },
    "SITAI_RULE_LJ14_CONNECTED_HOMELAND_FOUNDATION_REASON": {
        "english": "Homeland ties and market connection",
        "braz_por": "Laços com a pátria e conexão com o mercado",
        "french": "Liens avec la patrie et accès au marché",
        "german": "Heimatbindungen und Marktanbindung",
        "japanese": "故郷との結び付きと市場接続",
        "korean": "본토 유대와 시장 연결",
        "polish": "Więzi z ojczyzną i połączenie z rynkiem",
        "russian": "Связи с родиной и доступ к рынку",
        "simp_chinese": "本土联系与市场连接",
        "spanish": "Vínculos con la patria y conexión con el mercado",
        "turkish": "Anavatan bağları ve pazar bağlantısı",
    },
    "SITAI_RULE_LJ14_HOMELAND_ISOLATION_COST_REASON": {
        "english": "Market isolation of the homeland target",
        "braz_por": "Isolamento de mercado do território pátrio pretendido",
        "french": "Isolement du marché du territoire national visé",
        "german": "Marktisolation des angestrebten Heimatgebiets",
        "japanese": "目標となる故郷の市場からの孤立",
        "korean": "목표 본토 지역의 시장 고립",
        "polish": "Izolacja rynkowa docelowej ziemi ojczystej",
        "russian": "Рыночная изоляция целевой родной территории",
        "simp_chinese": "目标本土州的市场隔离成本",
        "spanish": "Aislamiento del mercado del territorio patrio objetivo",
        "turkish": "Hedef anavatan bölgesinin pazar yalıtımı",
    },
    "SITAI_RULE_LJ14_HOMELAND_ADMINISTRATIVE_COST_REASON": {
        "english": "Administrative cost of homeland integration",
        "braz_por": "Custo administrativo da integração de territórios pátrios",
        "french": "Coût administratif de l’intégration du territoire national",
        "german": "Verwaltungskosten der Eingliederung von Heimatgebieten",
        "japanese": "故郷の統合に伴う行政負担",
        "korean": "본토 통합의 행정 비용",
        "polish": "Koszt administracyjny integracji ziem ojczystych",
        "russian": "Административные издержки интеграции родных территорий",
        "simp_chinese": "本土整合的行政承诺成本",
        "spanish": "Coste administrativo de integrar el territorio patrio",
        "turkish": "Anavatan bütünleşmesinin idari maliyeti",
    },
    "SITAI_RULE_MARKET_ACCESS_STATE_VALUE_REASON": {
        "english": "Accessible market position and local demand",
        "braz_por": "Posição de mercado acessível e demanda local",
        "french": "Position de marché accessible et demande locale",
        "german": "Zugängliche Marktposition und lokale Nachfrage",
        "japanese": "市場へのアクセスと地域需要",
        "korean": "접근 가능한 시장 입지와 지역 수요",
        "polish": "Dostępna pozycja rynkowa i lokalny popyt",
        "russian": "Доступ к рынку и местный спрос",
        "simp_chinese": "良好的市场接入与本地需求",
        "spanish": "Posición de mercado accesible y demanda local",
        "turkish": "Erişilebilir pazar konumu ve yerel talep",
    },
    "SITAI_RULE_COORDINATED_LAYERED_INFORMATION_STATE_GEOGRAPHY_REASON": {
        "english": "Administrative burden of new territory",
        "braz_por": "Custo administrativo de novos territórios",
        "french": "Charge administrative des nouveaux territoires",
        "german": "Verwaltungsaufwand neuer Gebiete",
        "japanese": "新領土の行政負担",
        "korean": "신규 영토의 행정 부담",
        "polish": "Obciążenie administracyjne nowych terytoriów",
        "russian": "Административная нагрузка новых территорий",
        "simp_chinese": "新增领土的行政负担",
        "spanish": "Carga administrativa de nuevos territorios",
        "turkish": "Yeni toprakların idari yükü",
    },
    "SITAI_RULE_COORDINATED_LAYERED_INFORMATION_STATE_IDENTITY_REASON": {
        "english": "Homeland ties and sustainable capacity",
        "braz_por": "Laços com a pátria e capacidade sustentável",
        "french": "Liens avec la patrie et capacité durable",
        "german": "Heimatbindungen und tragfähige Kapazität",
        "japanese": "故郷との結び付きと持続可能な能力",
        "korean": "본토 유대와 지속 가능한 역량",
        "polish": "Więzi z ojczyzną i trwała zdolność działania",
        "russian": "Связи с родиной и устойчивый потенциал",
        "simp_chinese": "本土联系与可持续承受力",
        "spanish": "Vínculos con la patria y capacidad sostenible",
        "turkish": "Anavatan bağları ve sürdürülebilir kapasite",
    },
    "SITAI_RULE_COORDINATED_LAYERED_INFORMATION_STATE_RECOVERY_REASON": {
        "english": "Postwar recovery before new territorial commitments",
        "braz_por": "Recuperação pós-guerra antes de novos compromissos territoriais",
        "french": "Reconstruction après-guerre avant de nouveaux engagements territoriaux",
        "german": "Wiederaufbau vor neuen territorialen Verpflichtungen",
        "japanese": "新たな領土拡大に先立つ戦後復興",
        "korean": "신규 영토 확장보다 우선하는 전후 복구",
        "polish": "Odbudowa powojenna przed nowymi zobowiązaniami terytorialnymi",
        "russian": "Послевоенное восстановление до новых территориальных обязательств",
        "simp_chinese": "先恢复战后能力，再考虑新增领土承诺",
        "spanish": "Recuperación de posguerra antes de nuevos compromisos territoriales",
        "turkish": "Yeni toprak taahhütlerinden önce savaş sonrası toparlanma",
    },
    "SITAI_RULE_IDENTITY_FEASIBLE_HOMELAND_REASON": {
        "english": "Homeland ties and feasible national priorities (candidate)",
        "braz_por": "Laços com a pátria e prioridades nacionais viáveis (candidato)",
        "french": "Liens avec la patrie et priorités nationales réalisables (candidat)",
        "german": "Heimatbindungen und umsetzbare nationale Prioritäten (Kandidat)",
        "japanese": "故郷との結び付きと実行可能な国家の優先事項（候補ルール）",
        "korean": "본토 유대와 실행 가능한 국가 우선순위(후보 규칙)",
        "polish": "Więzi z ojczyzną i wykonalne priorytety narodowe (kandydat)",
        "russian": "Связи с родиной и осуществимые национальные приоритеты (кандидат)",
        "simp_chinese": "本土联系与可行的国家优先事项（候选规则）",
        "spanish": "Vínculos con la patria y prioridades nacionales viables (candidato)",
        "turkish": "Anavatan bağları ve uygulanabilir ulusal öncelikler (aday)",
    },
    "SITAI_RULE_GEOGRAPHIC_ISOLATION_FINANCIAL_COST_REASON": {
        "english": "Isolation and financial commitment costs (candidate)",
        "braz_por": "Isolamento e custos de compromissos financeiros (candidato)",
        "french": "Isolement et coûts des engagements financiers (candidat)",
        "german": "Geografische Isolation und Kosten finanzieller Verpflichtungen (Kandidat)",
        "japanese": "孤立と財政上の負担（候補ルール）",
        "korean": "고립과 재정적 부담 비용(후보 규칙)",
        "polish": "Izolacja i koszty zobowiązań finansowych (kandydat)",
        "russian": "Изоляция и стоимость финансовых обязательств (кандидат)",
        "simp_chinese": "地理孤立与财政承诺成本（候选规则）",
        "spanish": "Aislamiento y costes de los compromisos financieros (candidato)",
        "turkish": "Coğrafi izolasyon ve mali taahhüt maliyetleri (aday)",
    },
    "SITAI_RULE_GEOGRAPHIC_PORT_CONTINUITY_REASON": {
        "english": "Treaty port position and fiscal capacity (candidate)",
        "braz_por": "Posição do porto de tratado e capacidade fiscal (candidato)",
        "french": "Position du port de traité et capacité budgétaire (candidat)",
        "german": "Lage des Vertragshafens und finanzielle Kapazität (Kandidat)",
        "japanese": "条約港の位置と財政能力（候補ルール）",
        "korean": "조약항의 위치와 재정 역량(후보 규칙)",
        "polish": "Położenie portu traktatowego i możliwości fiskalne (kandydat)",
        "russian": "Положение договорного порта и финансовые возможности (кандидат)",
        "simp_chinese": "条约港位置与财政能力（候选规则）",
        "spanish": "Posición del puerto de tratado y capacidad fiscal (candidato)",
        "turkish": "Antlaşma limanının konumu ve mali kapasite (aday)",
    },
    "SITAI_MARKET_DEPENDENCE_SUPPORT_REASON": {
        "english": "Economic exposure to both sides",
        "braz_por": "Exposição econômica aos dois lados",
        "french": "Exposition économique aux deux camps",
        "german": "Wirtschaftliche Abhängigkeit von beiden Seiten",
        "japanese": "双方への経済的な依存",
        "korean": "양측에 대한 경제적 노출",
        "polish": "Gospodarcza zależność od obu stron",
        "russian": "Экономическая зависимость от обеих сторон",
        "simp_chinese": "对博弈双方的经济依赖",
        "spanish": "Exposición económica a ambos bandos",
        "turkish": "İki tarafa ekonomik maruziyet",
    },
    "SITAI_SECURITY_COMMITMENT_REASON": {
        "english": "Defense commitment (candidate)",
        "braz_por": "Compromisso de defesa (candidato)",
        "french": "Engagement de défense (candidat)",
        "german": "Verteidigungsverpflichtung (Kandidat)",
        "japanese": "防衛上の約束（候補ルール）",
        "korean": "방위 공약(후보 규칙)",
        "polish": "Zobowiązanie obronne (kandydat)",
        "russian": "Оборонное обязательство (кандидат)",
        "simp_chinese": "防御承诺（候选规则）",
        "spanish": "Compromiso defensivo (candidato)",
        "turkish": "Savunma taahhüdü (aday)",
    },
    "SITAI_SECURITY_NEIGHBOR_REASON": {
        "english": "Neighbor defense exposure (candidate)",
        "braz_por": "Risco de defesa de vizinho (candidato)",
        "french": "Exposition à la défense d'un voisin (candidat)",
        "german": "Sicherheitsrisiko durch die Bedrohung eines Nachbarlandes (Kandidat)",
        "japanese": "隣国防衛への関与（候補ルール）",
        "korean": "이웃 국가 방위 노출(후보 규칙)",
        "polish": "Ryzyko dla bezpieczeństwa związane z zagrożeniem sąsiada (kandydat)",
        "russian": "Риск для безопасности при угрозе соседней стране (кандидат)",
        "simp_chinese": "邻国受侵略的安全风险（候选规则）",
        "spanish": "Riesgo de defensa de un vecino (candidato)",
        "turkish": "Komşu savunma riski (aday)",
    },
    "SITAI_ECONOMY_CAPACITY_REASON": {
        "english": "Economic and administrative capacity (candidate)",
        "braz_por": "Capacidade econômica e administrativa (candidato)",
        "french": "Capacité économique et administrative (candidat)",
        "german": "Wirtschaftliche und administrative Kapazität (Kandidat)",
        "japanese": "経済・行政能力（候補ルール）",
        "korean": "경제 및 행정 역량(후보 규칙)",
        "polish": "Zdolność gospodarcza i administracyjna (kandydat)",
        "russian": "Экономическая и административная способность (кандидат)",
        "simp_chinese": "经济与行政能力（候选规则）",
        "spanish": "Capacidad económica y administrativa (candidato)",
        "turkish": "Ekonomik ve idari kapasite (aday)",
    },
    "SITAI_DIPLOMACY_BURDEN_REASON": {
        "english": "War burden and diplomatic capacity (candidate)",
        "braz_por": "Custo da guerra e capacidade diplomática (candidato)",
        "french": "Charge de guerre et capacité diplomatique (candidat)",
        "german": "Kriegslast und diplomatische Kapazität (Kandidat)",
        "japanese": "戦争負担と外交能力（候補ルール）",
        "korean": "전쟁 부담과 외교 역량(후보 규칙)",
        "polish": "Obciążenie wojną i zdolność dyplomatyczna (kandydat)",
        "russian": "Военная нагрузка и дипломатический потенциал (кандидат)",
        "simp_chinese": "战争负担与外交能力（候选规则）",
        "spanish": "Carga bélica y capacidad diplomática (candidato)",
        "turkish": "Savaş yükü ve diplomatik kapasite (aday)",
    },
}


def _localized_decision_text(key: str, language: Language) -> str:
    """返回生产说明译文；缺键或缺语言显式失败，不以英语冒充完整支持。"""

    values = _DECISION_LOCALIZATION[key]
    return values[language.directory]


@dataclass(frozen=True, slots=True)
class PackageContract:
    """由生产数据源声明的可追溯交付契约。"""

    product_version: str
    status: str
    parent: str
    save_compatibility: str
    platforms: tuple[str, ...]
    platform_notes: str


@dataclass(frozen=True, slots=True)
class Policy:
    enabled: bool
    game_version: str
    baseline_sha256: str
    entry_weeks: int
    exit_weeks: int
    ttl_days: int
    neutrality: float
    aggression: float
    package: PackageContract
    source_sha256: str = ""


@dataclass(frozen=True, slots=True)
class Extensions:
    reform_enabled: bool = False
    reform_legitimacy: int = 75
    fragile_legitimacy: int = 25
    reform_bonus: float = 1
    fragile_penalty: float = -0.5
    market_enabled: bool = False
    market_multiplier: float = 5
    source_sha256: str = ""
    security_enabled: bool = False
    security_commitment_bonus: float = 25
    security_threat_bonus: float = 15
    economy_enabled: bool = False
    diplomacy_enabled: bool = False


@dataclass(frozen=True, slots=True)
class SupportArbitration:
    """外交博弈支持字段的离线仲裁结果。

    ``market`` 与 ``security`` 都是同一原版字段的候选贡献。仲裁器只接受
    已知双方和 AI 作用域；安全理由按绝对值取一个最高理由，并按键去重，
    这样调用方不会把同一原因重复计分。
    """

    value: float
    reasons: tuple[str, ...]


def merge_diplomatic_play_support(
    *,
    market: float | None = None,
    security: Mapping[str, float | None] | None = None,
    has_sides: bool = True,
    is_ai: bool = True,
) -> SupportArbitration:
    """共享连续程序的兼容入口；未知辅助项局部退出，最终只限幅一次。"""
    if is_ai is not True or has_sides is not True:
        return SupportArbitration(0.0, ())
    result = support_program.combine(market, tuple((security or {}).items()))
    return SupportArbitration(result.value, result.reasons)


def player_boundary_issues(strategy: str) -> list[str]:
    """静态检查所有新增默认策略字段块都显式约束 ``is_ai``。"""

    marker = re.compile(r"# SITAI BEGIN ([^\n]+)\n(.*?)# SITAI END \1\n", re.DOTALL)
    return [
        f"{match.group(1)} 新增字段块缺少 is_ai = yes 玩家边界"
        for match in marker.finditer(strategy)
        if "is_ai = yes" not in match.group(2)
    ]


MODULE_LIFECYCLE_CONTRACT: dict[str, dict[str, object]] = {
    "fiscal": {
        "stateful": True,
        "direct_read": False,
        "hooks": [
            "on_monthly_pulse_country",
            "on_country_default",
            "on_country_no_longer_default",
        ],
        "ttl_or_none": "policy.ttl_days",
        "clear_on_disable": True,
    },
    "reform": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
    "market": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
    "security": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
    "economy": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
    "diplomacy": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
    "subjects": {
        "stateful": False,
        "direct_read": True,
        "hooks": [],
        "ttl_or_none": None,
        "clear_on_disable": True,
    },
}

FULL_INFORMATION_DOMAINS = (
    "political",
    "fiscal",
    "economy",
    "market",
    "diplomacy",
    "subjects",
    "military",
    "geography",
    "identity",
)


def information_contract() -> dict[str, object]:
    """生产候选携带的全量信息实现契约。

    这份契约描述 F0 的实现边界，不把静态目录或脚本加载宣称为行为质量；
    未确认的运行时消费者必须继续回退原版。
    """

    return {
        "schema": 1,
        "domains": list(FULL_INFORMATION_DOMAINS),
        "states": [
            "discovered",
            "runtime_readable",
            "derived",
            "consumer_mapped",
            "behavior_verified",
            "unsupported",
        ],
        "impact_levels": {
            "A": "direct",
            "B": "strategy",
            "C": "qualification",
            "D": "explanation",
            "E": "no_consumer",
        },
        "unknown_policy": "preserve_unknown_and_fallback_vanilla",
        "domain_list_kind": "target_scope_not_implementation_claim",
        "arbitration": "see_candidate_decision_rules_contract",
        "player_boundary": "is_ai_only",
        "behavior_quality": "user_long_term_review_pending",
    }


def module_lifecycle_contract(
    policy: Policy, _extensions: Extensions, country_policy: CountryPolicy | None = None
) -> dict[str, dict[str, object]]:
    """返回各决策模块的状态、求值时机、关闭和存档契约。"""

    contract = deepcopy(MODULE_LIFECYCLE_CONTRACT)
    contract["fiscal"]["ttl_or_none"] = policy.ttl_days if policy.enabled else None
    if country_policy is not None and country_policy.enabled:
        contract["country_state"] = {
            "stateful": False,
            "direct_read": True,
            "hooks": [],
            "ttl_or_none": None,
            "clear_on_disable": "no_persistent_state",
        }
    for item in contract.values():
        item["save_compatibility"] = policy.package.save_compatibility
    return contract


def load_extensions(source: Path = EXTENSIONS, *, profile: str | None = None) -> Extensions:
    """读取扩展配置；发布 profile 是生产开关的唯一来源。

    未指定 profile 时保留开发/离线默认开关，便于单元测试隔离模块。
    ``release`` 由 ``extensions.toml`` 声明启用模块，再覆盖各模块的默认开关。
    """
    raw = source.read_bytes()
    data = tomllib.loads(raw.decode("utf-8"))
    allowed = {
        "schema_version",
        "reform",
        "market",
        "security",
        "economy",
        "diplomacy",
        "profiles",
    }
    if (
        not set(data) <= allowed
        or not {"schema_version", "reform", "market"} <= set(data)
        or type(data["schema_version"]) is not int
        or data["schema_version"] != 1
    ):
        raise ValueError("扩展参数 schema 无效")
    reform, market = data["reform"], data["market"]
    if (
        not isinstance(reform, dict)
        or not isinstance(market, dict)
        or set(reform) != {"enabled", "legitimacy", "fragile_legitimacy", "bonus", "penalty", "why"}
        or set(market) != {"enabled", "multiplier", "why"}
    ):
        raise ValueError("扩展参数包含未知或缺失字段")
    if any(type(v) is not bool for v in (reform["enabled"], market["enabled"])):
        raise ValueError("扩展开关必须是布尔值")
    if (
        any(type(v) is not int for v in (reform["legitimacy"], reform["fragile_legitimacy"]))
        or not 0 <= reform["fragile_legitimacy"] < reform["legitimacy"] <= 100
    ):
        raise ValueError("合法性阈值必须是0到100的有序整数")
    amounts = (reform["bonus"], reform["penalty"], market["multiplier"])
    if (
        any(
            isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
            for v in amounts
        )
        or not 0 <= reform["bonus"] <= 5
        or not -0.9 <= reform["penalty"] <= 0
        or not 0 <= market["multiplier"] <= 10
    ):
        raise ValueError("扩展偏置必须有限且位于保守范围内")
    if any(not isinstance(v, str) or not v.strip() for v in (reform["why"], market["why"])):
        raise ValueError("扩展参数必须给出依据")
    security = data.get(
        "security",
        {
            "enabled": False,
            "commitment_bonus": 25,
            "threat_bonus": 15,
            "why": "旧配置：外部模块关闭",
        },
    )
    if (
        not isinstance(security, dict)
        or set(security) != {"enabled", "commitment_bonus", "threat_bonus", "why"}
        or type(security["enabled"]) is not bool
        or not isinstance(security["why"], str)
        or not security["why"].strip()
    ):
        raise ValueError("外部防御配置字段、开关或依据无效")
    for amount in (security["commitment_bonus"], security["threat_bonus"]):
        if (
            isinstance(amount, bool)
            or not isinstance(amount, (int, float))
            or not 0 <= amount <= 50
            or not math.isfinite(amount)
        ):
            raise ValueError("外部防御权重必须是 0 到 50 的有限数值")
    optional = {name: data.get(name, {}) for name in ("economy", "diplomacy")}
    for name, value in optional.items():
        if value and (not isinstance(value, dict) or set(value) != {"enabled"}):
            raise ValueError(f"{name} 扩展只允许声明 enabled；具体参数由模块数据源维护")
    profiles = data.get("profiles", {})
    if not isinstance(profiles, dict):
        raise ValueError("扩展 profile 必须是表")
    for name, modules in profiles.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError("扩展 profile 名称无效")
        if (
            not isinstance(modules, list)
            or any(
                not isinstance(module, str) or module not in EXTENSION_PROFILE_MODULES
                for module in modules
            )
            or len(modules) != len(set(modules))
        ):
            raise ValueError(f"扩展 profile {name} 必须是无重复的已知模块列表")
    if profile is not None:
        if not isinstance(profile, str) or not profile.strip():
            raise ValueError("扩展 profile 名称无效")
        if profile not in profiles:
            raise ValueError(f"扩展 profile 不存在：{profile}")
    enabled_profile = set(profiles.get(profile, ())) if profile is not None else set()
    return Extensions(
        reform_enabled=("reform" in enabled_profile) if profile is not None else reform["enabled"],
        reform_legitimacy=reform["legitimacy"],
        fragile_legitimacy=reform["fragile_legitimacy"],
        reform_bonus=reform["bonus"],
        fragile_penalty=reform["penalty"],
        market_enabled=("market" in enabled_profile) if profile is not None else market["enabled"],
        market_multiplier=market["multiplier"],
        source_sha256=hashlib.sha256(raw).hexdigest(),
        security_enabled=("security" in enabled_profile)
        if profile is not None
        else security["enabled"],
        security_commitment_bonus=security["commitment_bonus"],
        security_threat_bonus=security["threat_bonus"],
        economy_enabled=("economy" in enabled_profile)
        if profile is not None
        else bool(optional["economy"].get("enabled", False)),
        diplomacy_enabled=("diplomacy" in enabled_profile)
        if profile is not None
        else bool(optional["diplomacy"].get("enabled", False)),
    )


def extension_triggers(policy: Extensions) -> str:
    return f"""# 由 pdx.decisions 生成；改革派IG身份是机会代理，不指定法律。
sitai_reform_fragile = {{
    is_ai = yes
    OR = {{ legitimacy < {policy.fragile_legitimacy} is_at_war = yes any_insurrection_ongoing = yes }}
}}
sitai_reform_opportunity = {{
    is_ai = yes
    legitimacy >= {policy.reform_legitimacy}
    is_at_war = no
    any_insurrection_ongoing = no
    OR = {{
        ig:ig_industrialists ?= {{ is_in_government = yes }}
        ig:ig_intelligentsia ?= {{ is_in_government = yes }}
    }}
}}
"""


def extension_values(policy: Extensions) -> str:
    return f"""# 由 pdx.decisions 生成；本项是default贡献，不是最终AI总概率。
sitai_reform_default_delta = {{
    value = 0
    if = {{ limit = {{ sitai_reform_fragile = yes }} add = {policy.fragile_penalty:g} }}
    else_if = {{ limit = {{ sitai_reform_opportunity = yes }} add = {policy.reform_bonus:g} }}
}}
"""


def market_delta(own: float, other: float, *, multiplier: float) -> float:
    """依赖为0到5的方向性标度，双方差值的参考契约。"""
    if (
        any(not math.isfinite(v) for v in (own, other, multiplier))
        or not 0 <= own <= 5
        or not 0 <= other <= 5
        or not 0 <= multiplier <= 10
    ):
        raise ValueError("市场依赖必须在0到5，权重必须在0到10，所有数值有限")
    return (own - other) * multiplier


def load(source: Path = SOURCE) -> Policy:
    raw = source.read_bytes()
    data = tomllib.loads(raw.decode("utf-8"))
    if (
        set(data)
        != {
            "schema_version",
            "game_version",
            "baseline_sha256",
            "package",
            "fiscal",
            "fields",
        }
        or type(data["schema_version"]) is not int
        or data["schema_version"] != 1
    ):
        raise ValueError("决策数据源的 schema 或字段无效")
    if (
        not isinstance(data["game_version"], str)
        or data["game_version"] != "1.14.5"
        or not isinstance(data["baseline_sha256"], str)
        or len(data["baseline_sha256"]) != 64
        or any(c not in "0123456789abcdef" for c in data["baseline_sha256"])
        or not isinstance(data["package"], dict)
        or not isinstance(data["fiscal"], dict)
        or not isinstance(data["fields"], dict)
    ):
        raise ValueError("决策版本、底本指纹或参数表无效；升级需重新审查")
    package, fiscal, fields = data["package"], data["fiscal"], data["fields"]
    if (
        set(package)
        != {
            "product_version",
            "status",
            "parent",
            "save_compatibility",
            "platforms",
            "platform_notes",
        }
        or set(fiscal) != {"enabled", "entry_weeks", "exit_weeks", "ttl_days", "why"}
        or set(fields)
        != {
            "diplomatic_play_neutrality",
            "aggression",
            "why",
        }
    ):
        raise ValueError("决策数据源含缺失或未知字段")
    try:
        product_version = Version(package["product_version"])
    except (InvalidVersion, TypeError) as exc:
        raise ValueError("产品版本必须是有效的 Python 打包版本") from exc
    if (
        not isinstance(package["product_version"], str)
        or not isinstance(package["status"], str)
        or not isinstance(package["save_compatibility"], str)
        or not isinstance(package["platform_notes"], str)
        or str(product_version) != package["product_version"]
        or package["status"] not in PACKAGE_STATUSES
        or package["save_compatibility"] not in SAVE_COMPATIBILITY
        or not isinstance(package["parent"], str)
        or not package["parent"].strip()
        or not isinstance(package["platforms"], list)
        or not package["platforms"]
        or any(not isinstance(platform, str) for platform in package["platforms"])
        or len(set(package["platforms"])) != len(package["platforms"])
        or any(platform not in SUPPORTED_PLATFORMS for platform in package["platforms"])
        or not package["platform_notes"].strip()
    ):
        raise ValueError("产品交付契约无效：版本、状态、父包、存档或平台声明不可靠")
    if (
        any(
            not isinstance(v, str) or not v.strip()
            for v in (
                package["parent"],
                package["platform_notes"],
                fiscal["why"],
                fields["why"],
            )
        )
        or type(fiscal["enabled"]) is not bool
    ):
        raise ValueError("每组决策参数必须给出依据")
    contract = PackageContract(
        package["product_version"],
        package["status"],
        package["parent"],
        package["save_compatibility"],
        tuple(package["platforms"]),
        package["platform_notes"],
    )
    policy = Policy(
        fiscal["enabled"],
        data["game_version"],
        data["baseline_sha256"],
        fiscal["entry_weeks"],
        fiscal["exit_weeks"],
        fiscal["ttl_days"],
        fields["diplomatic_play_neutrality"],
        fields["aggression"],
        contract,
        hashlib.sha256(raw).hexdigest(),
    )
    if (
        any(
            type(v) is not int or v <= 0
            for v in (policy.entry_weeks, policy.exit_weeks, policy.ttl_days)
        )
        or policy.exit_weeks <= policy.entry_weeks
        or policy.ttl_days < 32
    ):
        raise ValueError("财政阈值必须为正整数，退出线高于进入线，TTL覆盖一个月")
    if (
        any(
            isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v)
            for v in (policy.neutrality, policy.aggression)
        )
        or not 0 <= policy.neutrality <= 100
        or not -1 <= policy.aggression <= 0
    ):
        raise ValueError("外交偏置必须为有限数且位于声明方向的保守范围内")
    return policy


def risk_next(
    active: bool,
    *,
    in_default: bool,
    taking_loans: bool,
    credit: float | None,
    weeks: float | None,
    policy: Policy,
) -> bool:
    """与脚本共享的有限状态契约；未知读数停止干预，不默认为安全。"""
    if not policy.enabled:
        return False
    if in_default:
        return True
    if not taking_loans or credit is None or not math.isfinite(credit) or credit <= 0:
        return False
    if weeks is None or not math.isfinite(weeks) or weeks < 0:
        return False
    return weeks < (policy.exit_weeks if active else policy.entry_weeks)


def fiscal_condition(weeks: int) -> str:
    """复用相同原生输入条件；它不包含迟滞记忆、TTL 或策略状态。"""
    if type(weeks) is not int or weeks <= 0:
        raise ValueError("财政条件周数必须是正整数")
    return f"""    OR = {{
        in_default = yes
        AND = {{ taking_loans = yes credit > 0 weeks_until_bankruptcy >= 0 weeks_until_bankruptcy < {weeks} }}
    }}"""


def diplomatic_play_support_addition(extensions: Extensions) -> str:
    """兼容入口：由同一有类型连续程序生成物理消费者写入。"""
    return support_program.SupportProgram.from_extensions(extensions).render()


def triggers(policy: Policy) -> str:
    if not policy.enabled:
        return ""
    return f"""# 由 pdx.decisions 生成；所有国家共享同一规则。
sitai_fiscal_entry = {{
{fiscal_condition(policy.entry_weeks)}
}}
sitai_fiscal_hold = {{
{fiscal_condition(policy.exit_weeks)}
}}
sitai_external_exposure = {{
    OR = {{
        is_at_war = yes
        is_diplomatic_play_initiator = yes
        is_diplomatic_play_target = yes
        is_diplomatic_play_committed_participant = yes
        is_diplomatic_play_undecided_participant = yes
    }}
}}
{ACTIVE_TRIGGER} = {{
    is_ai = yes
    sitai_external_exposure = yes
    has_variable = {RISK_VAR}
    sitai_fiscal_hold = yes
}}
"""


def effects(policy: Policy) -> str:
    if not policy.enabled:
        return ""
    return f"""# 由 pdx.decisions 生成；只有本更新器写入财政状态。
sitai_update_fiscal = {{
    if = {{
        limit = {{ is_ai = yes OR = {{ sitai_fiscal_entry = yes AND = {{ has_variable = {RISK_VAR} sitai_fiscal_hold = yes }} }} }}
        set_variable = {{ name = {RISK_VAR} value = 1 days = {policy.ttl_days} }}
    }}
    else = {{ remove_variable = {RISK_VAR} }}
}}
"""


def on_actions(policy: Policy | None = None) -> str:
    policy = policy or load()
    if not policy.enabled:
        return ""
    return """# 由 pdx.decisions 生成；追加子钩子，不替换原版 effect。
on_monthly_pulse_country = { on_actions = { sitai_fiscal_update } }
on_country_default = { on_actions = { sitai_fiscal_update } }
on_country_no_longer_default = { on_actions = { sitai_fiscal_update } }
sitai_fiscal_update = { effect = { sitai_update_fiscal = yes } }
"""


def patch_default(
    text: str,
    policy: Policy,
    extensions: Extensions | None = None,
    *,
    action_overlay: Mapping[str, str] | None = None,
    suppress_fields: frozenset[str] = frozenset(),
) -> str:
    """利用词法器定位闭括号，避免注释/字符串内的括号破坏补丁位置。"""
    text = normalized_text(text)
    if hashlib.sha256(text.encode()).hexdigest() != policy.baseline_sha256:
        raise ValueError("默认策略底本哈希不符；升级需重新审核，拒绝盲生成")
    parsed = parse_text(text, str(BASELINE))
    if (
        parsed.errors
        or len(parsed.top_assignments) != 1
        or parsed.top_keys != ["ai_strategy_default"]
    ):
        raise ValueError("底本必须恰好包含原版默认策略")
    block = parsed.top_assignments[0].value
    if not isinstance(block, Block):
        raise TypeError("默认策略必须为块")
    additions = {
        field: f"\t\tif = {{\n\t\t\tlimit = {{ ROOT ?= {{ is_ai = yes {ACTIVE_TRIGGER} = yes }} }}\n\t\t\tadd = {amount:g}\n\t\t}}\n"
        for field, amount in (
            ("diplomatic_play_neutrality", policy.neutrality),
            ("aggression", policy.aggression),
        )
        if policy.enabled and amount != 0 and field not in suppress_fields
    }
    if extensions and extensions.reform_enabled and "change_law_chance" not in suppress_fields:
        additions["change_law_chance"] = (
            "\t\tif = { limit = { ROOT ?= { is_ai = yes } } add = sitai_reform_default_delta }\n"
        )
    if extensions and "diplomatic_play_support" not in suppress_fields:
        support = diplomatic_play_support_addition(extensions)
        if support:
            additions["diplomatic_play_support"] = support
    if (
        extensions
        and extensions.economy_enabled
        and "economic_vs_government_spending_balance" not in suppress_fields
    ):
        additions["economic_vs_government_spending_balance"] = decision_economy.strategy_addition(
            replace(decision_economy.load(), enabled=True)
        )
    if extensions and extensions.diplomacy_enabled and "recklessness" not in suppress_fields:
        additions["recklessness"] = decision_diplomacy.strategy_addition(
            replace(decision_diplomacy.load(), enabled=True)
        )
    if action_overlay:
        for field, overlay in sorted(action_overlay.items()):
            if not overlay:
                continue
            additions[field] = additions.get(field, "") + overlay
    if not additions:
        return text
    for field in additions:
        matches = block.all(field)
        if len(matches) != 1 or not isinstance(matches[0].value, Block):
            raise ValueError(f"底本 {field} 必须为唯一脚本值块")
    positions = decision_rules.insertion_offsets(
        text, {(field,) for field in additions}, block, ("ai_strategy_default",)
    )
    result = text
    for field_path, offset in sorted(positions.items(), key=lambda item: item[1], reverse=True):
        name = field_path[0]
        addition = re.sub(r"(?m)^ +(?=\t)", "", additions[name])
        addition = re.sub(r"(?m)^[\t ]+$", "", addition)
        addition = re.sub(r"[\t ]+(?=\n)", "", addition).rstrip("\n") + "\n"
        # 常规底本在行首缩进前插入以保留原文；紧凑单行底本则在词法
        # 位置换行，不能凭行号把补丁插到字段外。
        start = result.rfind("\n", 0, offset) + 1
        if result[start:offset].strip():
            start = offset
            leading = "\n"
        else:
            leading = ""
        extra = f"{leading}\t\t# SITAI BEGIN {name}\n{addition}\t\t# SITAI END {name}\n"
        result = result[:start] + extra + result[start:]
    if parse_text(result).errors:
        raise ValueError("默认策略补丁产物解析失败")
    return result


def source_fingerprint(
    policy: Policy,
    extensions: Extensions,
    baseline: str,
    country_policy: CountryPolicy | None = None,
) -> dict[str, str]:
    """返回生成输入指纹，供 metadata 与交付清单共同引用。"""

    result = {
        "fiscal_source_sha256": policy.source_sha256,
        "extensions_source_sha256": extensions.source_sha256,
        "baseline_sha256": hashlib.sha256(normalized_text(baseline).encode()).hexdigest(),
        "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    situated_model = load_situated_model(baseline=baseline)
    result.update(
        {
            f"situated_{name}_source_sha256": digest
            for name, digest in situated_model.source_sha256.items()
        },
        situated_compiler_sha256=hashlib.sha256(
            Path(situated_compiler.__file__).read_bytes()
        ).hexdigest(),
    )
    if extensions.security_enabled:
        result["security_generator_sha256"] = hashlib.sha256(
            Path(decision_security.__file__).read_bytes()
        ).hexdigest()
    if extensions.market_enabled or extensions.security_enabled:
        result["support_program_generator_sha256"] = hashlib.sha256(
            Path(support_program.__file__).read_bytes()
        ).hexdigest()
    if extensions.economy_enabled:
        result["economy_source_sha256"] = decision_economy.load().source_sha256
    if extensions.diplomacy_enabled:
        result["diplomacy_source_sha256"] = decision_diplomacy.load().source_sha256
    if country_policy is not None:
        country_state = _country_state_module()

        result.update(
            country_state_source_sha256=country_policy.source_sha256,
            country_state_generator_sha256=hashlib.sha256(
                Path(country_state.__file__).read_bytes()
            ).hexdigest(),
        )
    return result


def _module_names(
    policy: Policy,
    extensions: Extensions,
    files: Mapping[str, str] | None = None,
    languages: tuple[Language, ...] = DEFAULT_LANGUAGES,
) -> list[str]:
    files = files or {}
    modules: list[str] = []
    if policy.enabled and (
        not files
        or {
            "common/scripted_triggers/sitai_fiscal_triggers.txt",
            "common/scripted_effects/sitai_fiscal_effects.txt",
            "common/on_actions/sitai_fiscal_on_actions.txt",
        }
        <= files.keys()
    ):
        modules.append("fiscal")
    if extensions.reform_enabled and (
        not files
        or {
            "common/scripted_triggers/sitai_reform_triggers.txt",
            "common/script_values/sitai_reform_values.txt",
        }
        <= files.keys()
    ):
        modules.append("reform")
    if extensions.market_enabled and (
        not files
        or {localization_path(language, "sitai_decisions") for language in languages}
        <= files.keys()
    ):
        modules.append("market")
    if extensions.security_enabled and (
        not files or "common/scripted_triggers/sitai_security_triggers.txt" in files
    ):
        modules.append("security")
    if extensions.economy_enabled and (
        not files or "common/scripted_triggers/sitai_economy_triggers.txt" in files
    ):
        modules.append("economy")
    if extensions.diplomacy_enabled and (
        not files or "common/scripted_triggers/sitai_diplomacy_triggers.txt" in files
    ):
        modules.append("diplomacy")
    return modules


def metadata_payload(
    policy: Policy | None = None,
    extensions: Extensions | None = None,
    *,
    enabled_modules: list[str] | None = None,
    baseline: str | None = None,
    languages: tuple[Language, ...] | None = None,
    complete_localization: bool = False,
    country_policy: CountryPolicy | None = None,
) -> dict[str, object]:
    policy = policy or load()
    extensions = extensions or load_extensions()
    languages = normalize_languages(DEFAULT_LANGUAGES if languages is None else languages)
    production_fallback_languages = (
        []
        if complete_localization
        else [
            language.directory
            for language in languages
            if language.directory not in {"english", "simp_chinese"}
        ]
    )
    return {
        "name": "Situated AI",
        "id": config.MOD_ID,
        "version": policy.package.product_version,
        "tool_version": TOOL_VERSION,
        "status": policy.package.status,
        "supported_game_version": policy.game_version,
        "short_description": (
            "依据国家处境综合调整政治、经济、外交与军事 AI 倾向，保留原版资格、成本和行动执行。"
        ),
        "picture": "thumbnail.png",
        "tags": [],
        "relationships": [],
        "enabled_modules": enabled_modules
        if enabled_modules is not None
        else _module_names(policy, extensions, languages=languages),
        "localization": {
            "languages": [language.directory for language in languages],
            "headers": [language.header for language in languages],
            # 保留旧消费者字段；生产回退必须如实声明，打包时拒绝缺译。
            "fallback_languages": production_fallback_languages,
            "production_fallback_languages": production_fallback_languages,
            # 生产源不包含解释探针，保留空字段以便核对历史生成合同。
            "explanation_fallback_languages": [],
            "fallback_policy": "none"
            if complete_localization
            else "experimental-only-english-source",
        },
        "parent_package": policy.package.parent,
        "save_compatibility": policy.package.save_compatibility,
        "platforms": list(policy.package.platforms),
        "platform_notes": policy.package.platform_notes,
        "module_contract": module_lifecycle_contract(policy, extensions, country_policy),
        "information_contract": information_contract(),
        "source_fingerprint": source_fingerprint(
            policy,
            extensions,
            baseline if baseline is not None else BASELINE.read_text(encoding="utf-8"),
            country_policy,
        ),
        "game_custom_data": {"multiplayer_synchronized": True},
    }


def attach_country_metadata(metadata: dict[str, object], country_policy: CountryPolicy) -> None:
    """Attach observations evaluated on demand by each vanilla consumer."""
    country_state = _country_state_module()

    state_contract = country_state.contract(country_policy)
    metadata["country_state"] = state_contract
    metadata["country_coordination"] = {
        "runtime_state": "stateless_consumer_observations"
        if country_policy.enabled
        else "disabled",
        "state_contract": state_contract,
        "behavior_verified": False,
        "evidence": "static_check",
    }
    modules = metadata["enabled_modules"]
    fingerprint = metadata["source_fingerprint"]
    assert isinstance(modules, list)
    assert isinstance(fingerprint, dict)
    if country_policy.enabled and "country_state" not in modules:
        modules.append("country_state")
    fingerprint.update(
        country_state_source_sha256=country_policy.source_sha256,
        country_state_generator_sha256=hashlib.sha256(
            Path(country_state.__file__).read_bytes()
        ).hexdigest(),
    )


def build(
    policy: Policy | None = None,
    baseline: str | None = None,
    *,
    extensions: Extensions | None = None,
    languages: tuple[Language, ...] | None = None,
    complete_localization: bool = False,
    information_rules: decision_rules.RuleSet | None = None,
    consumer_adapters: decision_adapters.AdapterSet | None = None,
    country_policy: CountryPolicy | None = None,
) -> dict[str, str]:
    policy = policy or load()
    baseline = baseline if baseline is not None else BASELINE.read_text(encoding="utf-8")
    extensions = extensions or load_extensions()
    situated_model = load_situated_model(baseline=baseline)
    supply_enabled = (
        consumer_adapters is not None
        and consumer_adapters.supply is not None
        and any("market" in adapter.enabled_domains for _, adapter in consumer_adapters.policies)
    )
    if not supply_enabled and situated_model.consumer_ir is not None:
        # The configured model is wider than a caller's actual enabled inputs.
        # A disabled adapter must not survive as a claimed production writer.
        situated_model = replace(
            situated_model,
            consumer_ir=replace(
                situated_model.consumer_ir,
                writers=tuple(
                    writer
                    for writer in situated_model.consumer_ir.writers
                    if writer.kind != "supply_program"
                ),
            ),
        )
    situated_compiled_contract: dict[str, object] | None = None
    # 在统一 IR 编译前保留字段 owner 的早期冲突门。这样篡改/拼接一条
    # 旧适配规则时，调用方仍得到“重复写入”的领域错误，而不是先看到
    # IR 与已冻结规则不一致的内部错误。
    if information_rules is not None and consumer_adapters is not None:
        # information.toml targets the body of the default strategy, so its
        # fields are stored relative to ``ai_strategy_default``.  Adapter
        # rules for that same consumer carry the root block in their field
        # path.  Compare the two representations at this earliest owner
        # gate, before the unified compiler lowers semantics; otherwise a
        # deliberately duplicated writer can surface as a later IR-drift
        # error and hide the more useful duplicate-write contract.
        information_fields = {
            rule.field
            if rule.field and rule.field[0] == "ai_strategy_default"
            else ("ai_strategy_default", *rule.field)
            for rule in information_rules.rules
        }
        seen_adapter_fields: set[tuple[str, ...]] = set()
        for source, field, _owner in decision_adapters.writes(consumer_adapters):
            comparable = field
            if source == "common/ai_strategies/00_default_strategy.txt" and field[:1] == (
                "ai_strategy_default",
            ):
                comparable = field
            if comparable in information_fields or comparable in seen_adapter_fields:
                raise ValueError(f"旧模块或全域规则与消费者适配重复写入字段：{'.'.join(field)}")
            seen_adapter_fields.add(comparable)
    # 将全域信息规则和消费者适配器先经过统一的处境编译器，再进入既有
    # patch/build 路径。这样目标、关系、未知回退和一次写入合同不会只停留
    # 在参考 API，而会真正影响生产生成；底层原版资格、成本和执行尾部仍由
    # 原有 patcher 保留。
    if information_rules is not None and consumer_adapters is not None:
        compiled_sources, situated_compiled_contract = situated_compiler.compile_sources(
            information_rules,
            consumer_adapters,
            config_model=situated_model,
        )
        compiled_by_source = dict(compiled_sources)
        information_rules = compiled_by_source["mod/decisions/information.toml"]
        consumer_adapters = replace(
            consumer_adapters,
            policies=tuple(
                (source, compiled_by_source.get(source, policy))
                for source, policy in consumer_adapters.policies
            ),
        )
    enabled_action_fields = {"diplomatic_play_neutrality"} if policy.enabled else set()
    support = support_program.SupportProgram.from_extensions(extensions)
    if support.enabled:
        bundle = situated_model.consumer_ir
        if bundle is None:
            raise ValueError("支持程序缺少统一消费者IR")
        source = "research/vanilla-ai/1.14.5/00_default_strategy.txt"
        support_writer = WriterDecisionIR(
            writer_id=support.writer_id,
            kind="support_program",
            source="mod/decisions/extensions.toml",
            definition=support.writer_id,
            consumer_id="diplomatic_play_support",
            field="diplomatic_play_support",
            actor="root",
            target="target_country",
            operation="add",
            vanilla_tail="preserve",
            owner="situated_kernel",
            program=support,
            evaluation_context=EvaluationContext(
                actor_scope=ContextBinding("root", "country", "actor", source, 183),
                targets=(
                    ContextBinding("target_country", "country", "target", source, 184),
                    ContextBinding("enemy_country", "country", "target", source, 185),
                ),
                evidence=tuple(f"{source}:{line}" for line in (183, 184, 185)),
            ),
        )
        situated_model = replace(
            situated_model,
            consumer_ir=replace(bundle, writers=(*bundle.writers, support_writer)),
        )
    if extensions.reform_enabled:
        enabled_action_fields.update(
            {"change_law_chance", "max_progressiveness", "max_regressiveness"}
        )
    if extensions.economy_enabled:
        enabled_action_fields.add("economic_vs_government_spending_balance")
    if extensions.diplomacy_enabled:
        enabled_action_fields.update({"aggression", "recklessness", "diplomatic_play_boldness"})
    action_overlay = {
        field: value
        for field, value in compile_situated_overlay(
            situated_model,
            enabled_consumer_fields=enabled_action_fields,
        ).items()
        if field in enabled_action_fields
    }
    if support.enabled:
        action_overlay["diplomatic_play_support"] = support.render()
    # 每个输出只允许一个处境规则作者。旧模块不能在适配规则后继续叠加，
    # 否则同一财政/宗属事实可能被重复计分；历史变体保持原实现。
    field_owners: dict[tuple[str, ...], str] = {}
    situated_fields = frozenset(action_overlay)
    if policy.enabled and "diplomatic_play_neutrality" not in situated_fields:
        field_owners.update(
            {
                ("diplomatic_play_neutrality",): "fiscal",
            }
        )
    if extensions.diplomacy_enabled and "aggression" not in situated_fields:
        field_owners[("aggression",)] = "diplomacy"
    for enabled, owner, fields in (
        (
            extensions.reform_enabled,
            "reform",
            tuple(field for field in ("change_law_chance",) if field not in situated_fields),
        ),
        (
            extensions.market_enabled or extensions.security_enabled,
            "support_composer",
            tuple(field for field in ("diplomatic_play_support",) if field not in situated_fields),
        ),
        (
            extensions.economy_enabled,
            "economy",
            tuple(
                field
                for field in ("economic_vs_government_spending_balance",)
                if field not in situated_fields
            ),
        ),
        (
            extensions.diplomacy_enabled,
            "diplomacy",
            tuple(field for field in ("recklessness",) if field not in situated_fields),
        ),
    ):
        if enabled:
            field_owners.update({(field,): owner for field in fields})
    for field_name in sorted(situated_fields):
        field_owners[(field_name,)] = "situated_kernel"
    if information_rules is not None:
        for field_path in information_rules.groups():
            if any(
                field_path[: len(existing)] == existing or existing[: len(field_path)] == field_path
                for existing in field_owners
            ):
                raise ValueError(f"旧模块与全域规则重复写入字段：{'.'.join(field_path)}")
            field_owners[field_path] = "information_rules"
    if consumer_adapters is not None:
        for name, field, owner in decision_adapters.writes(consumer_adapters):
            if name != "common/ai_strategies/00_default_strategy.txt":
                continue
            if field[0] != "ai_strategy_default":
                raise ValueError("默认策略适配不能写入其它顶层键")
            path = field[1:]
            if any(
                path[: len(existing)] == existing or existing[: len(path)] == path
                for existing in field_owners
            ):
                raise ValueError(f"旧模块或全域规则与消费者适配重复写入字段：{'.'.join(path)}")
            field_owners[path] = owner
    country_state = _country_state_module()

    languages = normalize_languages(DEFAULT_LANGUAGES if languages is None else languages)
    state_owned_triggers = (
        frozenset(country_state.owned_triggers(country_policy))
        if country_policy is not None
        else None
    )
    files = {
        "common/ai_strategies/00_default_strategy.txt": patch_default(
            baseline,
            policy,
            extensions,
            action_overlay=action_overlay,
            suppress_fields=frozenset(action_overlay),
        ),
    }
    adapter_inputs = (
        decision_adapters.read_inputs(consumer_adapters) if consumer_adapters is not None else None
    )
    if information_rules is not None:
        files["common/ai_strategies/00_default_strategy.txt"] = decision_rules.patch(
            files["common/ai_strategies/00_default_strategy.txt"],
            information_rules,
            baseline=baseline,
            reader_words=(
                frozenset(decision_adapters.reader_evidence(adapter_inputs))
                if adapter_inputs is not None
                else None
            ),
            country_policy=country_policy,
            owned_triggers=state_owned_triggers,
            consumer_ir=situated_model.consumer_ir,
            consumer_source="mod/decisions/information.toml",
        )
    strategy_issues = player_boundary_issues(files["common/ai_strategies/00_default_strategy.txt"])
    if strategy_issues:
        raise ValueError("生产策略违反玩家边界：" + "；".join(strategy_issues))
    if policy.enabled:
        files.update(
            {
                "common/scripted_triggers/sitai_fiscal_triggers.txt": triggers(policy),
                "common/scripted_effects/sitai_fiscal_effects.txt": effects(policy),
                "common/on_actions/sitai_fiscal_on_actions.txt": on_actions(policy),
            }
        )
    if extensions.reform_enabled:
        files["common/scripted_triggers/sitai_reform_triggers.txt"] = extension_triggers(extensions)
        files["common/script_values/sitai_reform_values.txt"] = extension_values(extensions)
    if extensions.security_enabled:
        files["common/scripted_triggers/sitai_security_triggers.txt"] = decision_security.triggers()
    if extensions.economy_enabled:
        files["common/scripted_triggers/sitai_economy_triggers.txt"] = decision_economy.triggers(
            replace(decision_economy.load(), enabled=True)
        )
    if extensions.diplomacy_enabled:
        files["common/scripted_triggers/sitai_diplomacy_triggers.txt"] = (
            decision_diplomacy.triggers(replace(decision_diplomacy.load(), enabled=True))
        )
    if (
        extensions.market_enabled
        or extensions.security_enabled
        or extensions.economy_enabled
        or extensions.diplomacy_enabled
        or information_rules is not None
    ):
        reason_keys: list[str] = []
        if extensions.market_enabled:
            reason_keys.append("SITAI_MARKET_DEPENDENCE_SUPPORT_REASON")
        if support.enabled:
            reason_keys.append("SITAI_SUPPORT_BALANCE_REASON")
        if extensions.security_enabled:
            reason_keys.extend(
                ["SITAI_SECURITY_COMMITMENT_REASON", "SITAI_SECURITY_NEIGHBOR_REASON"]
            )
        if extensions.economy_enabled:
            reason_keys.append("SITAI_ECONOMY_CAPACITY_REASON")
        if extensions.diplomacy_enabled:
            reason_keys.append("SITAI_DIPLOMACY_BURDEN_REASON")
        if information_rules is not None:
            reason_keys.extend(
                key
                for rule in information_rules.rules
                if rule.domain in information_rules.enabled_domains
                and (key := decision_rules.description_key(rule)) is not None
            )
        for language in languages:
            reasons = {key: _localized_decision_text(key, language) for key in reason_keys}
            files[localization_path(language, "sitai_decisions")] = (
                f"{language.header}:\n"
                + "".join(f' {key}: "{value}"\n' for key, value in reasons.items())
            )
    if country_policy is not None and country_policy.enabled:
        files.update(country_state.files(country_policy))
    metadata = metadata_payload(
        policy,
        extensions,
        enabled_modules=_module_names(policy, extensions, files, languages),
        baseline=baseline,
        languages=languages,
        complete_localization=complete_localization,
        country_policy=country_policy,
    )
    action_contract = situated_model.contract()
    action_contract["enabled"] = bool(action_overlay)
    action_contract["evidence"] = "static_check"
    semantic_facts = {
        "is_ai": True,
        "is_at_war": False,
        "in_default": False,
        "any_insurrection_ongoing": False,
        "legitimacy": 60,
        "bureaucracy": 1,
        "literacy_rate": 0.3,
        "is_subject": True,
    }
    action_contract["independent_pdx_semantics"] = {
        "consumer_count": len(action_overlay),
        "witnesses": {
            field: {
                "action_id": result.action_id,
                "operation": result.operation,
                "delta": result.delta,
                "fallback": result.fallback,
            }
            for field, overlay in sorted(action_overlay.items())
            for result in (situated_pdx_eval.select(overlay, semantic_facts),)
        },
        "evidence": "static_semantic_witness",
        "behavior_quality": "not_evaluated",
    }
    metadata["situated_actions"] = action_contract
    if situated_compiled_contract is not None:
        situated_metadata = metadata["situated_actions"]
        assert isinstance(situated_metadata, dict)
        situated_metadata["compiled_sources"] = situated_compiled_contract
    if country_policy is not None:
        attach_country_metadata(metadata, country_policy)
    if information_rules is not None or consumer_adapters is not None or support.enabled:
        metadata["default_field_owners"] = {
            ".".join(field): owner for field, owner in sorted(field_owners.items())
        }
    if information_rules is not None or consumer_adapters is not None:
        metadata["vanilla_field_coverage"] = decision_interfaces.coverage(baseline, field_owners)
    if information_rules is not None:
        rules_contract = decision_rules.contract(information_rules)
        metadata["decision_rules"] = rules_contract
        fingerprint = metadata["source_fingerprint"]
        enabled_modules = metadata["enabled_modules"]
        lifecycle = metadata["module_contract"]
        assert isinstance(fingerprint, dict)
        assert isinstance(enabled_modules, list)
        assert isinstance(lifecycle, dict)
        fingerprint.update(
            information_rules_source_sha256=information_rules.source_sha256,
            information_rules_generator_sha256=rules_contract["generator_sha256"],
        )
        enabled_modules.append("information_rules")
        lifecycle["information_rules"] = {
            "stateful": False,
            "direct_read": True,
            "hooks": [],
            "ttl_or_none": None,
            "clear_on_disable": "no_persistent_state",
            "save_compatibility": policy.package.save_compatibility,
        }
    if consumer_adapters is not None:
        adapter_files, adapter_contract = decision_adapters.build(
            consumer_adapters,
            overlays=files,
            texts=adapter_inputs,
            country_policy=country_policy,
            owned_triggers=state_owned_triggers,
            consumer_ir=situated_model.consumer_ir,
        )
        collisions = files.keys() & adapter_files.keys()
        if collisions - {"common/ai_strategies/00_default_strategy.txt"}:
            raise ValueError("消费者适配存在多个写入者：" + "、".join(sorted(collisions)))
        files.update(adapter_files)
        metadata["consumer_adapters"] = adapter_contract
        fingerprint = metadata["source_fingerprint"]
        enabled_modules = metadata["enabled_modules"]
        lifecycle = metadata["module_contract"]
        assert isinstance(fingerprint, dict)
        assert isinstance(enabled_modules, list)
        assert isinstance(lifecycle, dict)
        fingerprint.update(
            consumer_adapters_source_sha256=consumer_adapters.source_sha256,
            consumer_adapters_generator_sha256=adapter_contract["generator_sha256"],
            production_inputs_generator_sha256=adapter_contract[
                "production_inputs_generator_sha256"
            ],
            consumer_interfaces_sha256=hashlib.sha256(
                Path(decision_interfaces.__file__).read_bytes()
            ).hexdigest(),
        )
        enabled_modules.append("consumer_adapters")
        lifecycle["consumer_adapters"] = {
            "stateful": False,
            "direct_read": True,
            "hooks": [],
            "ttl_or_none": None,
            "clear_on_disable": "regenerate_without_adapter_files_and_restart",
            "save_compatibility": policy.package.save_compatibility,
        }
        if player_boundary_issues(files["common/ai_strategies/00_default_strategy.txt"]):
            raise ValueError("消费者适配违反玩家边界")
    strategic_policies = ([information_rules] if information_rules is not None else []) + (
        [row for _, row in consumer_adapters.policies] if consumer_adapters is not None else []
    )
    strategies = [row.strategy for row in strategic_policies if row.strategy is not None]
    if strategies:
        strategy = strategies[0]
        if any(other != strategy for other in strategies[1:]):
            raise ValueError("同一候选不能混合不同来源的战略意图")
        active_rules = [
            rule
            for row in strategic_policies
            for rule in row.rules
            if rule.domain in row.enabled_domains and rule.intent is not None
        ]
        strategic_contract = strategy.contract(
            {rule.intent for rule in active_rules if rule.intent}
        )
        metadata["strategic_coordination"] = {
            **strategic_contract,
            "rules_with_intent": len(active_rules),
            "runtime_state": "none",
            "behavior_verified": False,
            "limits": "nonexclusive_constraints; no_global_planner_or_persistent_country_intent",
        }
        fingerprint = metadata["source_fingerprint"]
        assert isinstance(fingerprint, dict)
        fingerprint.update(
            strategic_source_sha256=strategy.source_sha256,
            strategic_generator_sha256=strategic_contract["generator_sha256"],
        )
    # 所有生产消费者适配器在此之前已经写入 files；见证必须基于最终候选，
    # 不能只检查信息规则和行动 overlay 的中间状态。
    generated_texts = {
        name: text
        for name, text in files.items()
        if name.endswith(".txt") and isinstance(text, str)
    }
    action_contract["action_instance_witnesses"] = {
        "missing": list(
            situated_action_instances.missing_witnesses(situated_model.action_instances, files)
        ),
        "witness_count": len(situated_action_instances.witness_ids(files)),
        "required_rule_instances": sum(
            item.kind == "rule_action" for item in situated_model.action_instances
        ),
    }
    action_contract["action_instance_witness_contract"] = (
        situated_action_instances.witness_contract(situated_model.action_instances, files)
    )
    action_contract["legacy_behavior_witness_contract"] = (
        situated_action_instances.behavior_witness_contract(
            situated_model.action_instances,
            generated_texts,
        )
    )
    action_contract["ir_lowering_witness"] = {
        "missing": list(situated_lowering.missing(situated_model.action_ir, generated_texts)),
        "mismatches": list(situated_lowering.mismatches(situated_model.action_ir, generated_texts)),
        "witness_count": len(situated_lowering.witnesses(generated_texts)),
        "required_count": len(situated_model.action_ir),
        "evidence": "static_check",
    }
    ast_witnesses = situated_lowering.ast_witnesses(generated_texts)
    action_contract["ast_lowering_witness"] = {
        "mismatches": list(situated_lowering.ast_mismatches(generated_texts)),
        "witness_count": len(ast_witnesses),
        "parsed_count": sum(item.parsed for item in ast_witnesses),
        "limit_count": sum(item.has_limit for item in ast_witnesses),
        "write_count": sum(item.has_write for item in ast_witnesses),
        "evidence": "independent_pdx_ast_structure",
    }
    metadata["situated_actions"] = action_contract
    files[".metadata/metadata.json"] = (
        json.dumps(
            metadata,
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )
    for name, text in files.items():
        if name.endswith((".txt", ".yml")):
            files[name] = re.sub(r"(?m)[\t ]+$", "", text).rstrip("\n") + "\n"
    return files


def write(root: Path, files: Mapping[str, str | bytes] | None = None) -> list[Path]:
    files = files if files is not None else build()
    written: list[Path] = []
    for name, text in sorted(files.items()):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(text, bytes):
            path.write_bytes(text)
        else:
            path.write_text(text, encoding="utf-8", newline="\n")
        written.append(path)
    # 新产物写入成功后才删除固定受控的旧文件；探针与用户文件交给 check 报告。
    stale_names = {
        "common/scripted_triggers/sitai_country_triggers.txt",
        "common/scripted_effects/sitai_country_effects.txt",
        "common/on_actions/sitai_country_on_actions.txt",
        "common/scripted_triggers/sitai_fiscal_triggers.txt",
        "common/scripted_effects/sitai_fiscal_effects.txt",
        "common/on_actions/sitai_fiscal_on_actions.txt",
        "common/scripted_triggers/sitai_reform_triggers.txt",
        "common/script_values/sitai_reform_values.txt",
        "common/scripted_triggers/sitai_security_triggers.txt",
        "common/scripted_triggers/sitai_economy_triggers.txt",
        "common/scripted_triggers/sitai_diplomacy_triggers.txt",
        *(localization_path(language, "sitai_decisions") for language in DEFAULT_LANGUAGES),
    }
    localization_root = root / "localization"
    if localization_root.is_dir():
        stale_names.update(
            str(path.relative_to(root)).replace("\\", "/")
            for path in localization_root.glob("*/sitai_decisions_l_*.yml")
        )
    for name in stale_names:
        if name not in files:
            (root / name).unlink(missing_ok=True)
    return written


def check(root: Path, files: Mapping[str, str | bytes] | None = None) -> list[str]:
    files = files if files is not None else build()
    issues = [
        f"{name} 与决策数据源不一致"
        for name, text in files.items()
        if not (root / name).is_file()
        or (root / name).read_bytes() != (text if isinstance(text, bytes) else text.encode("utf-8"))
    ]
    issues.extend(
        f"{p.relative_to(root)} 是未声明产物"
        for p in root.rglob("*")
        if p.is_file()
        and p.relative_to(root).parts[0] in {"common", "localization", ".metadata"}
        and p.relative_to(root).as_posix() not in files
    )
    return issues


def validate(
    vocabulary: set[str] | None,
    *,
    game: Path | None = None,
    snapshot: object | None = None,
    policy: Policy | None = None,
    extensions: Extensions | None = None,
    country_policy: CountryPolicy | None = None,
) -> list[str]:
    """检查决策生成器实际生成的引擎接口及锁定底本。

    只凭目标词汇表集合无法验证所有产品接口：新生成的改革/市场字段需要
    对应 API 词汇证据；脚本解析成功不是引擎证据。快照域必须覆盖
    ``vocabulary``、``vanilla_keys`` 和 ``vanilla_variables``。
    """
    interfaces = set()
    if country_policy is not None:
        country_state = _country_state_module()

        try:
            country_state.validate(country_policy, game, snapshot=snapshot)
        except (ValueError, OSError) as exc:
            return [str(exc)]
        interfaces |= {"is_ai", "has_variable", "set_variable", "remove_variable"}
    policy = policy or load()
    if policy.enabled:
        interfaces |= {
            "is_ai",
            "is_at_war",
            "is_diplomatic_play_initiator",
            "is_diplomatic_play_target",
            "is_diplomatic_play_committed_participant",
            "has_variable",
            "in_default",
            "taking_loans",
            "credit",
            "weeks_until_bankruptcy",
            "set_variable",
            "remove_variable",
            "on_monthly_pulse_country",
            "on_country_default",
            "on_country_no_longer_default",
        }
    extensions = extensions or load_extensions()
    if extensions.reform_enabled:
        interfaces |= {"legitimacy", "any_insurrection_ongoing", "is_in_government"}
    if extensions.market_enabled:
        interfaces |= {"economic_dependence", "diplomatic_play_support"}
    if extensions.security_enabled:
        interfaces |= {
            "any_scope_treaty",
            "binds",
            "any_scope_article",
            "has_type",
            "is_adjacent_to_country",
            "play_participant_has_war_goal_of_type_against",
        }
    if extensions.economy_enabled:
        interfaces |= {
            "economic_vs_government_spending_balance",
            "taking_loans",
            "bureaucracy",
        }
    if extensions.diplomacy_enabled:
        interfaces |= {"recklessness", "in_default", "taking_loans"}
    # 财政值属于独立的原版 script value 参考，而不是四个通用词汇目录。
    fiscal_words = vocabulary_dir(BASELINE.parent) if policy.enabled else set()
    if policy.enabled:
        fiscal_words |= {"credit", "weeks_until_bankruptcy"}
    if vocabulary is None:
        vocabulary_words: set[str] = set()
        vocabulary_uncovered = True
    else:
        vocabulary_words = vocabulary
        vocabulary_uncovered = False
    key_words = vocabulary_dir(BASELINE.parent)
    variable_words: set[str] = set()
    variable_uncovered = False
    script_value_interfaces = interfaces & {"economic_dependence"}
    script_value_words: set[str] = set()
    script_value_uncovered = bool(script_value_interfaces)
    if snapshot is not None:
        if not isinstance(snapshot, Mapping):
            return ["原版接口快照结构无效"]
        sections = snapshot.get("域", snapshot.get("sections"))
        if not isinstance(sections, Mapping):
            return ["原版接口快照缺少域映射"]
        vocabulary_section = sections.get("vocabulary")
        keys_section = sections.get("vanilla_keys")
        variables_section = sections.get("vanilla_variables")
        vocabulary_uncovered = not isinstance(vocabulary_section, Mapping) or any(
            rel not in vocabulary_section for rel in VOCABULARY_DIRS
        )
        if isinstance(vocabulary_section, Mapping):
            vocabulary_words = {
                word
                for rel in VOCABULARY_DIRS
                for word in vocabulary_section.get(rel, [])
                if isinstance(word, str)
            }
        keys_uncovered = not isinstance(keys_section, Mapping) or any(
            rel not in keys_section for rel in KEY_DIRS
        )
        if isinstance(keys_section, Mapping):
            key_words = {
                word
                for rel in KEY_DIRS
                for word in keys_section.get(rel, [])
                if isinstance(word, str)
            }
        variable_uncovered = not isinstance(variables_section, Mapping) or any(
            rel not in variables_section for rel in VARIABLE_POOL_DIRS
        )
        if isinstance(variables_section, Mapping):
            variable_words = {
                word
                for rel in VARIABLE_POOL_DIRS
                for word in variables_section.get(rel, [])
                if isinstance(word, str)
            }
        script_value_section = sections.get("script_value_accessors")
        if (
            script_value_interfaces
            and isinstance(script_value_section, Mapping)
            and SCRIPT_VALUE_ACCESSOR_DIR in script_value_section
        ):
            script_value_words = {
                word
                for word in script_value_section[SCRIPT_VALUE_ACCESSOR_DIR]
                if isinstance(word, str)
            }
            script_value_uncovered = False
        if keys_uncovered:
            return ["原版键快照缺失所需目录，无法校验 on_action / effect 接口"]
    elif game is not None:
        index = game_index(game)
        if index is None:
            return [
                "本机原版目录缺失，无法校验决策接口",
                "原版词汇、键和变量证据均不可用；不能把缺失输入当成通过",
            ]
        key_sets = [index.keys(rel) for rel in KEY_DIRS]
        if any(words is None for words in key_sets):
            return ["原版键目录缺失，无法校验 on_action / effect 接口"]
        key_words = set().union(*(words for words in key_sets if words is not None))
        variables = index.variables()
        if variables is None:
            variable_uncovered = True
        else:
            variable_words = variables
        if script_value_interfaces:
            script_value_words = script_value_accessors(game / SCRIPT_VALUE_ACCESSOR_DIR)
            script_value_uncovered = False
    else:
        # 兼容以往只检查通用词汇的调用，但把底本自带证据与自产物词汇分开；
        # 新模块所需接口不会被“所有目标词都存在于目标里”这件事验证。
        vocabulary_uncovered = True

    evidence_words = vocabulary_words | key_words | variable_words | fiscal_words
    ordinary_interfaces = interfaces - script_value_interfaces
    issues = [
        f"决策生成接口未被原版证据覆盖：{name}"
        for name in sorted(ordinary_interfaces - evidence_words)
    ]
    if script_value_uncovered and script_value_interfaces:
        issues.append("原版脚本值 API 快照缺少 common/script_values 域，读取接口检查未覆盖")
    else:
        issues.extend(
            f"决策生成接口未被原版脚本值证据覆盖：{name}"
            for name in sorted(script_value_interfaces - script_value_words)
        )
    if vocabulary_uncovered:
        issues.append("原版词汇快照缺少所需目录；接口词汇检查未覆盖，不算通过")
    if variable_uncovered and "has_variable" in interfaces:
        issues.append("原版变量写入快照缺失；变量 API 检查未覆盖，不算通过")
    if game is not None:
        path = game / "common/ai_strategies/00_default_strategy.txt"
        if not path.is_file() or normalized_text(
            path.read_text(encoding="utf-8-sig")
        ) != BASELINE.read_text(encoding="utf-8"):
            issues.append("本机默认策略与锁定底本不一致，需重审版本")
    if game is not None and policy.enabled:
        path = game / "common/script_values/war_support_values.txt"
        reference = BASELINE.parent / "war_support_values.txt"
        if not path.is_file() or normalized_text(
            path.read_text(encoding="utf-8-sig")
        ) != reference.read_text(encoding="utf-8"):
            issues.append("本机财政接口参考与锁定底本不一致，需重审版本")
    return issues
